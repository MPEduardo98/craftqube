import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import ts from "typescript";
import React from "react";
import { render } from "@react-email/components";
import * as jsxRuntime from "react/jsx-runtime";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
// Ejecutar los módulos reales sin iniciar Next ni conectar servicios externos.
function cargar(archivo, dobles = {}, cache = new Map()) {
  const ruta = path.resolve(root, archivo);
  if (cache.has(ruta)) return cache.get(ruta);
  const codigo = ts.transpileModule(fs.readFileSync(ruta, "utf8"), {
    compilerOptions: { jsx: ts.JsxEmit.ReactJSX, esModuleInterop: true, module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 },
  }).outputText;
  const modulo = { exports: {} };
  cache.set(ruta, modulo.exports);
  const require = id => {
    if (id === "react") return React;
    if (id === "react/jsx-runtime") return jsxRuntime;
    if (id === "@react-email/components") return { render };
    if (id in dobles) return dobles[id];
    if (id.startsWith(".")) {
      const base = path.resolve(path.dirname(ruta), id);
      return cargar(fs.existsSync(`${base}.ts`) ? `${base}.ts` : `${base}.tsx`, dobles, cache);
    }
    throw new Error(`Dependencia no simulada: ${id}`);
  };
  new Function("require", "module", "exports", codigo)(require, modulo, modulo.exports);
  return modulo.exports;
}
const { CONTACTO_DEFAULT, obtenerCamposContacto } = cargar("src/contacto/types.ts");
const { validarConfig, validarMensaje } = cargar("src/contacto/validacion.ts");
const config = () => ({ ...structuredClone(CONTACTO_DEFAULT), activo: true, destinatario: "tienda@example.com" });
const campo = (id, tipo = "text", extra = {}) => ({ id, etiqueta: id, tipo, obligatorio: true, placeholder: "", ayuda: "", opciones: [], max: 5000, ...extra });
const personalizado = (...campos) => validarConfig({ ...config(), formulario: [campo("email", "email"), ...campos] });

test("convierte reglas antiguas y permite quitar mensaje y agregar preguntas ordenadas", () => {
  assert.deepEqual(obtenerCamposContacto(config()).map(c => c.id), ["nombre", "email", "telefono", "asunto", "mensaje"]);
  const c = personalizado(campo("servicio", "radio", { opciones: ["Asesoría", "Pedido"] }));
  assert.equal(c.campos.mensaje, "oculto");
  assert.deepEqual(validarMensaje({ email: "ana@example.com", servicio: "Pedido", mensaje: "Ignorar", desconocido: "Ignorar" }, c), { email: "ana@example.com", servicio: "Pedido" });
});

test("protege identificadores, correo esencial, tipos, límites y opciones del editor", () => {
  for (const campos of [
    [campo("email", "text")], [campo("email", "email", { obligatorio: false })],
    [campo("email", "email"), campo("website")], [campo("email", "email"), campo("constructor")],
    [campo("email", "email"), campo("pregunta"), campo("pregunta")],
    [campo("email", "email"), campo("pregunta", "file")],
    [campo("email", "email"), campo("pregunta", "text", { etiqueta: " " })],
    [campo("email", "email"), campo("pregunta", "text", { max: 5001 })],
    ...[[], [" "], ["A", " A "], ["x".repeat(161)], ["A\nB"], Array.from({ length: 31 }, (_, i) => String(i))].map(opciones => [campo("email", "email"), campo("pregunta", "radio", { opciones })]),
    Array.from({ length: 31 }, (_, i) => campo(`campo_${i}`)), [],
  ]) assert.throws(() => validarConfig({ ...config(), formulario: campos }));
});

test("valida selección única y múltiple contra las opciones guardadas", () => {
  const c = personalizado(campo("servicio", "select", { opciones: ["Asesoría", "Pedido"] }), campo("intereses", "checkbox", { opciones: ["A", "B", "C"] }));
  const datos = { email: "ana@example.com", servicio: "Pedido", intereses: ["C", "A"] };
  assert.deepEqual(validarMensaje(datos, c), { email: "ana@example.com", servicio: "Pedido", intereses: "A\nC" });
  for (const cambio of [{ servicio: "Intruso" }, { servicio: ["Pedido"] }, { intereses: "A" }, { intereses: ["A", "A"] }, { intereses: ["Intruso"] }, { intereses: [] }, { intereses: [3] }]) assert.throws(() => validarMensaje({ ...datos, ...cambio }, c));
  c.formulario[2].obligatorio = false;
  assert.deepEqual(validarMensaje({ email: datos.email, servicio: "Pedido" }, c), { email: datos.email, servicio: "Pedido" });
});

test("valida fechas reales, números y correos adicionales", () => {
  const c = personalizado(campo("fecha", "date"), campo("cantidad", "number"), campo("otro", "email", { obligatorio: false }));
  const datos = { email: "ana@example.com", fecha: "2028-02-29", cantidad: "2.5" };
  assert.equal(validarMensaje(datos, c).cantidad, "2.5");
  for (const cambio of [{ fecha: "2026-02-29" }, { fecha: "2026-13-01" }, { cantidad: "Infinity" }, { cantidad: "abc" }, { otro: "incorrecto" }]) assert.throws(() => validarMensaje({ ...datos, ...cambio }, c));
});

test("configuración rechaza destinatarios, reglas y campos esenciales inválidos", () => {
  assert.equal(validarConfig(config()).activo, true);
  for (const v of [null, [], {}, { ...config(), destinatario: "mal" }, { ...config(), activo: "true" }, { ...config(), campos: {} }, { ...config(), campos: { ...config().campos, email: "oculto" } }]) {
    assert.throws(() => validarConfig(v));
  }
});
test("reglas vigentes, límites, correo y tipos se validan en servidor", () => {
  const datos = { nombre: " Ana ", email: "ana@example.com", mensaje: "Hola", empresa: "No conservar", destinatario: "atacante@example.com" };
  assert.deepEqual(validarMensaje(datos, config()), { nombre: "Ana", email: "ana@example.com", mensaje: "Hola" });
  for (const cambio of [{ nombre: "" }, { mensaje: " " }, { mensaje: "x".repeat(5001) }, { email: "a@b.com\r\nBcc: victim@example.com" }, { telefono: [] }]) {
    assert.throws(() => validarMensaje({ ...datos, ...cambio }, config()));
  }
  const c = config(); c.campos.telefono = "obligatorio";
  assert.throws(() => validarMensaje(datos, c));
});
test("configuración pública no expone destinatario", () => {
  const { contactoPublico } = cargar("src/contacto/config.ts", { "../db/pool": { pool: {} } });
  assert.equal("destinatario" in contactoPublico(config()), false);
});

function mensajesDoble(resultados = [{ error: null }, { error: null }], fallaInsert = false) {
  const eventos = [];
  const { recibirMensaje } = cargar("src/contacto/mensajes.ts", {
    "../db/pool": { pool: { execute: async (sql, params) => {
      eventos.push({ sql, params });
      if (fallaInsert) throw new Error("DB no disponible");
      return [{ insertId: 42 }];
    } } },
    "../email/logo": { getLogoAttachment: async () => ({ content: "bG9nbw==", filename: "Logo.png", contentId: "logo-tienda" }) },
    "../email/resend": {
      getFromEmail: () => "Marca <hola@example.com>",
      getResend: () => ({ emails: { send: async correo => {
        eventos.push({ correo });
        const r = resultados.shift(); if (r instanceof Error) throw r; return r;
      } } }),
    },
    "../config/store-config": { getStoreConfig: async () => ({ nombre: "Mi tienda" }) },
  });
  return { recibirMensaje, eventos };
}
test("guarda antes de enviar dos correos con destinatarios y Reply-To correctos", async () => {
  const { recibirMensaje, eventos } = mensajesDoble();
  await recibirMensaje({ email: "cliente@example.com", mensaje: "Contenido privado" }, config());
  assert.match(eventos[0].sql, /INSERT/);
  const correos = eventos.filter(e => e.correo).map(e => e.correo);
  assert.equal(correos.length, 2);
  for (const correo of correos) {
    assert.match(correo.html, /<html/);
    assert.match(correo.html, /cid:logo-tienda/);
    assert.match(correo.html.replace(/<!--.*?-->/g, ""), /#42/);
    assert.equal(correo.attachments[0].contentId, "logo-tienda");
  }
  assert.match(correos[0].html, /Contenido privado/);
  assert.doesNotMatch(correos[1].html, /Contenido privado/);
  assert.equal(correos[0].to, "tienda@example.com");
  assert.equal(correos[0].replyTo, "cliente@example.com");
  assert.match(correos[0].text, /Contenido privado/);
  assert.equal(correos[1].to, "cliente@example.com");
  assert.equal(correos[1].replyTo, "tienda@example.com");
  assert.doesNotMatch(correos[1].text, /Contenido privado/);
  assert.deepEqual(eventos.at(-1).params, ["enviada", "enviada", 42]);
});
test("rechazo y excepción del proveedor conservan consulta y registran cada fallo", async () => {
  for (const fallo of [{ error: { name: "validation_error" } }, new Error("Red")]) {
    const { recibirMensaje, eventos } = mensajesDoble([fallo, { error: null }]);
    assert.equal(await recibirMensaje({ email: "cliente@example.com", mensaje: "Hola" }, config()), 42);
    assert.deepEqual(eventos.at(-1).params, ["error", "enviada", 42]);
  }
  const { recibirMensaje, eventos } = mensajesDoble([{ error: null }, { error: { name: "rate_limit" } }]);
  await recibirMensaje({ email: "cliente@example.com" }, config());
  assert.deepEqual(eventos.at(-1).params, ["enviada", "error", 42]);
});
test("fallo al guardar no envía correos ni confirma recepción", async () => {
  const { recibirMensaje, eventos } = mensajesDoble([], true);
  await assert.rejects(recibirMensaje({ email: "cliente@example.com" }, config()));
  assert.equal(eventos.filter(e => e.correo).length, 0);
});

test("conserva títulos originales y envía respuestas personalizadas solo a la tienda", async () => {
  const c = personalizado(campo("intereses", "checkbox", { etiqueta: "¿Qué necesitas?", opciones: ["Asesoría", "Pedido"] }));
  const { recibirMensaje, eventos } = mensajesDoble();
  const datos = validarMensaje({ email: "ana@example.com", intereses: ["Pedido"] }, c);
  await recibirMensaje(datos, c);
  const contenido = JSON.parse(eventos[0].params[0]);
  assert.equal(contenido.version, 2);
  assert.deepEqual(contenido.valores, datos);
  assert.deepEqual(contenido.campos[1], { id: "intereses", etiqueta: "¿Qué necesitas?" });
  c.formulario[1].etiqueta = "Título cambiado";
  const correos = eventos.filter(e => e.correo).map(e => e.correo);
  assert.match(correos[0].html, /¿Qué necesitas\?/);
  assert.match(correos[0].html, /Pedido/);
  assert.match(correos[0].text, /¿Qué necesitas\?:\nPedido/);
  assert.doesNotMatch(correos[1].html, /¿Qué necesitas\?/);
});

test("lista consultas antiguas y nuevas sin perder sus etiquetas ni valores", async () => {
  const valores = { email: "ana@example.com", custom: "Respuesta" };
  const campos = [{ id: "custom", etiqueta: "Pregunta anterior" }];
  const { listarMensajes } = cargar("src/contacto/mensajes.ts", {
    "../db/pool": { pool: { query: async () => [[
      { id: 2, datos: JSON.stringify({ version: 2, valores, campos }), creado_at: "2026-10-23" },
      { id: 1, datos: { email: "old@example.com", mensaje: "Hola" }, creado_at: "2026-10-22" },
    ]] } }, "../email/logo": {}, "../email/resend": {}, "../config/store-config": {},
  });
  const { mensajes } = await listarMensajes(1);
  assert.deepEqual(mensajes[0].datos, valores);
  assert.deepEqual(mensajes[0].campos, campos);
  assert.equal(mensajes[1].datos.mensaje, "Hola");
  assert.equal(mensajes[1].campos.find(c => c.id === "mensaje").etiqueta, "Mensaje");
});

const next = { NextResponse: { json: (data, init) => Response.json(data, init) } };
function publico(c = config(), limite = true) {
  let guardados = 0;
  const ruta = cargar("src/rutas/api/contacto/route.ts", {
    "next/server": next,
    "../../../contacto/config": { getContactoConfig: async () => c },
    "../../../contacto/mensajes": { recibirMensaje: async () => { guardados++; } },
    "../../../lib/rate-limit": { ipDeRequest: () => "127.0.0.1", consumirLimite: () => ({ permitido: limite, esperaSegundos: 60 }) },
  });
  return { ruta, guardados: () => guardados };
}
const request = body => new Request("https://tienda.test/api/contacto", { method: "POST", body: typeof body === "string" ? body : JSON.stringify(body) });
test("API rechaza desactivado, inválido, demasiado grande y exceso de intentos", async () => {
  assert.equal((await publico({ ...config(), activo: false }).ruta.POST(request({}))).status, 403);
  assert.equal((await publico().ruta.POST(request("{"))).status, 400);
  assert.equal((await publico().ruta.POST(request(null))).status, 400);
  assert.equal((await publico().ruta.POST(request({ mensaje: "x".repeat(32001) }))).status, 413);
  const r = await publico(config(), false).ruta.POST(request({}));
  assert.equal(r.status, 429); assert.equal(r.headers.get("Retry-After"), "60");
});
test("honeypot no guarda ni envía; consulta válida devuelve 201", async () => {
  const p = publico();
  assert.equal((await p.ruta.POST(request({ website: "spam" }))).status, 200);
  assert.equal(p.guardados(), 0);
  assert.equal((await p.ruta.POST(request({ nombre: "Ana", email: "ana@example.com", mensaje: "Hola" }))).status, 201);
  assert.equal(p.guardados(), 1);
});

test("API recibe preguntas personalizadas y rechaza opciones manipuladas", async () => {
  const c = personalizado(campo("intereses", "checkbox", { opciones: ["A", "B"] }));
  const p = publico(c);
  assert.equal((await p.ruta.POST(request({ email: "ana@example.com", intereses: ["A", "B"] }))).status, 201);
  assert.equal((await p.ruta.POST(request({ email: "ana@example.com", intereses: ["C"] }))).status, 400);
  assert.equal((await p.ruta.POST(request({ email: "ana@example.com" }))).status, 400);
  assert.equal(p.guardados(), 1);
});
test("APIs administrativas bloquean lectura y escritura sin sesión autorizada", async () => {
  const bloqueo = Response.json({ error: "No autorizado" }, { status: 403 });
  const ruta = cargar("src/rutas/api/admin/contacto/route.ts", {
    "next/server": next,
    "../../../../auth/exigirAdmin": { exigirAdmin: async () => bloqueo },
    "../../../../contacto/mensajes": {}, "../../../../db/pool": {},
  });
  assert.equal((await ruta.GET({})).status, 403);
  assert.equal((await ruta.PATCH({})).status, 403);
  const ajustes = cargar("src/rutas/api/admin/contacto/ajustes/route.ts", {
    "next/server": next,
    "../../../../../auth/exigirAdmin": { exigirAdmin: async () => bloqueo },
    "../../../../../contacto/config": {},
  });
  assert.equal((await ajustes.GET()).status, 403);
  assert.equal((await ajustes.PUT({})).status, 403);
});

test("HTML del visitante se escapa y no se reproduce en el acuse", async () => {
  const { recibirMensaje, eventos } = mensajesDoble();
  await recibirMensaje({ email: "cliente@example.com", mensaje: "<script>alert(1)</script>" }, config());
  const correos = eventos.filter(e => e.correo).map(e => e.correo);
  assert.match(correos[0].html, /&lt;script&gt;/);
  assert.doesNotMatch(correos[0].html, /<script>/);
  assert.doesNotMatch(correos[1].html, /alert\(1\)/);
});
