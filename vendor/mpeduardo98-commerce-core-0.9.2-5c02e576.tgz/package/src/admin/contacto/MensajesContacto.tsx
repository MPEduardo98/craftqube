"use client";

import { useEffect, useRef, useState, useSyncExternalStore } from "react";
import { createPortal } from "react-dom";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { CAMPOS_CONTACTO, type MensajeContacto } from "../../contacto/types";
import { Dropdown } from "../../ui/Dropdown";

const ESTADOS: Record<MensajeContacto["estado"], { label: string; color: string; fondo: string }> = {
  nuevo: { label: "Nuevo", color: "#a16207", fondo: "#fef9e7" },
  leido: { label: "Leído", color: "#525252", fondo: "#f5f5f5" },
  resuelto: { label: "Resuelto", color: "#15803d", fondo: "#f0fdf4" },
};

const ENVIOS: Record<MensajeContacto["notificacion"], string> = {
  enviada: "Enviado",
  pendiente: "Pendiente",
  error: "No enviado",
};

const suscribirNada = () => () => {};

function fecha(v: string) {
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? "Fecha no disponible" : d.toLocaleString("es-MX", {
    day: "numeric", month: "short", year: "numeric", hour: "numeric", minute: "2-digit",
  });
}

function Dato({ etiqueta, valor }: { etiqueta: string; valor: string }) {
  return <div className="min-w-0">
    <dt className="text-[11px] font-medium text-slate-500">{etiqueta}</dt>
    <dd className="mt-0.5 whitespace-pre-wrap break-words text-[13px] text-slate-800">{valor}</dd>
  </div>;
}

function Estado({ estado }: { estado: MensajeContacto["estado"] }) {
  return <span className="shrink-0 rounded-md px-2 py-0.5 text-[11px] font-medium" style={{ color: ESTADOS[estado].color, background: ESTADOS[estado].fondo }}>{ESTADOS[estado].label}</span>;
}

function DetalleContacto({ mensaje: m, saving, error, onClose, onCambiar }: {
  mensaje: MensajeContacto;
  saving: boolean;
  error: string;
  onClose: () => void;
  onCambiar: (id: number, estado: MensajeContacto["estado"]) => void;
}) {
  const dialog = useRef<HTMLDialogElement>(null);
  const reducirMovimiento = useReducedMotion();
  const campos = m.campos ?? CAMPOS_CONTACTO;
  const laterales = campos.filter(c => c.id !== "mensaje" && c.id !== "asunto" && m.datos[c.id]);

  // El diálogo nativo mantiene el foco dentro y devuelve el foco a la fila.
  // Permanece montado hasta terminar la salida, incluido el bloqueo de scroll.
  useEffect(() => {
    const elemento = dialog.current;
    if (!elemento) return;
    const focoAnterior = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const { overflow, paddingRight } = document.body.style;
    const anchoScrollbar = window.innerWidth - document.documentElement.clientWidth;
    if (anchoScrollbar > 0) {
      document.body.style.paddingRight = `${parseFloat(getComputedStyle(document.body).paddingRight) + anchoScrollbar}px`;
    }
    document.body.style.overflow = "hidden";
    elemento.showModal();
    return () => {
      elemento.close();
      document.body.style.overflow = overflow;
      document.body.style.paddingRight = paddingRight;
      if (focoAnterior?.isConnected) focoAnterior.focus({ preventScroll: true });
    };
  }, []);

  return <dialog ref={dialog} aria-labelledby="contacto-detalle-titulo"
    className="fixed inset-0 m-0 h-dvh max-h-none w-screen max-w-none overflow-hidden border-0 bg-transparent p-0 backdrop:bg-transparent"
    onCancel={e => { e.preventDefault(); onClose(); }}>
    <motion.div className="absolute inset-0" aria-hidden="true" onClick={onClose}
      style={{ background: "rgba(0,0,0,0.38)" }}
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      transition={{ duration: reducirMovimiento ? 0 : 0.28, ease: "easeOut" }} />
    <motion.div className="absolute inset-y-0 right-0 flex w-full max-w-[560px] flex-col border-l border-slate-200 bg-white"
      style={{ boxShadow: "-20px 0 60px rgba(0,0,0,0.18)" }}
      initial={{ x: reducirMovimiento ? 0 : "100%" }}
      animate={{ x: 0, transition: { duration: reducirMovimiento ? 0 : 0.38, ease: [0.22, 1, 0.36, 1] } }}
      exit={{ x: reducirMovimiento ? 0 : "100%", transition: { duration: reducirMovimiento ? 0 : 0.28, ease: [0.4, 0, 1, 1] } }}>
      <header className="flex shrink-0 items-start justify-between gap-4 border-b border-slate-200 px-6 py-5">
        <div className="min-w-0">
          <p className="text-[11px] font-medium text-slate-500">Contacto · Consulta #{m.id}</p>
          <h2 id="contacto-detalle-titulo" className="mt-1 break-words text-[20px] font-semibold tracking-tight text-slate-900">{m.datos.nombre || m.datos.email || `Consulta #${m.id}`}</h2>
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <Estado estado={m.estado} />
            <span className="text-[11px] text-slate-500">{fecha(m.creado_at)}</span>
          </div>
        </div>
        <button type="button" autoFocus onClick={onClose} aria-label="Cerrar detalle del contacto" className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-slate-200 text-slate-500 hover:bg-slate-100 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-900">
          <svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="m6 6 12 12M18 6 6 18" /></svg>
        </button>
      </header>

      <div className="min-h-0 flex-1 space-y-6 overflow-y-auto overscroll-contain px-6 py-5">
        {error && <p role="alert" className="rounded-lg bg-red-50 px-4 py-3 text-[13px] text-red-600">{error}</p>}
        <div className="flex flex-wrap items-center justify-between gap-3 text-[12px] font-medium text-slate-500">
          Estado de la consulta
          <Dropdown ariaLabel={`Estado de consulta ${m.id}`} value={m.estado} disabled={saving}
            onChange={valor => onCambiar(m.id, valor as MensajeContacto["estado"])}
            options={Object.entries(ESTADOS).map(([value, estado]) => ({ value, label: estado.label }))} />
        </div>
        {laterales.length > 0 && <section>
          <h3 className="mb-3 text-[12px] font-semibold text-slate-900">Información del contacto</h3>
          <dl className="grid min-w-0 gap-4 rounded-xl border border-slate-200 bg-slate-50 p-4 sm:grid-cols-2">
            {laterales.map(c => <Dato key={c.id} etiqueta={c.etiqueta} valor={m.datos[c.id] || ""} />)}
          </dl>
        </section>}
        {campos.filter(c => (c.id === "mensaje" || c.id === "asunto") && m.datos[c.id]).map(c => <section key={c.id} className="min-w-0">
          <h3 className="text-[12px] font-semibold text-slate-900">{c.etiqueta}</h3>
          <p className="mt-3 whitespace-pre-wrap break-words text-[13px] leading-relaxed text-slate-800">{m.datos[c.id]}</p>
        </section>)}
        <dl className="grid gap-3 border-t border-slate-100 pt-4 sm:grid-cols-2">
          <Dato etiqueta="Aviso a tienda" valor={ENVIOS[m.notificacion]} />
          <Dato etiqueta="Acuse al cliente" valor={ENVIOS[m.confirmacion]} />
        </dl>
      </div>

      {m.datos.email && <footer className="flex shrink-0 justify-end border-t border-slate-200 px-6 py-4">
        <a className="btn-primary" href={`mailto:${encodeURIComponent(m.datos.email)}?subject=${encodeURIComponent(`Re: ${m.datos.asunto?.trim() || `Consulta #${m.id}`}`)}`}>Responder por correo ↗</a>
      </footer>}
    </motion.div>
  </dialog>;
}

export function MensajesContacto() {
  const [pagina, setPagina] = useState(1);
  const [mensajes, setMensajes] = useState<MensajeContacto[]>([]);
  const [hayMas, setHayMas] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [revision, setRevision] = useState(0);
  const [saving, setSaving] = useState<number | null>(null);
  const [seleccionado, setSeleccionado] = useState<MensajeContacto | null>(null);
  const [abierto, setAbierto] = useState(false);
  const montado = useSyncExternalStore(suscribirNada, () => true, () => false);

  useEffect(() => {
    const controller = new AbortController();
    setLoading(true);
    setError("");
    fetch(`/api/admin/contacto?pagina=${pagina}`, { signal: controller.signal }).then(async res => {
      const json = await res.json();
      if (!res.ok || !json.success) throw new Error("No se pudieron cargar las consultas.");
      if (!controller.signal.aborted) {
        setMensajes(json.data.mensajes);
        setHayMas(json.data.hayMas);
      }
    }).catch(e => {
      if (!controller.signal.aborted) setError(e instanceof Error ? e.message : "Error de conexión.");
    }).finally(() => {
      if (!controller.signal.aborted) setLoading(false);
    });
    return () => controller.abort();
  }, [pagina, revision]);

  async function cambiar(id: number, estado: MensajeContacto["estado"]) {
    setSaving(id);
    setError("");
    try {
      const res = await fetch("/api/admin/contacto", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, estado }),
      });
      const json = await res.json();
      if (!res.ok || !json.success) throw new Error("No se pudo cambiar el estado.");
      setMensajes(actual => actual.map(m => m.id === id ? { ...m, estado } : m));
      setSeleccionado(actual => actual?.id === id ? { ...actual, estado } : actual);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error de conexión.");
    } finally {
      setSaving(null);
    }
  }

  return <><section className="overflow-hidden rounded-xl border border-slate-200 bg-white" style={{ boxShadow: "var(--shadow-card)" }} aria-label="Consultas recibidas">
    <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 px-5 py-4">
      <div>
        <h2 className="text-[14px] font-semibold text-slate-900">Mensajes recibidos</h2>
        <p className="mt-0.5 text-[12px] text-slate-500">Selecciona un contacto para ver su información y consulta.</p>
      </div>
      <button type="button" className="btn-secondary disabled:opacity-40" disabled={loading || saving !== null} onClick={() => setRevision(r => r + 1)}>
        <svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <path d="M20 11a8 8 0 1 0-2.3 6.7M20 4v7h-7" />
        </svg>
        Actualizar
      </button>
    </div>

    {error && <p role="alert" className="border-b border-red-200 bg-red-50 px-5 py-3 text-[13px] text-red-600">{error}</p>}

    {loading ? <div role="status" className="px-5 py-14 text-center text-[13px] text-slate-500">Cargando consultas…</div>
      : mensajes.length === 0 ? <div className="px-5 py-14 text-center">
        <p className="text-[14px] font-medium text-slate-800">{error ? "No se pudieron mostrar las consultas" : "No hay mensajes recibidos"}</p>
        <p className="mt-1 text-[13px] text-slate-500">{error ? "Vuelve a intentarlo con Actualizar." : "Las consultas del formulario aparecerán aquí."}</p>
      </div>
      : <ul className="divide-y divide-slate-200">
        {mensajes.map(m => {
          const nombre = m.datos.nombre || m.datos.email || `Consulta #${m.id}`;
          const asunto = m.datos.asunto?.trim();
          return <li key={m.id} className="min-w-0">
            <button type="button" aria-haspopup="dialog" onClick={() => { setSeleccionado(m); setAbierto(true); }}
              className="flex w-full items-center gap-4 px-5 py-4 text-left hover:bg-slate-50 focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-slate-900">
              <span className="min-w-0 flex-1">
                <span className="flex flex-wrap items-center gap-2">
                  <span className="break-words text-[14px] font-semibold text-slate-900">{nombre}</span>
                  <Estado estado={m.estado} />
                </span>
                <span className="mt-1 block truncate text-[13px] text-slate-600">{asunto || `Consulta #${m.id}`}</span>
                <span className="mt-1 block text-[11px] text-slate-500">#{m.id} · {fecha(m.creado_at)}</span>
              </span>
              <svg aria-hidden="true" className="shrink-0 text-slate-400" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="m9 5 7 7-7 7" /></svg>
            </button>
          </li>;
        })}
      </ul>}

    <div className="flex items-center justify-between gap-3 border-t border-slate-200 px-5 py-3 text-[12px] text-slate-500">
      <span>Página {pagina}</span>
      <div className="flex items-center gap-2">
        <button type="button" className="btn-secondary disabled:opacity-40" disabled={loading || saving !== null || pagina === 1} onClick={() => setPagina(p => p - 1)}>Anterior</button>
        <button type="button" className="btn-secondary disabled:opacity-40" disabled={loading || saving !== null || !hayMas} onClick={() => setPagina(p => p + 1)}>Siguiente</button>
      </div>
    </div>
  </section>
    {montado && createPortal(<AnimatePresence>
      {abierto && seleccionado && <DetalleContacto key="contacto-drawer" mensaje={seleccionado} saving={saving !== null} error={error}
        onClose={() => setAbierto(false)} onCambiar={cambiar} />}
    </AnimatePresence>, document.body)}
  </>;
}
