"use client";
import Link from "next/link";
import { useId, useState, type FormEvent } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { Dropdown } from "../../../ui/Dropdown";
import { CamposFormularioContacto } from "../../../contacto/ContactoForm";
import { TIPOS_CAMPO_CONTACTO, esCampoOpciones, obtenerCamposContacto, type CampoFormularioContacto, type ContactoConfig } from "../../../contacto/types";

const input = "mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm";
const accion = "rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-medium disabled:opacity-40";
const tiposRespuesta = TIPOS_CAMPO_CONTACTO.map(t => ({ value: t.id, label: t.etiqueta }));
const selectClassName = `${input} flex items-center justify-between gap-2 text-left`;
const selectStyle = { fontFamily: "inherit", color: "var(--color-cq-text, #0f172a)" };
const preparar = (config: ContactoConfig) => ({ ...config, formulario: obtenerCamposContacto(config) });

export function ContactoSettings({ inicial, correoConfigurado }: { inicial: ContactoConfig; correoConfigurado: boolean }) {
  const prefijo = useId();
  const reducirMovimiento = useReducedMotion();
  const [config, setConfig] = useState(() => preparar(inicial));
  const [guardado, setGuardado] = useState(() => preparar(inicial));
  const [saving, setSaving] = useState(false);
  const [aviso, setAviso] = useState("");
  const [error, setError] = useState(false);
  const [editando, setEditando] = useState<string | null>(null);
  const [vistaPrevia, setVistaPrevia] = useState(false);
  const [tipoNuevo, setTipoNuevo] = useState<CampoFormularioContacto["tipo"]>("text");

  function actualizar(id: string, cambios: Partial<CampoFormularioContacto>) {
    setConfig(actual => ({ ...actual, formulario: actual.formulario.map(c => c.id === id ? { ...c, ...cambios } : c) }));
  }
  function agregar(original?: CampoFormularioContacto) {
    if (config.formulario.length >= 30) return;
    const id = `campo_${crypto.randomUUID().replaceAll("-", "")}`;
    const campo: CampoFormularioContacto = original ? { ...original, id, etiqueta: `${original.etiqueta.slice(0, 112)} (copia)`, opciones: [...original.opciones] } : {
      id, etiqueta: "Nueva pregunta", tipo: tipoNuevo, obligatorio: false, placeholder: "", ayuda: "",
      opciones: esCampoOpciones(tipoNuevo) ? ["Opción 1", "Opción 2"] : [], max: tipoNuevo === "textarea" ? 5000 : 254,
    };
    setConfig(actual => ({ ...actual, formulario: [...actual.formulario, campo] }));
    setEditando(id);
    setAviso(original ? "Campo duplicado." : "Campo agregado. Personaliza su título y sus opciones.");
    setError(false);
  }
  function mover(indice: number, desplazamiento: number) {
    setConfig(actual => {
      const formulario = [...actual.formulario];
      [formulario[indice], formulario[indice + desplazamiento]] = [formulario[indice + desplazamiento], formulario[indice]];
      return { ...actual, formulario };
    });
  }
  async function guardar(e: FormEvent) {
    e.preventDefault(); setSaving(true); setAviso(""); setError(false);
    try {
      const res = await fetch("/api/admin/contacto/ajustes", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(config) });
      const json = await res.json();
      if (!res.ok || !json.success) throw new Error(json.error || "No se pudo guardar.");
      const nueva = preparar(json.data);
      setConfig(nueva); setGuardado(nueva); setAviso("Configuración guardada.");
    } catch (e) { setError(true); setAviso(e instanceof Error ? e.message : "Error de conexión."); }
    finally { setSaving(false); }
  }
  return <form onSubmit={guardar} className="flex min-w-0 flex-col gap-5">
    <fieldset disabled={saving} className="flex min-w-0 flex-col gap-4 rounded-xl border border-slate-200 bg-white p-5">
      <h2 className="text-base font-semibold">Página de contacto</h2>
      <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={config.activo} onChange={e => setConfig({ ...config, activo: e.target.checked })} />Activar formulario de contacto</label>
      <label className="text-sm">Título<input className={input} required maxLength={120} value={config.titulo} onChange={e => setConfig({ ...config, titulo: e.target.value })} /></label>
      <label className="text-sm">Descripción<textarea className={input} rows={3} maxLength={600} value={config.descripcion} onChange={e => setConfig({ ...config, descripcion: e.target.value })} /></label>
      <label className="text-sm">Recibir consultas en<input className={input} type="email" required={config.activo} maxLength={254} value={config.destinatario} onChange={e => setConfig({ ...config, destinatario: e.target.value })} placeholder="contacto@tutienda.com" /></label>
      <p className="text-sm text-slate-500">Recibirás todas las respuestas y podrás contestar desde tu correo. El cliente recibe un acuse de recibo.</p>
      {!correoConfigurado && <p role="status" className="text-sm text-amber-700">Falta configurar el servicio de correo de la tienda. Las consultas se conservarán en el panel.</p>}
    </fieldset>
    <fieldset disabled={saving} className="min-w-0 rounded-xl border border-slate-200 bg-white">
      <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-200 p-5">
        <div>
          <h2 className="text-base font-semibold">Tu formulario</h2>
          <p className="mt-1 text-sm text-slate-500">Elige qué preguntar y cómo quieres recibir la respuesta.</p>
        </div>
        <button type="button" className={accion} aria-pressed={vistaPrevia} onClick={() => setVistaPrevia(v => !v)}>{vistaPrevia ? "Volver al editor" : "Vista previa"}</button>
      </div>
      {vistaPrevia ? <div className="p-5">
        <p className="mb-5 text-xs text-slate-500">Así verá tu formulario el cliente. Esta vista no envía respuestas.</p>
        <div className="mx-auto max-w-xl rounded-xl border border-slate-200 p-5">
          <h3 className="break-words text-lg font-semibold">{config.titulo}</h3>
          <p className="mt-2 break-words text-sm text-slate-500">{config.descripcion}</p>
          <fieldset disabled className="mt-6 grid min-w-0 gap-5 text-sm">
            <CamposFormularioContacto campos={config.formulario} prefijo={`${prefijo}-preview`} controlClassName={input} />
            <button type="button" className="rounded-lg bg-black px-5 py-2.5 text-sm font-semibold text-white">Enviar mensaje</button>
          </fieldset>
        </div>
      </div> : <>
        <div className="flex flex-col gap-3 p-5">
          {config.formulario.map((c, indice) => {
            const abierto = editando === c.id;
            const esCorreo = c.id === "email";
            return <div key={c.id} className={`min-w-0 rounded-xl border ${abierto ? "border-slate-400" : "border-slate-200"}`}>
              <div className="flex flex-wrap items-center gap-2 p-3">
                <button type="button" aria-expanded={abierto} aria-controls={`${prefijo}-${c.id}`} onClick={() => setEditando(abierto ? null : c.id)} className="flex min-w-0 flex-1 items-center gap-3 text-left">
                  <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-xs text-slate-500">{indice + 1}</span>
                  <span className="min-w-0"><span className="block break-words text-sm font-medium">{c.etiqueta || "Pregunta sin título"}</span><span className="block text-xs text-slate-500">{TIPOS_CAMPO_CONTACTO.find(t => t.id === c.tipo)?.etiqueta} · {c.obligatorio ? "Obligatorio" : "Opcional"}</span></span>
                  <span aria-hidden="true" className="ml-auto text-slate-400">{abierto ? "−" : "+"}</span>
                </button>
                <div className="flex shrink-0 gap-1">
                  <button type="button" className={accion} aria-label={`Subir ${c.etiqueta}`} disabled={indice === 0} onClick={() => mover(indice, -1)}>↑</button>
                  <button type="button" className={accion} aria-label={`Bajar ${c.etiqueta}`} disabled={indice === config.formulario.length - 1} onClick={() => mover(indice, 1)}>↓</button>
                </div>
              </div>
              <AnimatePresence initial={false}>{abierto && <motion.div id={`${prefijo}-${c.id}`} className="grid gap-4 border-t border-slate-200 p-4"
                initial={{ opacity: 0, y: reducirMovimiento ? 0 : -4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: reducirMovimiento ? 0 : -2 }}
                transition={{ duration: reducirMovimiento ? 0 : 0.18, ease: [0.22, 1, 0.36, 1] }}>
                <div className="grid gap-4 sm:grid-cols-2">
                  <label className="text-sm">Título o pregunta<input className={input} required maxLength={120} value={c.etiqueta} onChange={e => actualizar(c.id, { etiqueta: e.target.value })} /></label>
                  <div className="min-w-0 text-sm"><span>Tipo de respuesta</span><Dropdown ariaLabel="Tipo de respuesta" triggerClassName={selectClassName} triggerStyle={selectStyle} width="100%" align="left" options={tiposRespuesta} value={c.tipo} disabled={esCorreo || saving} onChange={valor => {
                    const tipo = valor as CampoFormularioContacto["tipo"];
                    actualizar(c.id, { tipo, max: tipo === "textarea" ? 5000 : 254, opciones: esCampoOpciones(tipo) ? c.opciones.length ? c.opciones : ["Opción 1", "Opción 2"] : [] });
                  }} /></div>
                </div>
                {esCampoOpciones(c.tipo) && <label className="text-sm">Opciones<textarea className={input} rows={Math.min(7, Math.max(3, c.opciones.length))} value={c.opciones.join("\n")} onChange={e => actualizar(c.id, { opciones: e.target.value.split("\n") })} /><span className="mt-1 block text-xs text-slate-500">Una opción por línea. Hasta 30 opciones, sin repetir.</span></label>}
                {c.tipo !== "radio" && c.tipo !== "checkbox" && <label className="text-sm">Texto de ejemplo<input className={input} maxLength={200} value={c.placeholder} placeholder="Ej. Cuéntanos qué necesitas" onChange={e => actualizar(c.id, { placeholder: e.target.value })} /></label>}
                <label className="text-sm">Texto de ayuda<input className={input} maxLength={400} value={c.ayuda} placeholder="Información para ayudar al cliente a responder" onChange={e => actualizar(c.id, { ayuda: e.target.value })} /></label>
                <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={c.obligatorio} disabled={esCorreo} onChange={e => actualizar(c.id, { obligatorio: e.target.checked })} />Respuesta obligatoria</label>
                {esCorreo && <p className="text-xs text-slate-500">Este correo permite responder al cliente y enviarle su confirmación. Puedes personalizar su título y ayuda.</p>}
                <div className="flex flex-wrap gap-2 border-t border-slate-100 pt-3">
                  {!esCorreo && <button type="button" className={accion} disabled={config.formulario.length >= 30} onClick={() => agregar(c)}>Duplicar campo</button>}
                  {!esCorreo && <button type="button" className="rounded-lg px-3 py-2 text-xs font-medium text-red-600" onClick={() => {
                    setConfig(actual => ({ ...actual, formulario: actual.formulario.filter(v => v.id !== c.id) }));
                    setEditando(null);
                  }}>Eliminar campo</button>}
                </div>
              </motion.div>}</AnimatePresence>
            </div>;
          })}
        </div>
        <div className="flex flex-wrap items-end gap-3 border-t border-slate-200 bg-slate-50 p-5">
          <div className="min-w-0 flex-1 text-xs font-medium text-slate-600"><span>Agregar una pregunta</span><Dropdown ariaLabel="Agregar una pregunta" triggerClassName={selectClassName} triggerStyle={selectStyle} width="100%" align="left" placement="top" options={tiposRespuesta} value={tipoNuevo} disabled={saving} onChange={valor => setTipoNuevo(valor as CampoFormularioContacto["tipo"])} /></div>
          <button type="button" className="rounded-lg bg-black px-4 py-2.5 text-sm font-medium text-white disabled:opacity-40" disabled={config.formulario.length >= 30} onClick={() => agregar()}>+ Agregar campo</button>
          <p className="w-full text-xs text-slate-500">{config.formulario.length} de 30 campos · Usa las flechas para cambiar el orden.</p>
        </div>
      </>}
    </fieldset>
    <p role={error ? "alert" : "status"} className={`text-sm ${error ? "text-red-600" : "text-slate-600"}`}>{aviso}</p>
    <div className="flex flex-wrap items-center justify-between gap-3">
      <Link className="text-sm underline" href="/admin/contacto">Ver mensajes recibidos</Link>
      <button type="submit" disabled={saving || JSON.stringify(config) === JSON.stringify(guardado)} className="rounded-lg bg-black px-5 py-2.5 text-sm font-semibold text-white disabled:opacity-50">{saving ? "Guardando…" : "Guardar cambios"}</button>
    </div>
  </form>;
}
