// email/resend.ts
// ─────────────────────────────────────────────────────────────
// Cliente de Resend y remitente. Se resuelven en el primer envío,
// no al importar: si truena al importar, cualquier ruta que toque
// el correo (registro, pedidos…) tumba el build de una tienda que
// todavía no configura Resend.
//
// No hay remitente por defecto: cada tienda manda desde su propio
// dominio, y uno inventado aquí saldría con la marca equivocada.
// ─────────────────────────────────────────────────────────────
import { Resend } from "resend";

function requerir(nombre: string): string {
  const valor = process.env[nombre];
  if (!valor) throw new Error(`[email] Falta la variable de entorno ${nombre}.`);
  return valor;
}

let _resend: Resend | null = null;

export function getResend(): Resend {
  if (!_resend) _resend = new Resend(requerir("RESEND_API_KEY"));
  return _resend;
}

/** Remitente, p. ej. "Mi Tienda <hola@mitienda.mx>". */
export function getFromEmail(): string {
  return requerir("RESEND_FROM_EMAIL");
}

export const BASE_URL = process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3000";
