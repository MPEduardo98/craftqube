// email/templates/CuponBienvenidaEmail.tsx
import { EmailBase, EmailButton } from "./EmailBase";

export interface CuponBienvenidaProps {
  nombre:    string;
  codigo:    string;
  /** "10% de descuento", "Envío gratis"… */
  oferta:    string;
  /** "Compra mínima de $500.00" — vacío si no hay. */
  condicion: string;
  /** Fecha legible de vencimiento — vacío si no vence. */
  vence:     string;
  tiendaUrl: string;
}

const texto = { fontFamily: "'Helvetica Neue', Arial, sans-serif" } as const;

export function CuponBienvenidaEmail({
  nombre, codigo, oferta, condicion, vence, tiendaUrl, tienda,
}: CuponBienvenidaProps & { tienda: string }) {
  return (
    <EmailBase
      tienda={tienda}
      subtitulo="Tu regalo de bienvenida"
      titulo={oferta}
      footerText={`Recibiste este correo porque dejaste tu dirección en ${tienda} para recibir este cupón.`}
    >
      <p style={{ ...texto, margin: "0 0 8px 0", fontSize: "16px", color: "#1e293b", lineHeight: 1.6 }}>
        Hola, <strong style={{ color: "#0f172a" }}>{nombre}</strong>
      </p>
      <p style={{ ...texto, margin: "0 0 28px 0", fontSize: "15px", color: "#475569", lineHeight: 1.7 }}>
        Gracias por unirte. Usa este código al pagar tu pedido para obtener {oferta.toLowerCase()}.
      </p>

      <div style={{ padding: "22px 16px", border: "2px dashed #cbd5e1", borderRadius: "12px", textAlign: "center", marginBottom: "28px" }}>
        <p style={{ ...texto, margin: "0 0 8px 0", fontSize: "10px", letterSpacing: "0.14em", textTransform: "uppercase", color: "#94a3b8", fontWeight: 600 }}>
          Tu código
        </p>
        <p style={{ margin: 0, fontSize: "28px", fontWeight: 700, letterSpacing: "0.12em", color: "#0f172a", fontFamily: "monospace" }}>
          {codigo}
        </p>
      </div>

      <EmailButton href={tiendaUrl} label="Ir a la tienda →" />

      {(condicion || vence) && (
        <div style={{ padding: "14px 16px", backgroundColor: "#f8fafc", borderRadius: "8px" }}>
          {condicion && (
            <p style={{ ...texto, margin: vence ? "0 0 6px 0" : 0, fontSize: "13px", color: "#475569", lineHeight: 1.6 }}>{condicion}</p>
          )}
          {vence && (
            <p style={{ ...texto, margin: 0, fontSize: "13px", color: "#475569", lineHeight: 1.6 }}>Válido hasta el {vence}.</p>
          )}
        </div>
      )}
      <p style={{ ...texto, margin: "16px 0 0 0", fontSize: "12px", color: "#94a3b8", lineHeight: 1.6 }}>
        El código es personal: funciona al pagar con este mismo correo.
      </p>
    </EmailBase>
  );
}
