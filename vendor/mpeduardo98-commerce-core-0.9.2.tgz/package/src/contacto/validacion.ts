import { CAMPOS_CONTACTO, type ContactoConfig, type CampoContacto } from "./types";

export class ErrorContacto extends Error {}
export function objeto(v: unknown): Record<string, unknown> {
  if (!v || typeof v !== "object" || Array.isArray(v)) throw new ErrorContacto("Datos inválidos.");
  return v as Record<string, unknown>;
}
export function emailValido(v: string): boolean {
  return v.length <= 254 && /^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(v);
}
export function validarConfig(v: unknown): ContactoConfig {
  const b = objeto(v);
  if (typeof b.activo !== "boolean") throw new ErrorContacto("Estado inválido.");
  for (const [key, max] of [["titulo", 120], ["descripcion", 600], ["destinatario", 254]] as const) {
    if (typeof b[key] !== "string" || b[key].length > max) throw new ErrorContacto(`Revisa ${key}.`);
  }
  const titulo = (b.titulo as string).trim();
  const destinatario = (b.destinatario as string).trim();
  if (!titulo) throw new ErrorContacto("Escribe un título.");
  if ((b.activo || destinatario) && !emailValido(destinatario)) throw new ErrorContacto("Escribe un correo de recepción válido.");
  const reglas = objeto(b.campos);
  const campos = {} as ContactoConfig["campos"];
  for (const { id } of CAMPOS_CONTACTO) {
    const regla = reglas[id];
    if (regla !== "oculto" && regla !== "opcional" && regla !== "obligatorio") throw new ErrorContacto(`Revisa el campo ${id}.`);
    campos[id] = regla;
  }
  if (campos.email !== "obligatorio" || campos.mensaje !== "obligatorio") throw new ErrorContacto("El correo y el mensaje son obligatorios para poder responder.");
  return { activo: b.activo, titulo, descripcion: (b.descripcion as string).trim(), destinatario, campos };
}
export function validarMensaje(v: unknown, config: ContactoConfig) {
  const b = objeto(v);
  const datos: Partial<Record<CampoContacto, string>> = {};
  for (const { id, etiqueta, max } of CAMPOS_CONTACTO) {
    if (config.campos[id] === "oculto") continue;
    if (b[id] !== undefined && typeof b[id] !== "string") throw new ErrorContacto(`Revisa ${etiqueta}.`);
    const valor = ((b[id] as string | undefined) ?? "").trim();
    if (valor.length > max || /[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(valor)) throw new ErrorContacto(`Revisa ${etiqueta} (máximo ${max} caracteres).`);
    if (config.campos[id] === "obligatorio" && !valor) throw new ErrorContacto(`${etiqueta} es obligatorio.`);
    if (id === "email" && valor && !emailValido(valor)) throw new ErrorContacto("Escribe un correo válido.");
    if (valor) datos[id] = valor;
  }
  return datos;
}
