"use client";
import { useId, useRef, useState, type FormEvent } from "react";
import { CAMPOS_CONTACTO, type ContactoPublico } from "./types";

/** La tienda puede dar estilo con className o consumir /api/contacto con su propio diseño. */
export function ContactoForm({ config, className, privacidadUrl }: { config: ContactoPublico; className?: string; privacidadUrl?: string }) {
  const id = useId();
  const enviando = useRef(false);
  const [estado, setEstado] = useState<"idle" | "enviando" | "enviado" | "error">("idle");
  const [error, setError] = useState("");
  async function enviar(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (enviando.current) return;
    enviando.current = true;
    setEstado("enviando"); setError("");
    const datos = Object.fromEntries(new FormData(e.currentTarget));
    try {
      const res = await fetch("/api/contacto", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(datos) });
      const json = await res.json();
      if (!res.ok || !json.success) throw new Error(json.error || "No se pudo enviar el mensaje.");
      setEstado("enviado");
    } catch (e) { setError(e instanceof Error ? e.message : "Error de conexión."); setEstado("error"); }
    finally { enviando.current = false; }
  }
  if (!config.activo) return null;
  return <section className={className}>
    <h1>{config.titulo}</h1><p>{config.descripcion}</p>
    {estado === "enviado" ? <p role="status">Recibimos tu mensaje. Te enviaremos una confirmación por correo y responderemos pronto.</p> :
      <form onSubmit={enviar}>
        <fieldset disabled={estado === "enviando"} style={{ border: 0, padding: 0, display: "grid", gap: 16 }}>
          {CAMPOS_CONTACTO.filter(c => config.campos[c.id] !== "oculto").map(c => <label key={c.id} htmlFor={`${id}-${c.id}`} style={{ display: "grid", gap: 6 }}>
            <span>{c.etiqueta}{config.campos[c.id] === "obligatorio" ? " *" : " (opcional)"}</span>
            {c.tipo === "textarea" ? <textarea id={`${id}-${c.id}`} name={c.id} rows={6} maxLength={c.max} required={config.campos[c.id] === "obligatorio"} /> :
              <input id={`${id}-${c.id}`} name={c.id} type={c.tipo} maxLength={c.max} required={config.campos[c.id] === "obligatorio"} autoComplete={c.id === "email" ? "email" : c.id === "nombre" ? "name" : c.id === "telefono" ? "tel" : "off"} />}
          </label>)}
          <div aria-hidden="true" style={{ position: "absolute", width: 1, height: 1, overflow: "hidden", clipPath: "inset(50%)" }}>
            <label htmlFor={`${id}-website`}>Deja este campo vacío</label><input id={`${id}-website`} name="website" tabIndex={-1} autoComplete="off" />
          </div>
          {privacidadUrl && <a href={privacidadUrl}>Aviso de privacidad</a>}
          {error && <p role="alert">{error}</p>}
          <button type="submit">{estado === "enviando" ? "Enviando…" : "Enviar mensaje"}</button>
        </fieldset>
      </form>}
  </section>;
}
