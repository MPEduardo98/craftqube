export { getContactoConfig, getContactoPublico } from "./config";
export { CAMPOS_CONTACTO, CONTACTO_DEFAULT } from "./types";
export type { CampoContacto, ReglaCampo, ContactoConfig, ContactoPublico, MensajeContacto } from "./types";
