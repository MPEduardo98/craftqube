export const CAMPOS_CONTACTO = [
  { id: "nombre", etiqueta: "Nombre", tipo: "text", max: 120 },
  { id: "email", etiqueta: "Correo electrónico", tipo: "email", max: 254 },
  { id: "telefono", etiqueta: "Teléfono", tipo: "tel", max: 40 },
  { id: "empresa", etiqueta: "Empresa", tipo: "text", max: 160 },
  { id: "pedido", etiqueta: "Número de pedido", tipo: "text", max: 80 },
  { id: "asunto", etiqueta: "Asunto", tipo: "text", max: 200 },
  { id: "mensaje", etiqueta: "Mensaje", tipo: "textarea", max: 5000 },
] as const;
export type CampoContacto = typeof CAMPOS_CONTACTO[number]["id"];
export type ReglaCampo = "oculto" | "opcional" | "obligatorio";
export interface ContactoPublico {
  activo: boolean;
  titulo: string;
  descripcion: string;
  campos: Record<CampoContacto, ReglaCampo>;
}
export interface ContactoConfig extends ContactoPublico { destinatario: string }
export const CONTACTO_DEFAULT: ContactoConfig = {
  activo: false, titulo: "Contáctanos", descripcion: "Envíanos tu consulta y nos pondremos en contacto contigo.", destinatario: "",
  campos: { nombre: "obligatorio", email: "obligatorio", telefono: "opcional", empresa: "oculto", pedido: "oculto", asunto: "opcional", mensaje: "obligatorio" },
};
export interface MensajeContacto {
  id: number;
  datos: Partial<Record<CampoContacto, string>>;
  estado: "nuevo" | "leido" | "resuelto";
  notificacion: "pendiente" | "enviada" | "error";
  confirmacion: "pendiente" | "enviada" | "error";
  creado_at: string;
}
