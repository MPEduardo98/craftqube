// resenas/config.ts
// ─────────────────────────────────────────────────────────────
// Ajustes de reseñas (tabla `configuracion`). Se leen en cada
// listado del catálogo, así que van memoizados con un TTL corto,
// igual que getStoreConfig.
//
// Default apagado: una tienda sin la clave no muestra estrellas
// vacías ni acepta reseñas hasta que las active en el panel.
// ─────────────────────────────────────────────────────────────
import { pool }               from "../db/pool";
import type { RowDataPacket } from "mysql2";
import type { ResenasConfig } from "./types";

const DEFAULTS: ResenasConfig = { activas: false, moderacion: "auto" };
const TTL_MS = 30_000;

let cache: { value: ResenasConfig; at: number } | null = null;

export async function getResenasConfig(): Promise<ResenasConfig> {
  if (cache && Date.now() - cache.at < TTL_MS) return cache.value;
  try {
    const [rows] = await pool.query<RowDataPacket[]>(
      "SELECT clave, valor FROM configuracion WHERE clave IN ('resenas_activas','resenas_moderacion')"
    );
    const map = new Map(rows.map((r) => [r.clave as string, String(r.valor ?? "")]));
    const value: ResenasConfig = {
      activas:    map.get("resenas_activas") === "1",
      moderacion: map.get("resenas_moderacion") === "manual" ? "manual" : "auto",
    };
    cache = { value, at: Date.now() };
    return value;
  } catch (err) {
    console.error("[getResenasConfig]", err);
    return DEFAULTS;
  }
}

export async function setResenasConfig(patch: Partial<ResenasConfig>): Promise<void> {
  const entries: [string, string][] = [];
  if (patch.activas    !== undefined) entries.push(["resenas_activas", patch.activas ? "1" : "0"]);
  if (patch.moderacion !== undefined) entries.push(["resenas_moderacion", patch.moderacion]);

  for (const [clave, valor] of entries) {
    await pool.execute(
      `INSERT INTO configuracion (clave, valor) VALUES (?, ?)
       ON DUPLICATE KEY UPDATE valor = VALUES(valor)`,
      [clave, valor]
    );
  }
  cache = null;
}
