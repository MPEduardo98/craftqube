// resenas/cliente.ts
// ─────────────────────────────────────────────────────────────
// Ayudas de NAVEGADOR para el formulario de reseña de la tienda.
// No importa nada de servidor: se puede usar en "use client".
//
// Por qué comprimir aquí: en Vercel el cuerpo de una petición no
// pasa de 4.5 MB, y tres fotos de celular fácilmente pesan 15 MB.
// Se reducen a 1600 px en JPEG antes de enviarlas; el servidor igual
// las vuelve a procesar (no confía en lo que llega).
// ─────────────────────────────────────────────────────────────
import { LIMITES_RESENA } from "./limites";
import type { ResenaEstado } from "./types";

const LADO_MAX = 1600;

/** Reduce una foto a 1600 px y la pasa a JPEG. Si no se puede, devuelve el archivo tal cual. */
export async function comprimirImagen(archivo: File, calidad = 0.85): Promise<File> {
  try {
    const bmp   = await createImageBitmap(archivo, { imageOrientation: "from-image" });
    const escala = Math.min(1, LADO_MAX / Math.max(bmp.width, bmp.height));
    const w = Math.round(bmp.width * escala);
    const h = Math.round(bmp.height * escala);

    const canvas = document.createElement("canvas");
    canvas.width = w; canvas.height = h;
    const ctx = canvas.getContext("2d");
    if (!ctx) return archivo;
    ctx.drawImage(bmp, 0, 0, w, h);
    bmp.close();

    const blob = await new Promise<Blob | null>((ok) => canvas.toBlob(ok, "image/jpeg", calidad));
    if (!blob) return archivo;
    const nombre = archivo.name.replace(/\.[^.]+$/, "") + ".jpg";
    return new File([blob], nombre, { type: "image/jpeg" });
  } catch {
    return archivo;
  }
}

export interface EnviarResenaDatos {
  productoId:   number;
  /** 1 a 5 */
  calificacion: number;
  titulo?:      string;
  comentario:   string;
  /** 0 a 3 fotos, tal como las eligió el cliente: aquí se comprimen. */
  imagenes?:    File[];
}

export type EnviarResenaResultado =
  | { ok: true;  id: number; estado: ResenaEstado }
  | { ok: false; error: string };

/**
 * Comprime las fotos y manda la reseña a POST /api/resenas.
 * estado "pendiente" = la tienda la revisa antes de publicarla.
 */
export async function enviarResena(datos: EnviarResenaDatos): Promise<EnviarResenaResultado> {
  const imagenes = datos.imagenes ?? [];
  if (imagenes.length > LIMITES_RESENA.imagenes) {
    return { ok: false, error: `Puedes subir hasta ${LIMITES_RESENA.imagenes} imágenes` };
  }

  const fd = new FormData();
  fd.set("producto_id",  String(datos.productoId));
  fd.set("calificacion", String(datos.calificacion));
  fd.set("titulo",       datos.titulo ?? "");
  fd.set("comentario",   datos.comentario);
  for (const f of await Promise.all(imagenes.map((f) => comprimirImagen(f)))) {
    fd.append("imagenes", f);
  }

  try {
    const res  = await fetch("/api/resenas", { method: "POST", body: fd });
    const json = await res.json().catch(() => null);
    if (json?.success) return { ok: true, id: json.data.id, estado: json.data.estado };
    if (res.status === 413) return { ok: false, error: "Las imágenes pesan demasiado" };
    return { ok: false, error: json?.error ?? "No se pudo enviar la reseña" };
  } catch {
    return { ok: false, error: "Error de red al enviar la reseña" };
  }
}
