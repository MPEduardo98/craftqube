// resenas/sesion.ts
// El cliente de la sesión activa, con lo que necesitan las reseñas.
import { getSessionUser }     from "../auth/getSessionUser";
import type { ClienteSesion } from "./elegibilidad";

export async function clienteActual(): Promise<ClienteSesion | null> {
  const u = await getSessionUser();
  if (!u) return null;
  const extra = u as { nombre?: string | null; apellido?: string | null };
  return {
    id:            u.id,
    email:         u.email,
    emailVerified: u.emailVerified,
    nombre:        extra.nombre ?? u.name,
    apellido:      extra.apellido ?? null,
  };
}
