// resenas/consultas.ts
// ─────────────────────────────────────────────────────────────
// Lecturas públicas: resumen de estrellas y listado paginado de
// un producto. Sólo cuentan las reseñas APROBADAS: una pendiente
// o rechazada no mueve el promedio ni aparece en la tienda.
// ─────────────────────────────────────────────────────────────
import { pool }               from "../db/pool";
import type { RowDataPacket } from "mysql2";
import type {
  ResenaPublica, ResumenResenas, ResenasOrden,
} from "./types";

/** Columnas que se pueden mostrar al público (sin email ni ids). */
export const COLUMNAS_PUBLICAS = `
  r.id, r.nombre, r.calificacion, r.titulo, r.cuerpo AS comentario,
  r.imagenes, r.pedido_item_id, r.respuesta_tienda, r.created_at`;

/** El driver devuelve el JSON como string o ya parseado, según la versión. */
export function parsearImagenes(v: unknown): string[] {
  let arr: unknown = v;
  if (typeof v === "string") {
    try { arr = JSON.parse(v); } catch { return []; }
  }
  return Array.isArray(arr) ? arr.filter((x): x is string => typeof x === "string") : [];
}

export function filaAPublica(r: RowDataPacket): ResenaPublica {
  return {
    id:                Number(r.id),
    nombre:            String(r.nombre),
    calificacion:      Number(r.calificacion),
    titulo:            r.titulo ?? null,
    comentario:        r.comentario ?? "",
    imagenes:          parsearImagenes(r.imagenes),
    compra_verificada: r.pedido_item_id != null,
    respuesta_tienda:  r.respuesta_tienda ?? null,
    created_at:        new Date(r.created_at).toISOString(),
  };
}

/** "Eduardo Martínez" → "Eduardo M.": se publica sin el apellido completo. */
export function nombrePublico(nombre?: string | null, apellido?: string | null): string {
  const n = (nombre ?? "").trim().split(/\s+/)[0] ?? "";
  const a = (apellido ?? "").trim();
  if (!n) return "Cliente";
  return a ? `${n} ${a.charAt(0).toUpperCase()}.` : n;
}

export async function getResumenResenas(productoId: number): Promise<ResumenResenas> {
  const [rows] = await pool.execute<RowDataPacket[]>(
    `SELECT calificacion, COUNT(*) AS n,
            SUM(imagenes IS NOT NULL AND JSON_LENGTH(imagenes) > 0) AS fotos
     FROM \`reseñas\`
     WHERE producto_id = ? AND estado = 'aprobada'
     GROUP BY calificacion`,
    [productoId]
  );

  const distribucion = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 } as ResumenResenas["distribucion"];
  let total = 0, suma = 0, conFotos = 0;
  for (const r of rows) {
    const c = Number(r.calificacion) as 1 | 2 | 3 | 4 | 5;
    const n = Number(r.n);
    if (!(c in distribucion)) continue;
    distribucion[c] = n;
    total    += n;
    suma     += c * n;
    conFotos += Number(r.fotos ?? 0);
  }

  return {
    promedio: total ? Math.round((suma / total) * 10) / 10 : 0,
    total,
    distribucion,
    con_fotos: conFotos,
  };
}

export interface ListarResenasOpciones {
  productoId: number;
  page?:      number;
  limit?:     number;
  orden?:     ResenasOrden;
  /** Sólo reseñas con estas estrellas (1-5). */
  estrellas?: number | null;
  /** Sólo reseñas con al menos una foto. */
  conFotos?:  boolean;
}

const ORDEN_SQL: Record<ResenasOrden, string> = {
  recientes: "r.created_at DESC, r.id DESC",
  mejores:   "r.calificacion DESC, r.created_at DESC",
  peores:    "r.calificacion ASC, r.created_at DESC",
};

export async function listarResenas({
  productoId, page = 1, limit = 10, orden = "recientes", estrellas = null, conFotos = false,
}: ListarResenasOpciones): Promise<{ resenas: ResenaPublica[]; total: number; pages: number }> {
  const safeLimit = Math.min(50, Math.max(1, Math.floor(limit)));
  const safePage  = Math.max(1, Math.floor(page));

  const wheres = ["r.producto_id = ?", "r.estado = 'aprobada'"];
  const params: (string | number)[] = [productoId];
  if (estrellas && estrellas >= 1 && estrellas <= 5) {
    wheres.push("r.calificacion = ?");
    params.push(Math.floor(estrellas));
  }
  if (conFotos) wheres.push("r.imagenes IS NOT NULL AND JSON_LENGTH(r.imagenes) > 0");
  const where = wheres.join(" AND ");

  const [[{ total }]] = await pool.execute<RowDataPacket[]>(
    `SELECT COUNT(*) AS total FROM \`reseñas\` r WHERE ${where}`, params
  ) as [RowDataPacket[], unknown];

  const [rows] = await pool.query<RowDataPacket[]>(
    `SELECT ${COLUMNAS_PUBLICAS}
     FROM \`reseñas\` r
     WHERE ${where}
     ORDER BY ${ORDEN_SQL[orden] ?? ORDEN_SQL.recientes}
     LIMIT ? OFFSET ?`,
    [...params, safeLimit, (safePage - 1) * safeLimit]
  );

  const n = Number(total);
  return { resenas: rows.map(filaAPublica), total: n, pages: Math.ceil(n / safeLimit) };
}
