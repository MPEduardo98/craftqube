// resenas/elegibilidad.ts
// ─────────────────────────────────────────────────────────────
// Compra verificada: sólo reseña quien compró. Es lo que evita las
// reseñas falsas, así que la regla vive aquí, en el servidor, y la
// usan tanto la API de crear como la de "¿puedo reseñar?".
//
// Cuenta como compra un pedido PAGADO (de pago_recibido en adelante)
// que no se canceló ni se reembolsó, con al menos una pieza de ese
// producto sin reembolsar. El pedido tiene que ser del cliente: por
// su usuario_id o, si compró como invitado, por su email — sólo si
// ese email ya está verificado, para que nadie se apropie de las
// compras de otro registrándose con su correo.
// ─────────────────────────────────────────────────────────────
import { pool }               from "../db/pool";
import type { RowDataPacket } from "mysql2";
import { getResenasConfig }   from "./config";
import { COLUMNAS_PUBLICAS, filaAPublica } from "./consultas";
import type {
  ElegibilidadResena, ResenaEstado, ResenaPendiente,
} from "./types";

/** Estados de pedido que cuentan como compra hecha. */
export const ESTADOS_COMPRA = ["pago_recibido", "en_proceso", "listo_envio", "enviado", "entregado"] as const;
const ESTADOS_SQL = ESTADOS_COMPRA.map((e) => `'${e}'`).join(",");

/** Lo mínimo que hace falta del usuario de la sesión. */
export interface ClienteSesion {
  id:             string | number;
  email:          string;
  emailVerified?: boolean | null;
  nombre?:        string | null;
  apellido?:      string | null;
}

/** WHERE que liga el pedido `p` con el cliente (usuario o invitado verificado). */
function condicionCliente(c: ClienteSesion): { sql: string; params: (string | number)[] } {
  if (c.emailVerified) {
    return {
      sql:    "(p.usuario_id = ? OR (p.usuario_id IS NULL AND p.email = ?))",
      params: [Number(c.id), c.email],
    };
  }
  return { sql: "p.usuario_id = ?", params: [Number(c.id)] };
}

/** id del pedido_item que prueba la compra, o null si no la hay. */
export async function buscarCompra(c: ClienteSesion, productoId: number): Promise<number | null> {
  const cli = condicionCliente(c);
  const [rows] = await pool.execute<RowDataPacket[]>(
    `SELECT pi.id
     FROM pedido_items pi
     JOIN pedidos p            ON p.id  = pi.pedido_id
     JOIN producto_variantes v ON v.id  = pi.variante_id
     WHERE v.producto_id = ?
       AND p.estado IN (${ESTADOS_SQL})
       AND pi.cantidad_reembolsada < pi.cantidad
       AND ${cli.sql}
     ORDER BY p.created_at DESC
     LIMIT 1`,
    [productoId, ...cli.params]
  );
  return rows[0] ? Number(rows[0].id) : null;
}

export async function getElegibilidad(
  c: ClienteSesion | null, productoId: number
): Promise<ElegibilidadResena> {
  const { activas } = await getResenasConfig();
  if (!activas) return { puede: false, motivo: "desactivadas" };
  if (!c)       return { puede: false, motivo: "sin_sesion" };

  const [propia] = await pool.execute<RowDataPacket[]>(
    `SELECT ${COLUMNAS_PUBLICAS}, r.estado
     FROM \`reseñas\` r WHERE r.producto_id = ? AND r.usuario_id = ? LIMIT 1`,
    [productoId, Number(c.id)]
  );
  if (propia[0]) {
    return {
      puede:  false,
      motivo: "ya_reseno",
      resena: { ...filaAPublica(propia[0]), estado: propia[0].estado as ResenaEstado },
    };
  }

  const compra = await buscarCompra(c, productoId);
  return compra ? { puede: true, motivo: null } : { puede: false, motivo: "sin_compra" };
}

/** Productos que el cliente compró y todavía no reseña, del más reciente al más viejo. */
export async function getResenasPendientes(c: ClienteSesion): Promise<ResenaPendiente[]> {
  const cli = condicionCliente(c);
  const [rows] = await pool.execute<RowDataPacket[]>(
    `SELECT
       pr.id AS producto_id, pr.titulo, pr.slug,
       MAX(p.created_at) AS comprado_en,
       (SELECT url FROM producto_imagenes
         WHERE producto_id = pr.id AND variante_id IS NULL
         ORDER BY orden ASC, id ASC LIMIT 1) AS imagen_url
     FROM pedido_items pi
     JOIN pedidos p            ON p.id  = pi.pedido_id
     JOIN producto_variantes v ON v.id  = pi.variante_id
     JOIN productos pr         ON pr.id = v.producto_id
     WHERE p.estado IN (${ESTADOS_SQL})
       AND pi.cantidad_reembolsada < pi.cantidad
       AND pr.estado = 'activo' AND pr.deleted_at IS NULL
       AND ${cli.sql}
       AND NOT EXISTS (
         SELECT 1 FROM \`reseñas\` r WHERE r.producto_id = pr.id AND r.usuario_id = ?
       )
     GROUP BY pr.id, pr.titulo, pr.slug
     ORDER BY comprado_en DESC
     LIMIT 50`,
    [...cli.params, Number(c.id)]
  );
  return rows.map((r) => ({
    producto_id: Number(r.producto_id),
    titulo:      r.titulo,
    slug:        r.slug,
    imagen_url:  r.imagen_url ?? null,
    comprado_en: new Date(r.comprado_en).toISOString(),
  }));
}
