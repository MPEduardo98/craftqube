// resenas/types.ts
// ─────────────────────────────────────────────────────────────
// Tipos de las reseñas de productos. Sin dependencias: los usan
// el servidor, el panel y el frontend de la tienda.
// ─────────────────────────────────────────────────────────────

export type ResenaEstado = "pendiente" | "aprobada" | "rechazada";

/** auto: se publican al enviarse. manual: esperan aprobación en el panel. */
export type ResenaModeracion = "auto" | "manual";

export interface ResenasConfig {
  activas:    boolean;
  moderacion: ResenaModeracion;
}

/** Reseña tal como la ve el público (sin email ni ids internos). */
export interface ResenaPublica {
  id:               number;
  /** "Eduardo M." — nombre y la inicial del apellido. */
  nombre:           string;
  calificacion:     number;
  titulo:           string | null;
  comentario:       string;
  /** URLs del CDN, 0 a 3. */
  imagenes:         string[];
  /** Siempre true hoy: sólo se aceptan reseñas con compra. */
  compra_verificada: boolean;
  respuesta_tienda: string | null;
  created_at:       string;
}

/** Resumen tipo Amazon: promedio, total y barras por estrella. */
export interface ResumenResenas {
  /** Promedio con un decimal; 0 si no hay reseñas. */
  promedio:     number;
  total:        number;
  /** Cuántas reseñas tiene cada estrella: { 5: 12, 4: 3, … }. */
  distribucion: Record<1 | 2 | 3 | 4 | 5, number>;
  /** Reseñas que traen al menos una foto. */
  con_fotos:    number;
}

export type ResenasOrden = "recientes" | "mejores" | "peores";

/**
 * Por qué un cliente no puede reseñar un producto.
 * - desactivadas: la tienda apagó las reseñas.
 * - sin_sesion:   hay que iniciar sesión.
 * - sin_compra:   no hay un pedido pagado con ese producto.
 * - ya_reseno:    ya dejó su reseña (sólo una por producto).
 */
export type MotivoNoResena = "desactivadas" | "sin_sesion" | "sin_compra" | "ya_reseno";

export interface ElegibilidadResena {
  puede:   boolean;
  motivo:  MotivoNoResena | null;
  /** La reseña que ya dejó, si motivo = ya_reseno (con su estado). */
  resena?: ResenaPublica & { estado: ResenaEstado };
}

/** Producto comprado que el cliente aún no reseña (pantalla "Opina sobre tus compras"). */
export interface ResenaPendiente {
  producto_id:   number;
  titulo:        string;
  slug:          string;
  imagen_url:    string | null;
  comprado_en:   string;
}

/** Fila del panel admin. */
export interface ResenaAdmin extends ResenaPublica {
  estado:          ResenaEstado;
  email:           string | null;
  usuario_id:      number | null;
  producto_id:     number;
  producto_titulo: string;
  producto_slug:   string;
  pedido_numero:   string | null;
}
