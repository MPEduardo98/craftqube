// resenas/limites.ts
// Límites de una reseña. Sin dependencias: el servidor los hace
// cumplir y el frontend los usa para validar antes de enviar.
export const LIMITES_RESENA = {
  titulo:        120,
  comentarioMin: 10,
  comentarioMax: 2000,
  imagenes:      3,
} as const;
