// resenas/imagenes.ts
// ─────────────────────────────────────────────────────────────
// Fotos de las reseñas. Las sube un cliente cualquiera, así que
// no se guarda el archivo tal cual: se decodifica y se vuelve a
// codificar con sharp.
//
//   - Si no es una imagen de verdad, sharp falla y se rechaza
//     (la extensión o el Content-Type no prueban nada).
//   - Se endereza según la orientación EXIF y se reduce a 1600 px.
//   - Sale en WebP SIN metadatos: las fotos de celular traen la
//     ubicación GPS de la casa del cliente, y esto se publica.
// ─────────────────────────────────────────────────────────────
import sharp           from "sharp";
import { randomUUID }  from "node:crypto";
import { uploadToR2, deleteFromR2, keyFromUrl } from "../media/r2";

/** Por archivo, antes de procesar. En Vercel el cuerpo entero no pasa de 4.5 MB. */
export const MAX_BYTES_IMAGEN = 8 * 1024 * 1024;

const FORMATOS = new Set(["jpeg", "png", "webp", "avif", "heif", "gif"]);
const LADO_MAX = 1600;
const PREFIJO  = "resenas/";

export class ImagenInvalida extends Error {}

/** Normaliza y sube una foto. Devuelve la URL pública. */
export async function subirImagenResena(productoId: number, archivo: File): Promise<string> {
  if (archivo.size > MAX_BYTES_IMAGEN) {
    throw new ImagenInvalida(`Cada imagen puede pesar hasta ${MAX_BYTES_IMAGEN / 1024 / 1024} MB`);
  }
  const entrada = Buffer.from(await archivo.arrayBuffer());

  let salida: Buffer;
  try {
    const img = sharp(entrada, { limitInputPixels: 50_000_000, animated: false });
    const { format } = await img.metadata();
    if (!format || !FORMATOS.has(format)) throw new Error(`formato ${format}`);
    salida = await img
      .rotate()
      .resize({ width: LADO_MAX, height: LADO_MAX, fit: "inside", withoutEnlargement: true })
      .webp({ quality: 82 })
      .toBuffer();
  } catch {
    throw new ImagenInvalida("Una de las imágenes no es válida. Usa JPG, PNG o WebP.");
  }

  return uploadToR2(`${PREFIJO}${productoId}/${randomUUID()}.webp`, salida, "image/webp");
}

/** Borra fotos de reseñas del bucket. Nunca toca nada fuera de resenas/. */
export async function borrarImagenesResena(urls: string[]): Promise<void> {
  await Promise.all(urls.map(async (url) => {
    const key = keyFromUrl(url);
    if (!key.startsWith(PREFIJO) || key.includes("..")) return;
    try { await deleteFromR2(key); }
    catch (err) { console.error("[borrarImagenesResena]", key, err); }
  }));
}
