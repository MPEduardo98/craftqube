// resenas/crear.ts
// ─────────────────────────────────────────────────────────────
// Alta de una reseña. Todo se valida aquí aunque el frontend ya
// valide: la API es alcanzable sin pasar por la pantalla.
//
// Orden: ajustes → campos → compra verificada → fotos → INSERT.
// Las fotos se suben al final para no dejar basura en el bucket
// por una reseña que iba a rechazarse de todos modos; si el INSERT
// falla (p. ej. doble clic que choca con la llave única), se borran.
// ─────────────────────────────────────────────────────────────
import { pool }                  from "../db/pool";
import type { ResultSetHeader }  from "mysql2";
import { getResenasConfig }      from "./config";
import { buscarCompra, type ClienteSesion } from "./elegibilidad";
import { nombrePublico }         from "./consultas";
import {
  subirImagenResena, borrarImagenesResena, ImagenInvalida,
}                                from "./imagenes";
import { LIMITES_RESENA }        from "./limites";
import type { ResenaEstado }     from "./types";

/** Error con mensaje para el cliente y el status HTTP que le toca. */
export class ErrorResena extends Error {
  constructor(message: string, public status = 400) { super(message); }
}

export interface NuevaResena {
  productoId:   number;
  calificacion: number;
  titulo?:      string | null;
  comentario:   string;
  imagenes:     File[];
}

export async function crearResena(
  c: ClienteSesion, datos: NuevaResena
): Promise<{ id: number; estado: ResenaEstado }> {
  const cfg = await getResenasConfig();
  if (!cfg.activas) throw new ErrorResena("Las reseñas no están disponibles", 403);

  // ── Campos ─────────────────────────────────────────────────
  const calificacion = Number(datos.calificacion);
  if (!Number.isInteger(calificacion) || calificacion < 1 || calificacion > 5) {
    throw new ErrorResena("La calificación va de 1 a 5 estrellas");
  }
  const titulo = (datos.titulo ?? "").trim();
  if (titulo.length > LIMITES_RESENA.titulo) {
    throw new ErrorResena(`El título admite hasta ${LIMITES_RESENA.titulo} caracteres`);
  }
  const comentario = (datos.comentario ?? "").trim();
  if (comentario.length < LIMITES_RESENA.comentarioMin) {
    throw new ErrorResena(`Cuéntanos un poco más: mínimo ${LIMITES_RESENA.comentarioMin} caracteres`);
  }
  if (comentario.length > LIMITES_RESENA.comentarioMax) {
    throw new ErrorResena(`El comentario admite hasta ${LIMITES_RESENA.comentarioMax} caracteres`);
  }
  if (datos.imagenes.length > LIMITES_RESENA.imagenes) {
    throw new ErrorResena(`Puedes subir hasta ${LIMITES_RESENA.imagenes} imágenes`);
  }

  // ── Compra verificada ──────────────────────────────────────
  const pedidoItemId = await buscarCompra(c, datos.productoId);
  if (!pedidoItemId) {
    throw new ErrorResena("Sólo puedes reseñar productos que compraste", 403);
  }

  // ── Fotos ──────────────────────────────────────────────────
  const urls: string[] = [];
  try {
    for (const f of datos.imagenes) urls.push(await subirImagenResena(datos.productoId, f));
  } catch (err) {
    await borrarImagenesResena(urls);
    if (err instanceof ImagenInvalida) throw new ErrorResena(err.message);
    throw err;
  }

  // ── Alta ───────────────────────────────────────────────────
  const estado: ResenaEstado = cfg.moderacion === "manual" ? "pendiente" : "aprobada";
  try {
    const [res] = await pool.execute<ResultSetHeader>(
      `INSERT INTO \`reseñas\`
         (producto_id, usuario_id, pedido_item_id, nombre, email,
          calificacion, titulo, cuerpo, imagenes, estado)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        datos.productoId, Number(c.id), pedidoItemId,
        nombrePublico(c.nombre, c.apellido), c.email,
        calificacion, titulo || null, comentario,
        urls.length ? JSON.stringify(urls) : null, estado,
      ]
    );
    return { id: res.insertId, estado };
  } catch (err) {
    await borrarImagenesResena(urls);
    if ((err as { code?: string }).code === "ER_DUP_ENTRY") {
      throw new ErrorResena("Ya dejaste una reseña de este producto", 409);
    }
    throw err;
  }
}
