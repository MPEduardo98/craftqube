// Carrito. El estado vive en el cliente; el precio final lo fija el
// servidor al cobrar.
export { CartProvider, useCart } from "./context/CartContext";
export * from "./types/cart";
