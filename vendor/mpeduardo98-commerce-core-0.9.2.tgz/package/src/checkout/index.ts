// Flujo de compra: contacto, envio, pago y confirmacion.
// Aqui solo va la LOGICA (estado del checkout, cotizacion de envio,
// validaciones, tipos). Las pantallas son diseno y cada tienda hace
// las suyas encima de useCheckout().
export { CheckoutProvider, useCheckout } from "./context/CheckoutContext";
export * from "./lib/cotizarEnvio";
export * from "./lib/validaciones";
export * from "./types";
