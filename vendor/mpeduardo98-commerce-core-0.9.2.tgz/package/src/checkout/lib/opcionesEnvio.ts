// checkout/lib/opcionesEnvio.ts
// ─────────────────────────────────────────────────────────────
// Opciones de envío que ve el cliente, según el modo de la tienda:
//
//   dinamico → una sola opción con el cálculo por guías/flete
//              (cotizarEnvioServer).
//   fijo     → una opción por paquetería activa que tenga precio
//              para la zona del estado de destino.
//
// En los dos modos, si el subtotal llega a `envio_gratis_desde`,
// las opciones salen en $0 (con su precio original para tacharlo).
//
// Sólo servidor: lo usa calcularTotales, que es quien decide lo que
// se cobra. Nada de esto se acepta desde el navegador.
// ─────────────────────────────────────────────────────────────
import { pool }                  from "../../db/pool";
import type { RowDataPacket }    from "mysql2";
import { cotizarEnvioServer, type ItemCotizable } from "./cotizarEnvioServer";
import type { EnvioModo, OpcionEnvioCheckout } from "../types";

const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

export interface OpcionesEnvio {
  modo:         EnvioModo;
  /** Subtotal desde el que el envío es gratis; null = sin envío gratis. */
  gratis_desde: number | null;
  opciones:     OpcionEnvioCheckout[];
}

/** Modo y umbral de envío gratis (configuracion). */
export async function leerConfigEnvio(): Promise<{ modo: EnvioModo; gratis_desde: number | null }> {
  const [rows] = await pool.execute<RowDataPacket[]>(
    "SELECT clave, valor FROM configuracion WHERE clave IN ('envio_modo','envio_gratis_desde')"
  );
  const cfg = new Map(rows.map((r) => [r.clave as string, String(r.valor ?? "")]));
  const umbral = Number(cfg.get("envio_gratis_desde"));
  return {
    modo:         cfg.get("envio_modo") === "fijo" ? "fijo" : "dinamico",
    gratis_desde: cfg.get("envio_gratis_desde")?.trim() && Number.isFinite(umbral) && umbral > 0 ? umbral : null,
  };
}

export async function obtenerOpcionesEnvio(
  estado:   string,
  items:    ItemCotizable[],
  subtotal: number,
): Promise<OpcionesEnvio> {
  const { modo, gratis_desde } = await leerConfigEnvio();
  const gratis = gratis_desde !== null && subtotal >= gratis_desde;

  const aOpcion = (o: Omit<OpcionEnvioCheckout, "precio" | "precio_original" | "gratis">, precio: number): OpcionEnvioCheckout => ({
    ...o,
    precio:          gratis ? 0 : round2(precio),
    precio_original: round2(precio),
    gratis,
  });

  if (modo === "dinamico") {
    const cot = await cotizarEnvioServer(estado, items);
    return {
      modo, gratis_desde,
      opciones: cot
        ? [aOpcion({ id: null, nombre: "Envío estándar", logo_url: null, dias_min: null, dias_max: null }, cot.costo_total)]
        : [],
    };
  }

  // ── Precio fijo: paqueterías con precio en la zona del estado ──
  // Sin zona para el estado no hay opciones: con precios por zona, un
  // estado sin zona es uno al que la tienda no envía.
  const [rows] = await pool.execute<RowDataPacket[]>(
    `SELECT p.id, p.nombre, p.logo_url, p.dias_min, p.dias_max, pp.precio
     FROM zona_estados ze
     INNER JOIN zonas_envio z         ON z.id = ze.zona_id AND z.activa = 1
     INNER JOIN paqueteria_precios pp ON pp.zona_id = z.id
     INNER JOIN paqueterias p         ON p.id = pp.paqueteria_id AND p.activa = 1
     WHERE ze.estado = ?
     ORDER BY pp.precio ASC, p.orden ASC, p.id ASC`,
    [estado]
  );

  return {
    modo, gratis_desde,
    opciones: rows.map((r) => aOpcion({
      id:       Number(r.id),
      nombre:   String(r.nombre),
      logo_url: (r.logo_url as string | null) || null,
      dias_min: r.dias_min == null ? null : Number(r.dias_min),
      dias_max: r.dias_max == null ? null : Number(r.dias_max),
    }, Number(r.precio))),
  };
}
