// features/checkout/context/CheckoutContext.tsx
// ─────────────────────────────────────────────────────────────
// Estado compartido del checkout. Antes vivía dentro de un único
// componente que pintaba los cuatro pasos; ahora cada paso es una
// página, así que el estado sube al layout —que Next conserva
// entre rutas hermanas— y se respalda en sessionStorage para que
// un F5 no borre lo que el comprador ya escribió.
//
// sessionStorage y no localStorage a propósito: el borrador muere
// con la pestaña. Del pago nunca se guarda nada sensible: número,
// vencimiento y CVC viven sólo dentro de los iframes de Stripe.
// ─────────────────────────────────────────────────────────────
"use client";

import {
  createContext, useContext, useState, useCallback, useEffect, useRef,
  type ReactNode,
} from "react";
import { useCart }      from "../../cart/context/CartContext";
import { useAuth }      from "../../auth/AuthContext";
import { useAlert }     from "../../context/AlertContext";
import { formatMoneda } from "../../lib/format";
import type {
  CheckoutFormData, DatosContacto, DatosEnvio, DatosPago,
} from "../types";
import type { ResultadoPago, EnvioModo, OpcionEnvioCheckout } from "../types";

/* ── Resumen calculado en servidor ───────────────────────── */
export interface ResumenCheckout {
  subtotal:    number;
  descuento:   number;
  costo_envio: number;
  impuestos:   number;
  total:       number;
  moneda:      string;
  /** Importe mínimo que la pasarela acepta cobrar en esta moneda. */
  monto_minimo?: number;
  /** Código realmente aplicado por el servidor; null si ninguno. */
  cupon_codigo?: string | null;
  cupon_tipo?:   string | null;
  /** El descuento se calculó incluyendo el envío en su base. */
  cupon_aplica_envio?: boolean;
  /** Motivo por el que se descartó el cupón que se pidió. */
  cupon_error?:  string | null;
  /** Cómo cobra el envío la tienda. */
  envio_modo?:         EnvioModo;
  /** Opciones para el estado de destino (en dinámico, una sola). */
  opciones_envio?:     OpcionEnvioCheckout[];
  /** Paquetería con la que se calculó el total (null en dinámico). */
  paqueteria_id?:      number | null;
  /** Subtotal desde el que el envío es gratis; null si no aplica. */
  envio_gratis_desde?: number | null;
}

const STORAGE_KEY = "cq-checkout";

export const emptyForm: CheckoutFormData = {
  contacto: { nombre: "", apellido: "", email: "", telefono: "", modoGuest: true },
  envio: {
    calle: "", numeroExt: "", numeroInt: "", colonia: "", ciudad: "",
    municipio: "", estado: "", codigoPostal: "", pais: "México",
    referencias: "", empresa: "", guardarDireccion: false,
  },
  pago: { metodo: "tarjeta", nombreTarjeta: "", notas: "" },
};

/** Lo que se respalda entre recargas. */
interface Borrador {
  formData:    CheckoutFormData;
  cupon:       string | null;
  resultado:   ResultadoPago | null;
  paqueteria?: number | null;
}

/* ── Guardar teléfono del usuario autenticado ────────────── */
async function guardarTelefonoUsuario(telefono: string) {
  try {
    await fetch("/api/users/profile", {
      method:  "PATCH",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ telefono }),
    });
  } catch (err) {
    console.error("[checkout] Error al guardar teléfono:", err);
  }
}

/* ── Guardar dirección del usuario autenticado ───────────── */
async function guardarDireccionUsuario(
  formData: CheckoutFormData,
  esPredeterminada = false
) {
  const { contacto, envio } = formData;
  try {
    await fetch("/api/users/addresses", {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({
        nombre:           contacto.nombre,
        apellido:         contacto.apellido,
        empresa:          envio.empresa || null,
        telefono:         contacto.telefono || null,
        calle:            envio.calle,
        numero_ext:       envio.numeroExt,
        numero_int:       envio.numeroInt || null,
        colonia:          envio.colonia,
        ciudad:           envio.ciudad,
        municipio:        envio.municipio || null,
        estado:           envio.estado,
        codigo_postal:    envio.codigoPostal,
        pais:             envio.pais,
        referencias:      envio.referencias || null,
        es_predeterminada: esPredeterminada,
        tipo:             "envio",
      }),
    });
  } catch (err) {
    console.error("[checkout] Error al guardar dirección:", err);
  }
}

/* ══════════════════════════════════════════════════════════ */
interface CheckoutContextValue {
  /** false hasta leer el borrador de sessionStorage. */
  hidratado: boolean;

  formData:    CheckoutFormData;
  setContacto: (d: DatosContacto) => void;
  setEnvio:    (d: DatosEnvio)    => void;
  setPago:     (d: DatosPago)     => void;

  cupon:         string | null;
  cuponCargando: boolean;
  cuponEtiqueta: string | null;
  aplicarCupon:  (codigo: string) => Promise<void>;
  quitarCupon:   () => Promise<void>;

  resumen:       ResumenCheckout | null;
  cargarResumen: (estado: string, codigoCupon: string | null) => Promise<ResumenCheckout | null>;

  /**
   * Paquetería elegida (tiendas con envío a precio fijo). Mandarla a
   * /api/checkout/pagar como `paqueteria_id`. Si el cliente no ha
   * elegido, el resumen preselecciona la más barata.
   */
  paqueteriaId:     number | null;
  elegirPaqueteria: (id: number) => Promise<void>;

  resultado:     ResultadoPago | null;
  /** Pago aceptado: guarda el pedido, vacía el carrito y hace las tareas de cuenta. */
  registrarPago: (r: ResultadoPago) => Promise<void>;
  /** Descarta el pedido terminado para empezar una compra nueva. */
  limpiarPedido: () => void;
}

const CheckoutContext = createContext<CheckoutContextValue | null>(null);

export function CheckoutProvider({ children }: { children: ReactNode }) {
  const { items, clearCart } = useCart();
  const { usuario, autenticado, refreshUser } = useAuth();
  const { success, error: alertaError } = useAlert();

  const [hidratado, setHidratado] = useState(false);
  const [formData,  setFormData]  = useState<CheckoutFormData>(emptyForm);

  /** Código de cupón confirmado por el servidor; null si no hay ninguno. */
  const [cupon,         setCupon]         = useState<string | null>(null);
  const [cuponCargando, setCuponCargando] = useState(false);

  /** Importes autoritativos del servidor; null mientras se calculan. */
  const [resumen, setResumen] = useState<ResumenCheckout | null>(null);

  /** Datos del pedido ya pagado, para la pantalla de confirmación. */
  const [resultado, setResultado] = useState<ResultadoPago | null>(null);

  /** Paquetería elegida. El ref evita que cargarResumen lea un valor viejo. */
  const [paqueteriaId, setPaqueteriaId] = useState<number | null>(null);
  const paqueteriaRef = useRef<number | null>(null);
  const fijarPaqueteria = useCallback((id: number | null) => {
    paqueteriaRef.current = id;
    setPaqueteriaId(id);
  }, []);

  /* ── Rehidratar el borrador (una sola vez) ──────────────── */
  useEffect(() => {
    try {
      const raw = sessionStorage.getItem(STORAGE_KEY);
      if (raw) {
        const b = JSON.parse(raw) as Partial<Borrador>;
        if (b.formData) {
          setFormData({
            contacto: { ...emptyForm.contacto, ...b.formData.contacto },
            envio:    { ...emptyForm.envio,    ...b.formData.envio    },
            pago:     { ...emptyForm.pago,     ...b.formData.pago     },
          });
        }
        if (b.cupon)     setCupon(b.cupon);
        if (b.resultado) setResultado(b.resultado);
        if (b.paqueteria != null) fijarPaqueteria(b.paqueteria);
      }
    } catch { /* un borrador ilegible no debe romper la compra */ }
    setHidratado(true);
  }, [fijarPaqueteria]);

  /* ── Persistir en cada cambio, ya hidratados ────────────── */
  useEffect(() => {
    if (!hidratado) return;
    try {
      const b: Borrador = { formData, cupon, resultado, paqueteria: paqueteriaId };
      sessionStorage.setItem(STORAGE_KEY, JSON.stringify(b));
    } catch { /* cuota llena o modo privado: seguir sin respaldo */ }
  }, [hidratado, formData, cupon, resultado, paqueteriaId]);

  const setContacto = useCallback((contacto: DatosContacto) =>
    setFormData((p) => ({ ...p, contacto })), []);
  const setEnvio = useCallback((envio: DatosEnvio) =>
    setFormData((p) => ({ ...p, envio })), []);
  const setPago = useCallback((pago: DatosPago) =>
    setFormData((p) => ({ ...p, pago })), []);

  /**
   * Pide al servidor el desglose real (precios de BD, envío cotizado,
   * cupón). Es la MISMA función que después calcula lo que se cobra,
   * así que lo mostrado y lo cobrado no pueden diferir.
   */
  const cargarResumen = useCallback(async (
    estado:      string,
    codigoCupon: string | null
  ): Promise<ResumenCheckout | null> => {
    if (!estado.trim() || items.length === 0) { setResumen(null); return null; }
    try {
      const res = await fetch("/api/checkout/resumen", {
        method:      "POST",
        headers:     { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          estado,
          items: items.map((i) => ({ variante_id: i.varianteId, cantidad: i.cantidad })),
          cupon_codigo: codigoCupon || undefined,
          paqueteria_id: paqueteriaRef.current ?? undefined,
          // Identifica al invitado en cupones de primera compra, para que
          // la vista previa coincida con lo que aceptará el cobro.
          email: formData.contacto.email || undefined,
        }),
      });
      const json = await res.json();
      if (!res.ok || !json.success) {
        setResumen(null);
        alertaError(json.error ?? "No pudimos calcular el total.", "Error en el resumen");
        return null;
      }

      const data = json.data as ResumenCheckout;
      setResumen(data);

      // El servidor dice con qué paquetería calculó: si la elegida ya no
      // llega a este estado, o no había elegida, queda la que él usó.
      if ((data.paqueteria_id ?? null) !== paqueteriaRef.current) {
        fijarPaqueteria(data.paqueteria_id ?? null);
      }

      // El servidor manda sobre el cupón. Si lo rechazó —por ejemplo
      // porque el carrito cambió y ya no llega al mínimo— se retira aquí,
      // en un solo sitio, y el comprador se entera por qué.
      if (data.cupon_error) {
        setCupon(null);
        alertaError(data.cupon_error, "Cupón no aplicado");
      } else {
        setCupon(data.cupon_codigo ?? null);
      }

      return data;
    } catch {
      setResumen(null);
      alertaError("No pudimos calcular el total. Revisa tu conexión.", "Error en el resumen");
      return null;
    }
  }, [items, formData.contacto.email, alertaError, fijarPaqueteria]);

  /** Cambia de paquetería y recalcula el total con su precio. */
  const elegirPaqueteria = useCallback(async (id: number) => {
    fijarPaqueteria(id);
    await cargarResumen(formData.envio.estado, cupon);
  }, [fijarPaqueteria, cargarResumen, formData.envio.estado, cupon]);

  /* ── Cupones ────────────────────────────────────────────── */
  const aplicarCupon = useCallback(async (codigo: string) => {
    setCuponCargando(true);
    try {
      const data = await cargarResumen(formData.envio.estado, codigo);
      if (!data?.cupon_codigo) return;   // el motivo ya se avisó
      success(
        data.cupon_tipo === "envio_gratis"
          ? "El envío de tu pedido es gratis."
          : data.cupon_aplica_envio
            ? `Ahorras ${formatMoneda(data.descuento, data.moneda)}, envío incluido.`
            : `Ahorras ${formatMoneda(data.descuento, data.moneda)}.`,
        "Cupón aplicado"
      );
    } finally {
      setCuponCargando(false);
    }
  }, [cargarResumen, formData.envio.estado, success]);

  const quitarCupon = useCallback(async () => {
    setCuponCargando(true);
    setCupon(null);
    try {
      await cargarResumen(formData.envio.estado, null);
    } finally {
      setCuponCargando(false);
    }
  }, [cargarResumen, formData.envio.estado]);

  /* ── Pago aceptado: sólo tareas de cuenta; el pedido ya existe ── */
  const registrarPago = useCallback(async (res: ResultadoPago) => {
    setResultado(res);
    clearCart();

    // Guardar teléfono si el usuario autenticado no tenía uno
    if (autenticado && usuario && !usuario.telefono && formData.contacto.telefono?.trim()) {
      await guardarTelefonoUsuario(formData.contacto.telefono.trim());
      refreshUser?.();
    }

    // Guardar dirección si el usuario lo marcó
    if (autenticado && formData.envio.guardarDireccion) {
      void guardarDireccionUsuario(formData, true);
    }
  }, [formData, autenticado, usuario, refreshUser, clearCart]);

  /**
   * Cierra el pedido terminado. Conserva contacto y envío: si vuelve a
   * comprar en la misma pestaña no tiene que reescribir sus datos.
   */
  const limpiarPedido = useCallback(() => {
    setResultado(null);
    setResumen(null);
    setCupon(null);
  }, []);

  /** Efecto del cupón, para mostrarlo junto al código aplicado. */
  const cuponEtiqueta =
    !resumen                                ? null
    : resumen.cupon_tipo === "envio_gratis" ? "Envío gratis"
    : resumen.descuento > 0                 ? `−${formatMoneda(resumen.descuento, resumen.moneda)}${resumen.cupon_aplica_envio ? " (envío incluido)" : ""}`
    : null;

  return (
    <CheckoutContext.Provider value={{
      hidratado,
      formData, setContacto, setEnvio, setPago,
      cupon, cuponCargando, cuponEtiqueta, aplicarCupon, quitarCupon,
      resumen, cargarResumen,
      paqueteriaId, elegirPaqueteria,
      resultado, registrarPago, limpiarPedido,
    }}>
      {children}
    </CheckoutContext.Provider>
  );
}

export function useCheckout(): CheckoutContextValue {
  const ctx = useContext(CheckoutContext);
  if (!ctx) throw new Error("useCheckout debe usarse dentro de <CheckoutProvider>");
  return ctx;
}
