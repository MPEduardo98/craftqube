// app/(main)/checkout/types.ts

export type CheckoutStep = "contacto" | "envio" | "pago" | "confirmacion";

export interface DatosContacto {
  nombre:    string;
  apellido:  string;
  email:     string;
  telefono:  string;
  /** Solo aplica cuando el usuario NO está autenticado */
  modoGuest?: boolean;
}

export interface DatosEnvio {
  calle:           string;
  numeroExt:       string;
  numeroInt:       string;
  colonia:         string;
  ciudad:          string;
  municipio:       string;
  estado:          string;
  codigoPostal:    string;
  pais:            string;
  referencias:     string;
  empresa:         string;
  /** Guardar dirección en la cuenta (solo usuarios autenticados) */
  guardarDireccion?: boolean;
}

export interface DatosPago {
  metodo:        "tarjeta" | "transferencia" | "oxxo";
  /**
   * Sólo el nombre del titular. El número, el vencimiento y el CVC
   * viven exclusivamente dentro de los iframes de Stripe Elements:
   * nunca tocan el estado de la aplicación ni nuestro servidor.
   */
  nombreTarjeta: string;
  notas:         string;
}

export interface CheckoutFormData {
  contacto: DatosContacto;
  envio:    DatosEnvio;
  pago:     DatosPago;
}

export const STEPS: { id: CheckoutStep; label: string; shortLabel: string; icon: string }[] = [
  { id: "contacto",     label: "Contacto",  shortLabel: "Contacto", icon: "fa-user"       },
  { id: "envio",        label: "Envío",     shortLabel: "Envío",    icon: "fa-truck"      },
  { id: "pago",         label: "Pago",      shortLabel: "Pago",     icon: "fa-credit-card"},
  { id: "confirmacion", label: "Listo",     shortLabel: "Listo",    icon: "fa-check"      },
];

export { ESTADOS_MX } from "../data/estados-mx";
/* ── Ruta de cada paso ────────────────────────────────────────
   Cada paso es una URL propia, para que la flecha de "atrás" del
   navegador y el recargar la página caigan donde el comprador se
   quedó en lugar de reiniciar el flujo.                        */
export const RUTA_PASO: Record<CheckoutStep, string> = {
  contacto:     "/checkout/contacto",
  envio:        "/checkout/envio",
  pago:         "/checkout/pago",
  confirmacion: "/checkout/confirmacion",
};

/** Paso al que corresponde un pathname; "contacto" si no encaja. */
export function pasoDesdeRuta(pathname: string): CheckoutStep {
  const seg = pathname.split("/")[2];
  return seg && seg in RUTA_PASO ? (seg as CheckoutStep) : "contacto";
}

/* ── Tipos de datos de pago para la confirmación ─────────── */
export interface SpeiConfirmData {
  clabe:                 string | null;
  banco:                 string;
  referencia:            string | null;
  monto:                 number;
  hostedInstructionsUrl: string | null;
}

export interface OxxoConfirmData {
  numero:           string;
  expira:           number;
  hostedVoucherUrl: string | null;
}

export interface PaymentConfirmData {
  spei?: SpeiConfirmData;
  oxxo?: OxxoConfirmData;
}

/** Lo que el checkout necesita saber cuando el pago sale bien. */
export interface ResultadoPago {
  pedidoId:        number;
  /** Número REAL de la BD (CQ-2026-000042), no uno inventado en el cliente. */
  numero:          string;
  total:           number;
  moneda:          string;
  paymentIntentId: string | null;
  paymentData:     PaymentConfirmData | null;
}

/* ── Opciones de envío ───────────────────────────────────── */

/**
 * Cómo cobra el envío la tienda (Ajustes → Envíos):
 *   dinamico → guías por peso/volumen + flete, por zona (una opción).
 *   fijo     → el cliente elige paquetería; precio fijo por zona.
 */
export type EnvioModo = "dinamico" | "fijo";

/** Una opción que el cliente puede elegir en el paso de envío. */
export interface OpcionEnvioCheckout {
  /** id de la paquetería; null en modo dinámico (opción única). */
  id:              number | null;
  nombre:          string;
  logo_url:        string | null;
  dias_min:        number | null;
  dias_max:        number | null;
  /** Lo que se cobra (0 si aplica envío gratis). */
  precio:          number;
  /** Precio antes del envío gratis, para mostrarlo tachado. */
  precio_original: number;
  gratis:          boolean;
}
