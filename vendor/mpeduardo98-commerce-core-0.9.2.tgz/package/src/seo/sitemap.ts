// seo/sitemap.ts
// ─────────────────────────────────────────────────────────────
// sitemap.xml y robots.txt de la tienda.
//
//   // app/sitemap.ts
//   export default () => sitemapTienda({ paginas: ["/", "/nosotros"] });
//
//   // app/robots.ts
//   export default () => robotsTienda();
// ─────────────────────────────────────────────────────────────
import type { MetadataRoute } from "next";
import { getAllProductoSlugs, getAllCategoriaSlugs } from "../catalogo/getAllSlugs";
import { RUTAS_SEO, urlAbsoluta, urlSitio, type RutasSeo } from "./sitio";

/**
 * Productos activos y categorías con productos, más las páginas
 * propias que la tienda pase en `paginas` (inicio, nosotros…).
 */
export async function sitemapTienda(opciones: {
  paginas?: string[];
  rutas?:   Partial<RutasSeo>;
} = {}): Promise<MetadataRoute.Sitemap> {
  const rutaProducto  = opciones.rutas?.producto  ?? RUTAS_SEO.producto;
  const rutaCategoria = opciones.rutas?.categoria ?? RUTAS_SEO.categoria;

  const [productos, categorias] = await Promise.all([
    getAllProductoSlugs(),
    getAllCategoriaSlugs(),
  ]);

  return [
    ...(opciones.paginas ?? ["/"]).map((ruta) => ({
      url:        urlAbsoluta(ruta),
      changeFrequency: "weekly" as const,
      priority:   ruta === "/" ? 1 : 0.5,
    })),
    ...categorias.map((c) => ({
      url:        urlAbsoluta(rutaCategoria(c.slug)),
      changeFrequency: "weekly" as const,
      priority:   0.7,
    })),
    ...productos.map((p) => ({
      url:          urlAbsoluta(rutaProducto(p.slug)),
      lastModified: p.updated_at ? new Date(p.updated_at) : undefined,
      changeFrequency: "weekly" as const,
      priority:     0.8,
    })),
  ];
}

/**
 * robots.txt: deja fuera el panel, las APIs y las páginas privadas
 * del cliente. `bloquear` agrega rutas propias de la tienda.
 */
export function robotsTienda(opciones: { bloquear?: string[] } = {}): MetadataRoute.Robots {
  return {
    rules: {
      userAgent: "*",
      allow:     "/",
      disallow: [
        "/admin",
        "/api/",
        "/carrito",
        "/checkout",
        "/cuenta",
        "/login",
        "/registro",
        ...(opciones.bloquear ?? []),
      ],
    },
    sitemap: `${urlSitio()}/sitemap.xml`,
  };
}
