// seo/JsonLd.tsx
// Inserta datos estructurados (schema.org) en la página.
// Se escapa "<" para que un texto del producto no pueda cerrar el
// <script> e inyectar HTML.

export function JsonLd({ datos }: { datos: Record<string, unknown> | Record<string, unknown>[] }) {
  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(datos).replace(/</g, "\\u003c") }}
    />
  );
}
