// seo/categoria.ts
// ─────────────────────────────────────────────────────────────
// SEO de la página de categoría.
//
//   export async function generateMetadata({ params }) {
//     const categoria = await getCategoriaBySlug((await params).slug);
//     return categoria ? metadataCategoria(categoria) : {};
//   }
// ─────────────────────────────────────────────────────────────
import type { Metadata } from "next";
import type { CategoriaDetalle } from "../catalogo/getCategoriaBySlug";
import { toCdnUrl } from "../media/cdn";
import { RUTAS_SEO, textoPlano, urlAbsoluta, type RutasSeo } from "./sitio";

export function metadataCategoria(
  categoria: CategoriaDetalle,
  opciones: { rutas?: Partial<RutasSeo> } = {},
): Metadata {
  const titulo      = categoria.meta_titulo?.trim()      || categoria.nombre;
  const descripcion = categoria.meta_descripcion?.trim() || textoPlano(categoria.descripcion);
  const url         = urlAbsoluta((opciones.rutas?.categoria ?? RUTAS_SEO.categoria)(categoria.slug));
  const imagen      = toCdnUrl(categoria.imagen);

  return {
    title:       titulo,
    description: descripcion || undefined,
    alternates:  { canonical: url },
    // Una categoría sin productos no aporta nada en Google.
    robots:      categoria.total_productos > 0 ? undefined : { index: false, follow: true },
    openGraph: {
      type:        "website",
      url,
      title:       titulo,
      description: descripcion || undefined,
      images:      imagen ? [{ url: imagen, alt: categoria.nombre }] : undefined,
    },
  };
}
