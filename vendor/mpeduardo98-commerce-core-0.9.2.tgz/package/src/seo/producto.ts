// seo/producto.ts
// ─────────────────────────────────────────────────────────────
// SEO de la página de producto: metadatos (título, descripción,
// URL canónica, imagen al compartir) y datos estructurados para
// Google (precio, disponibilidad, estrellas).
//
// Uso en la página de producto de la tienda:
//
//   export async function generateMetadata({ params }) {
//     const producto = await getProductoBySlug((await params).slug);
//     return producto ? metadataProducto(producto) : {};
//   }
//   …
//   <JsonLd datos={await jsonLdProducto(producto)} />
// ─────────────────────────────────────────────────────────────
import type { Metadata } from "next";
import type { ProductoDetalle, ProductoVariante } from "../catalogo/types/product-detail";
import { getStoreConfig } from "../config/store-config";
import { getVentaPublica } from "../venta/config";
import { toCdnUrl }       from "../media/cdn";
import { RUTAS_SEO, textoPlano, urlAbsoluta, type RutasSeo } from "./sitio";

interface OpcionesSeo {
  rutas?: Partial<RutasSeo>;
}

function rutaProducto(producto: ProductoDetalle, opciones: OpcionesSeo): string {
  return (opciones.rutas?.producto ?? RUTAS_SEO.producto)(producto.slug);
}

/** Imágenes generales del producto (las de variante van después), ya en el CDN. */
function imagenesProducto(producto: ProductoDetalle): { url: string; alt: string }[] {
  return [...producto.imagenes]
    .sort((a, b) => Number(a.variante_id !== null) - Number(b.variante_id !== null) || a.orden - b.orden)
    .map((img) => ({ url: toCdnUrl(img.url), alt: img.alt || producto.titulo }))
    .filter((img): img is { url: string; alt: string } => !!img.url);
}

function disponible(v: ProductoVariante): boolean {
  return v.stock > 0 || v.vender_sin_existencia === 1;
}

/** Metadatos de la página de producto. Respeta lo que el admin escribió en la sección SEO. */
export function metadataProducto(producto: ProductoDetalle, opciones: OpcionesSeo = {}): Metadata {
  const titulo      = producto.meta_titulo?.trim()      || producto.titulo;
  const descripcion = producto.meta_descripcion?.trim() || textoPlano(producto.descripcion);
  const url         = urlAbsoluta(rutaProducto(producto, opciones));
  const imagenes    = imagenesProducto(producto).slice(0, 4);

  return {
    title:       titulo,
    description: descripcion || undefined,
    alternates:  { canonical: url },
    openGraph: {
      type:        "website",
      url,
      title:       titulo,
      description: descripcion || undefined,
      images:      imagenes,
    },
    twitter: {
      card:        imagenes.length ? "summary_large_image" : "summary",
      title:       titulo,
      description: descripcion || undefined,
      images:      imagenes.map((i) => i.url),
    },
  };
}

/**
 * Datos estructurados schema.org/Product. Con varias variantes se
 * publica el rango de precios; las estrellas solo si hay reseñas.
 * En modo catálogo con precios ocultos no se publica la oferta: el
 * precio que la tienda esconde no debe aparecer en Google.
 */
export async function jsonLdProducto(
  producto: ProductoDetalle,
  opciones: OpcionesSeo = {},
): Promise<Record<string, unknown>> {
  const [{ monedaTienda }, venta] = await Promise.all([getStoreConfig(), getVentaPublica()]);
  const url       = urlAbsoluta(rutaProducto(producto, opciones));
  const variantes = producto.variantes.filter((v) => Number.isFinite(v.precio_final));
  const principal = variantes.find((v) => v.es_default === 1) ?? variantes[0];
  const precios   = variantes.map((v) => v.precio_final);
  const hayStock  = variantes.some(disponible);

  const disponibilidad = hayStock
    ? "https://schema.org/InStock"
    : "https://schema.org/OutOfStock";

  const oferta = variantes.length > 1 && Math.min(...precios) !== Math.max(...precios)
    ? {
        "@type":       "AggregateOffer",
        priceCurrency: monedaTienda,
        lowPrice:      Math.min(...precios).toFixed(2),
        highPrice:     Math.max(...precios).toFixed(2),
        offerCount:    variantes.length,
        availability:  disponibilidad,
        url,
      }
    : principal
      ? {
          "@type":       "Offer",
          priceCurrency: monedaTienda,
          price:         principal.precio_final.toFixed(2),
          availability:  disponibilidad,
          itemCondition: "https://schema.org/NewCondition",
          url,
        }
      : undefined;
  const offers = venta.mostrarPrecios ? oferta : undefined;

  const resenas = producto.resenas;

  return {
    "@context":   "https://schema.org",
    "@type":      "Product",
    name:         producto.titulo,
    description:  textoPlano(producto.descripcion, 5000) || undefined,
    url,
    image:        imagenesProducto(producto).map((i) => i.url),
    sku:          principal?.sku || undefined,
    gtin:         principal?.codigo_barras || undefined,
    brand:        producto.marca ? { "@type": "Brand", name: producto.marca } : undefined,
    category:     producto.categorias[0]?.nombre,
    offers,
    aggregateRating: resenas && resenas.total > 0
      ? {
          "@type":     "AggregateRating",
          ratingValue: resenas.promedio,
          reviewCount: resenas.total,
          bestRating:  5,
          worstRating: 1,
        }
      : undefined,
  };
}
