// seo/sitio.ts
// ─────────────────────────────────────────────────────────────
// Base del SEO de toda la tienda: dirección pública, rutas de
// producto y categoría, y los metadatos por defecto del layout raíz.
//
// Las páginas propias de cada tienda (inicio, nosotros, landings)
// definen su SEO ellas mismas; lo que no definan lo heredan de
// metadataTienda().
// ─────────────────────────────────────────────────────────────
import type { Metadata } from "next";
import { getStoreConfig } from "../config/store-config";
import { toCdnUrl }       from "../media/cdn";

/**
 * Dónde vive cada página que arma el núcleo. La tienda define sus
 * URLs; si usa otras, las pasa en `rutas` a cada función.
 * Los valores por defecto coinciden con la vista previa del panel.
 */
export interface RutasSeo {
  producto:  (slug: string) => string;
  categoria: (slug: string) => string;
}

export const RUTAS_SEO: RutasSeo = {
  producto:  (slug) => `/productos/${slug}`,
  categoria: (slug) => `/categoria/${slug}`,
};

/** Dirección pública de la tienda, sin barra final. */
export function urlSitio(): string {
  const raw =
    process.env.NEXT_PUBLIC_SITE_URL ||
    process.env.NEXT_PUBLIC_BASE_URL ||
    "http://localhost:3000";
  return raw.replace(/\/+$/, "");
}

/** Convierte una ruta ("/productos/x") en URL completa. */
export function urlAbsoluta(ruta: string): string {
  if (/^https?:\/\//i.test(ruta)) return ruta;
  return `${urlSitio()}/${ruta.replace(/^\/+/, "")}`;
}

/** Quita el HTML y recorta a `max` caracteres sin partir palabras. */
export function textoPlano(html: string | null | undefined, max = 160): string {
  const texto = (html ?? "")
    .replace(/<[^>]*>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  if (texto.length <= max) return texto;
  const corte = texto.slice(0, max - 1);
  const espacio = corte.lastIndexOf(" ");
  return `${espacio > max * 0.6 ? corte.slice(0, espacio) : corte}…`;
}

/**
 * Metadatos del layout raíz. Todas las páginas los heredan: el nombre
 * de la tienda se agrega a cada título ("Página | Mi Tienda") y la
 * descripción por defecto cubre a las páginas que no traen la suya.
 *
 *   export const generateMetadata = () => metadataTienda();
 *
 * `plantilla` cambia el formato del título; `%s` es el de la página.
 */
export async function metadataTienda(opciones: { plantilla?: string } = {}): Promise<Metadata> {
  const cfg      = await getStoreConfig();
  const favicon  = toCdnUrl(cfg.faviconUrl);
  const logo     = toCdnUrl(cfg.logoUrl);

  return {
    metadataBase: new URL(urlSitio()),
    title: {
      default:  cfg.nombre,
      template: opciones.plantilla ?? `%s | ${cfg.nombre}`,
    },
    description: cfg.descripcion || undefined,
    icons:       favicon ? { icon: favicon } : undefined,
    openGraph: {
      type:     "website",
      locale:   "es_MX",
      siteName: cfg.nombre,
      images:   logo ? [{ url: logo }] : undefined,
    },
  };
}
