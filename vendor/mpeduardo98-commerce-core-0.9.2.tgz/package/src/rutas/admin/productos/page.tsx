// rutas/admin/productos/page.tsx
import Link              from "next/link";
import { pool }          from "../../../db";
import type { RowDataPacket } from "mysql2";
import { ProductosTable } from "../../../admin/productos/components/ProductosTable";
import { ImportarProductosButton } from "../../../admin/productos/components/ImportarProductosButton";
import { BulkEditProvider, HideOnBulkEdit } from "../../../admin/productos/components/BulkEditContext";
import type { ProductoRow } from "../../../admin/productos/types";
import { AdminPageHeader } from "../../../admin/components/AdminPageHeader";

export type { ProductoRow };
export const metadata = { title: "Productos" };

async function fetchProductos() {
  const [rows] = await pool.execute<RowDataPacket[]>(`
    SELECT
      p.id, p.titulo, p.slug, p.estado,
      MIN(v.precio_final) AS precio,
      COALESCE(SUM(v.stock), 0) AS stock,
      (SELECT pi.url FROM producto_imagenes pi WHERE pi.producto_id = p.id ORDER BY pi.orden ASC LIMIT 1) AS imagen_url,
      GROUP_CONCAT(DISTINCT c.nombre ORDER BY c.nombre SEPARATOR ', ') AS categorias,
      (SELECT pc2.categoria_id FROM producto_categorias pc2 WHERE pc2.producto_id = p.id ORDER BY pc2.categoria_id ASC LIMIT 1) AS categoria_id,
      m.nombre AS marca,
      p.marca_id
    FROM productos p
    LEFT JOIN producto_variantes v      ON v.producto_id = p.id
    LEFT JOIN marcas m                  ON m.id = p.marca_id
    LEFT JOIN producto_categorias pc    ON pc.producto_id = p.id
    LEFT JOIN categorias c              ON c.id = pc.categoria_id
    WHERE p.deleted_at IS NULL
    GROUP BY p.id
    ORDER BY p.updated_at DESC
    LIMIT 50
  `);

  const [[{ total }]] = await pool.execute<RowDataPacket[]>(
    "SELECT COUNT(*) AS total FROM productos WHERE deleted_at IS NULL"
  );

  return { productos: rows as ProductoRow[], total: Number(total) };
}

async function fetchCategorias() {
  const [rows] = await pool.execute<RowDataPacket[]>(
    "SELECT id, nombre FROM categorias ORDER BY nombre ASC"
  );
  return rows as { id: number; nombre: string }[];
}

async function fetchMarcas() {
  const [rows] = await pool.execute<RowDataPacket[]>(
    "SELECT id, nombre FROM marcas ORDER BY nombre ASC"
  );
  return rows as { id: number; nombre: string }[];
}

export default async function ProductosPage() {
  const [{ productos, total }, categorias, marcas] = await Promise.all([
    fetchProductos(), fetchCategorias(), fetchMarcas(),
  ]);

  return (
    <BulkEditProvider>
    <div className="min-h-full" style={{ background: "var(--color-cq-bg, #fafafa)" }}>

      <AdminPageHeader
        titulo="Productos"
        descripcion={<>{total} productos en total</>}
        acciones={
          <HideOnBulkEdit>
            <div className="flex items-center gap-2">
              <ImportarProductosButton />
              <Link href="/admin/productos/crear" className="btn-primary shrink-0">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                  <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
                </svg>
                Nuevo producto
              </Link>
            </div>
          </HideOnBulkEdit>
        }
      />

      <div className="px-8 pb-10 space-y-5">

        {/* ── Tabla ── */}
        <div
          className="rounded-xl overflow-hidden"
          style={{ background: "var(--color-cq-surface, #fff)", border: "1px solid var(--color-cq-border, #ebebeb)", boxShadow: "var(--shadow-card)" }}
        >
          <ProductosTable initialProductos={productos} initialTotal={total} categorias={categorias} marcas={marcas} />
        </div>

      </div>
    </div>
    </BulkEditProvider>
  );
}