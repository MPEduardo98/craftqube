// rutas/admin/categorias/page.tsx
import { pool } from "../../../db";
import type { RowDataPacket } from "mysql2";
import { CategoriasTable }        from "../../../admin/categorias/components/CategoriasTable";
import { CrearCategoriaButton }   from "../../../admin/categorias/components/CrearCategoriaButton";
import { BulkEditProvider, HideOnBulkEdit } from "../../../ui";
import type { CategoriaRow } from "../../../admin/categorias/types";
import { AdminPageHeader } from "../../../admin/components/AdminPageHeader";

export const metadata = { title: "Categorías" };

const LIMIT = 20;

async function fetchCategorias() {
  const [rows] = await pool.query<RowDataPacket[]>(`
    SELECT
      c.id, c.nombre, c.slug, c.descripcion, c.imagen, c.parent_id,
      p.nombre AS parent_nombre,
      COUNT(DISTINCT pc.producto_id) AS total_productos
    FROM categorias c
    LEFT JOIN categorias p           ON p.id = c.parent_id
    LEFT JOIN producto_categorias pc ON pc.categoria_id = c.id
    GROUP BY c.id, c.nombre, c.slug, c.descripcion, c.imagen, c.parent_id, p.nombre
    ORDER BY c.nombre ASC
    LIMIT ?
  `, [LIMIT]);

  const [[{ total }]] = await pool.execute<RowDataPacket[]>(
    "SELECT COUNT(*) AS total FROM categorias"
  );

  return { categorias: rows as CategoriaRow[], total: Number(total) };
}

export default async function CategoriasPage() {
  const { categorias, total } = await fetchCategorias();

  return (
    <BulkEditProvider>
    <div className="min-h-full" style={{ background: "var(--color-cq-bg, #fafafa)" }}>

      <AdminPageHeader
        titulo="Categorías"
        descripcion={<>{total} categorías en total</>}
        acciones={
          <HideOnBulkEdit>
            <div className="flex items-center gap-2">
              <CrearCategoriaButton categorias={categorias} />
            </div>
          </HideOnBulkEdit>
        }
      />

      <div className="px-8 pb-10 space-y-5">

        {/* ── Tabla ── */}
        <div
          className="rounded-xl overflow-hidden"
          style={{ background: "var(--color-cq-surface, #fff)", border: "1px solid var(--color-cq-border, #ebebeb)", boxShadow: "var(--shadow-card)" }}
        >
          <CategoriasTable initialCategorias={categorias} initialTotal={total} />
        </div>

      </div>
    </div>
    </BulkEditProvider>
  );
}
