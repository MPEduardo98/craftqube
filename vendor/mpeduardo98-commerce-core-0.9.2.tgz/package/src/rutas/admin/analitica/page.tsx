import { notFound } from "next/navigation";
import { exigirAdmin } from "../../../auth/exigirAdmin";
import { analyticsReport, type Bar } from "../../../analytics/report";
import { AdminPageHeader } from "../../../admin/components/AdminPageHeader";

export const metadata = { title: "Analítica" };
export const dynamic = "force-dynamic";
function Chart({ title, rows }: { title: string; rows: Bar[] }) {
  const max = Math.max(1, ...rows.map(x => x.value));
  return <section style={{ border: "1px solid #ebebeb", borderRadius: 12, padding: 20, background: "white", minWidth: 0 }}>
    <h2 className="font-semibold mb-4">{title}</h2>
    {!rows.length ? <p className="text-sm text-neutral-500">Todavía no hay datos para este período.</p> :
      <ul style={{ maxHeight: 320, overflowY: "auto" }} aria-label={title}>{rows.map(r => <li key={r.label} style={{ marginBottom: 12 }}>
        <div style={{ display: "flex", justifyContent: "space-between", gap: 16, fontSize: 13 }}><span style={{ overflowWrap: "anywhere" }}>{r.label}</span><strong>{r.value.toLocaleString("es-MX")}</strong></div>
        <div aria-hidden="true" style={{ height: 7, background: "#f5f5f5", borderRadius: 4, marginTop: 5 }}><div style={{ height: "100%", width: `${r.value / max * 100}%`, background: "#2563eb", borderRadius: 4 }} /></div>
      </li>)}</ul>}
  </section>;
}
export default async function AnalyticsDashboard({ searchParams }: { searchParams: Promise<{ days?: string }> }) {
  if (await exigirAdmin()) notFound();
  const requested = Number((await searchParams).days);
  const days = [7, 30, 90].includes(requested) ? requested : 30;
  let data;
  try { data = await analyticsReport(days); } catch (error) {
    const missing = (error as { code?: string }).code === "ER_NO_SUCH_TABLE";
    if (!missing) throw error;
    return <div><AdminPageHeader titulo="Analítica" descripcion="La medición necesita una actualización de la base de datos." /><p className="px-8">Ejecuta la migración de commerce-core en esta tienda para habilitar el dashboard.</p></div>;
  }
  const cards = [
    ["Sesiones medidas", data.totals.sessions], ["Páginas vistas", data.totals.views],
    ["Clientes registrados (total)", data.accounts.total], ["Nuevos clientes", data.accounts.recent],
    ["Unidades agregadas al carrito", data.totals.units], ["Sesiones con carrito", data.totals.carts],
    ["Inicios de checkout", data.totals.checkouts], ["Registros sin completar · 30 min", data.registration.abandoned],
  ];
  return <div><AdminPageHeader titulo="Analítica" descripcion="Interacciones y audiencia de la tienda" />
    <div className="px-8 pb-10 space-y-6">
      <form method="get" className="flex items-center gap-3"><label htmlFor="analytics-days">Período</label><select id="analytics-days" name="days" defaultValue={days}>{[7,30,90].map(n => <option key={n} value={n}>Últimos {n} días</option>)}</select><button type="submit" className="border rounded-lg px-3 py-2">Aplicar</button></form>
      <p className="text-sm text-neutral-500">Días calendario UTC. La navegación incluye solo sesiones con consentimiento; una sesión no equivale a una persona. Los registros provienen de las cuentas de clientes de la tienda.</p>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(190px,1fr))", gap: 16 }}>{cards.map(([label, value]) => <section key={String(label)} className="border rounded-xl p-5 bg-white"><p className="text-sm text-neutral-500">{label}</p><p className="text-3xl font-semibold mt-2">{Number(value).toLocaleString("es-MX")}</p></section>)}</div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(280px,1fr))", gap: 20 }}>
        <Chart title="Páginas vistas por día" rows={data.daily} />
        <Chart title="Productos más vistos" rows={data.products} />
        <Chart title="Clics por elemento" rows={data.clicks} />
        <Chart title="Países · sesiones" rows={data.countries} />
        <Chart title="Proceso de registro · sesiones" rows={[{ label: "Iniciaron", value: Number(data.registration.started) }, { label: "Completaron", value: Number(data.registration.completed) }, { label: "Sin completar tras 30 min de inactividad", value: Number(data.registration.abandoned) }]} />
        <Chart title="Edad · respuestas opcionales" rows={data.ages} />
        <Chart title="Género · respuestas opcionales" rows={data.genders} />
      </div>
      <p className="text-sm text-neutral-500">Edad y género son declarados, con una respuesta por sesión; no representan a toda la audiencia. País aproximado cuando el alojamiento lo proporciona. Los eventos de navegación son orientativos y pueden perderse por bloqueadores o fallos de red.</p>
    </div>
  </div>;
}
