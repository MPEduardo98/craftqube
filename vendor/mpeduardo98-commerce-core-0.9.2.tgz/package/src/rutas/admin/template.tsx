// rutas/admin/template.tsx
// A diferencia del layout, Next vuelve a montar el template en cada
// navegación: así cada pantalla del panel entra con su animación.
import { TransicionPagina } from "../../admin/components/TransicionPagina";

export default function AdminTemplate({ children }: { children: React.ReactNode }) {
  return <TransicionPagina>{children}</TransicionPagina>;
}
