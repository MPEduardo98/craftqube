// rutas/admin/resenas/page.tsx
import Link                   from "next/link";
import { AdminPageHeader }    from "../../../admin/components/AdminPageHeader";
import { AdminStatCards }     from "../../../admin/components/AdminStatCards";
import { ResenasTable }       from "../../../admin/resenas/components/ResenasTable";
import { listarResenasAdmin, statsResenas } from "../../../admin/resenas/lib/resenasAdmin";
import { getResenasConfig }   from "../../../resenas/config";

export const metadata = { title: "Reseñas" };

export default async function ResenasPage() {
  const cfg = await getResenasConfig();
  // Si la tienda modera y hay pendientes, se abre directo en ellas.
  const stats0 = await statsResenas();
  const estado = cfg.moderacion === "manual" && stats0.pendientes > 0 ? "pendiente" as const : "";
  const lista  = await listarResenasAdmin({ estado, limit: 20 });

  const cards = [
    { key: "total",      label: "Reseñas",             href: "/admin/resenas", value: stats0.total,
      d: "M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" },
    { key: "pendientes", label: "Por revisar",         href: "/admin/resenas", value: stats0.pendientes,
      d: "M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM12 6v6l4 2" },
    { key: "promedio",   label: "Calificación promedio", href: "/admin/resenas", value: stats0.promedio, decimales: 1,
      nota: "de 5, sólo publicadas",
      d: "M12 2.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.3l-5.9 3.2 1.2-6.5L2.5 9.4l6.6-.9z" },
    { key: "fotos",      label: "Con fotos",           href: "/admin/resenas", value: stats0.con_fotos,
      d: "M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2zM12 17a4 4 0 1 0 0-8 4 4 0 0 0 0 8z" },
  ];

  return (
    <div className="min-h-full" style={{ background: "var(--color-cq-bg, #fafafa)" }}>
      <AdminPageHeader
        titulo="Reseñas"
        descripcion={cfg.activas
          ? <>Opiniones de clientes con compra verificada</>
          : <>Las reseñas están apagadas: la tienda no las muestra ni acepta nuevas. <Link href="/admin/ajustes/resenas" className="underline" style={{ color: "#0a0a0a" }}>Activarlas</Link></>}
      />

      <div className="px-8 pb-10 space-y-5">
        <AdminStatCards cards={cards} />
        <div className="rounded-xl overflow-hidden"
          style={{ background: "var(--color-cq-surface, #fff)", border: "1px solid var(--color-cq-border, #ebebeb)", boxShadow: "var(--shadow-card)" }}>
          <ResenasTable initialResenas={lista.resenas} initialTotal={lista.total} initialEstado={estado} />
        </div>
      </div>
    </div>
  );
}
