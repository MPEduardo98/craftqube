// rutas/admin/ajustes/venta/page.tsx
import { VentaSettings }  from "../../../../admin/settings/components/VentaSettings";
import { getVentaConfig } from "../../../../venta/config";

export const metadata = { title: "Modo de venta" };
export const dynamic  = "force-dynamic";

export default async function VentaSettingsPage() {
  return <VentaSettings inicial={await getVentaConfig()} />;
}
