// rutas/admin/ajustes/resenas/page.tsx
import { ResenasSettings }  from "../../../../admin/settings/components/ResenasSettings";
import { getResenasConfig } from "../../../../resenas/config";

export const metadata = { title: "Reseñas" };

export default async function ResenasSettingsPage() {
  return <ResenasSettings inicial={await getResenasConfig()} />;
}
