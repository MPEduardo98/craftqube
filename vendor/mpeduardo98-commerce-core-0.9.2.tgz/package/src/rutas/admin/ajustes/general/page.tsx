// rutas/admin/ajustes/general/page.tsx
import { getStoreConfig }   from "../../../../config";
import { getUsdToMxnRate }  from "../../../../currency";
import { GeneralSettings }  from "../../../../admin/settings/components/GeneralSettings";

export const metadata = { title: "General" };

export default async function GeneralSettingsPage() {
  const [config, usdMxn] = await Promise.all([getStoreConfig({ fresh: true }), getUsdToMxnRate()]);

  return (
    <GeneralSettings
      nombre={config.nombre}
      descripcion={config.descripcion}
      logoUrl={config.logoUrl}
      email={config.email}
      telefono={config.telefono}
      colorSidebarFondo={config.colorSidebarFondo}
      colorSidebarTexto={config.colorSidebarTexto}
      colorPrimario={config.colorPrimario}
      colorAcento={config.colorAcento}
      monedaCaptura={config.monedaCaptura}
      monedaTienda={config.monedaTienda}
      usdMxn={usdMxn}
    />
  );
}
