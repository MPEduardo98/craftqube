// rutas/admin/ajustes/layout.tsx
import { SettingsSidebar } from "../../../admin/settings/components/SettingsSidebar";
import { AdminPageHeader } from "../../../admin/components/AdminPageHeader";

export const metadata = { title: "Ajustes" };

export default function AjustesLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-full">
      <AdminPageHeader titulo="Ajustes" descripcion="Configuración general de la tienda" />
      <div className="px-8 pb-10 max-w-[1100px] flex gap-8 items-start">
        <SettingsSidebar />
        <div className="flex-1 min-w-0">{children}</div>
      </div>
    </div>
  );
}
