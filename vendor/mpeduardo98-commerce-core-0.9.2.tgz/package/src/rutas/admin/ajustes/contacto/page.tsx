import { ContactoSettings } from "../../../../admin/settings/components/ContactoSettings";
import { getContactoConfig } from "../../../../contacto/config";
export const metadata = { title: "Contacto" };
export const dynamic = "force-dynamic";
export default async function ContactoSettingsPage() {
  return <ContactoSettings inicial={await getContactoConfig()} correoConfigurado={!!(process.env.RESEND_API_KEY && process.env.RESEND_FROM_EMAIL)} />;
}
