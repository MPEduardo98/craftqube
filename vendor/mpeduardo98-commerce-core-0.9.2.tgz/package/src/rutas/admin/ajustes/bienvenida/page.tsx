// rutas/admin/ajustes/bienvenida/page.tsx
import { BienvenidaSettings }     from "../../../../admin/settings/components/BienvenidaSettings";
import { getBienvenidaConfig }    from "../../../../bienvenida/config";
import { listarCuponesElegibles } from "../../../../bienvenida/cuponesElegibles";

export const metadata = { title: "Bienvenida" };
export const dynamic  = "force-dynamic";

export default async function BienvenidaSettingsPage() {
  const [inicial, cupones] = await Promise.all([getBienvenidaConfig(), listarCuponesElegibles()]);
  return <BienvenidaSettings inicial={inicial} cupones={cupones} />;
}
