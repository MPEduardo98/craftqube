// rutas/admin/ajustes/envios/page.tsx
import { EnviosSettings }       from "../../../../admin/settings/components/EnviosSettings";
import { leerEnvioConfigAdmin } from "../../../../admin/settings/lib/envioConfig";

export const metadata = { title: "Envíos" };

export default async function EnviosSettingsPage() {
  return <EnviosSettings inicial={await leerEnvioConfigAdmin()} />;
}
