import Link from "next/link";
import { AdminPageHeader } from "../../../admin/components/AdminPageHeader";
import { MensajesContacto } from "../../../admin/contacto/MensajesContacto";
export const metadata = { title: "Mensajes de contacto" };
export default function ContactoPage() {
  return <div className="min-h-full"><AdminPageHeader titulo="Contacto" descripcion="Consultas recibidas desde el formulario de tu tienda" /><div className="px-8 pb-10 max-w-[1100px]"><Link href="/admin/ajustes/contacto" className="inline-block mb-5 text-sm underline">Configurar formulario</Link><MensajesContacto /></div></div>;
}
