// rutas/admin/pedidos/page.tsx
import { pool }             from "../../../db";
import { AdminStatCards }   from "../../../admin/components/AdminStatCards";
import { PedidosTable }     from "../../../admin/pedidos/components/PedidosTable";
import type { PedidoRow }   from "../../../admin/pedidos/types";
import type { RowDataPacket } from "mysql2";
import { AdminPageHeader } from "../../../admin/components/AdminPageHeader";

export const metadata = { title: "Pedidos" };

const LIMIT = 20;

interface Stats {
  total:        number;
  pendientes:   number;
  en_curso:     number;
  entregados:   number;
  ingresos_mes: number;
}

async function fetchPedidos() {
  const [rows] = await pool.query<RowDataPacket[]>(`
    SELECT
      p.id, p.numero, p.estado,
      p.envio_nombre AS cliente,
      p.email, p.telefono,
      p.total, p.moneda, p.metodo_pago,
      p.paqueteria, p.numero_guia,
      p.envio_ciudad, p.envio_estado,
      p.usuario_id, p.pagado_en, p.created_at,
      (SELECT COALESCE(SUM(pi.cantidad), 0)
         FROM pedido_items pi WHERE pi.pedido_id = p.id) AS total_items
    FROM pedidos p
    ORDER BY p.created_at DESC, p.id DESC
    LIMIT ?
  `, [LIMIT]);

  const [[stats]] = await pool.query<RowDataPacket[]>(`
    SELECT
      COUNT(*)                                                                   AS total,
      SUM(estado = 'pendiente_pago')                                             AS pendientes,
      SUM(estado IN ('pago_recibido','en_proceso','listo_envio','enviado'))       AS en_curso,
      SUM(estado = 'entregado')                                                   AS entregados,
      COALESCE(SUM(
        CASE WHEN estado NOT IN ('cancelado','reembolsado')
              AND YEAR(created_at)  = YEAR(CURDATE())
              AND MONTH(created_at) = MONTH(CURDATE())
             THEN total ELSE 0 END
      ), 0)                                                                       AS ingresos_mes
    FROM pedidos
  `);

  return {
    pedidos: rows as PedidoRow[],
    stats: {
      total:        Number(stats.total),
      pendientes:   Number(stats.pendientes),
      en_curso:     Number(stats.en_curso),
      entregados:   Number(stats.entregados),
      ingresos_mes: Number(stats.ingresos_mes),
    } satisfies Stats,
  };
}

export default async function PedidosPage() {
  const { pedidos, stats } = await fetchPedidos();

  const cards = [
    {
      key:      "pendientes",
      label:    "Pendientes de pago",
      href:     "/admin/pedidos",
      d:        "M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM12 6v6l4 2",
      value:    stats.pendientes,
    },
    {
      key:      "en_curso",
      label:    "En curso",
      href:     "/admin/pedidos",
      d:        "M1 3h15v13H1zM16 8h4l3 3v5h-7zM5.5 18.5a2 2 0 1 0 0 .01M18.5 18.5a2 2 0 1 0 0 .01",
      value:    stats.en_curso,
    },
    {
      key:      "entregados",
      label:    "Entregados",
      href:     "/admin/pedidos",
      d:        "M22 11.08V12a10 10 0 1 1-5.93-9.14M22 4 12 14.01l-3-3",
      value:    stats.entregados,
    },
    {
      key:      "ingresos_mes",
      label:    "Ingresos del mes",
      href:     "/admin/pedidos",
      d:        "M12 1v22M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6",
      value:    Number(stats.ingresos_mes),
      moneda:   true,
    },
  ];

  return (
    <div className="min-h-full" style={{ background: "var(--color-cq-bg, #fafafa)" }}>

      <AdminPageHeader
        titulo="Pedidos"
        descripcion={<>{stats.total} pedido{stats.total !== 1 ? "s" : ""} en total</>}
      />

      <div className="px-8 pb-10 space-y-5">

        {/* ── Métricas ── */}
        <AdminStatCards cards={cards} />

        {/* ── Tabla ── */}
        <div
          className="rounded-xl overflow-hidden"
          style={{ background: "var(--color-cq-surface, #fff)", border: "1px solid var(--color-cq-border, #ebebeb)", boxShadow: "var(--shadow-card)" }}
        >
          <PedidosTable initialPedidos={pedidos} initialTotal={stats.total} />
        </div>

      </div>
    </div>
  );
}
