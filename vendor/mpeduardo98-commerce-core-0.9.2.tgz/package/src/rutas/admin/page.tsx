// rutas/admin/page.tsx
// ─────────────────────────────────────────────────────────────
// Inicio del panel: métricas rápidas y los últimos pedidos.
// ─────────────────────────────────────────────────────────────
import Link                   from "next/link";
import { pool }               from "../../db";
import { formatMoneda }       from "../../lib";
import { AdminStatCards }     from "../../admin/components/AdminStatCards";
import { AdminPageHeader }    from "../../admin/components/AdminPageHeader";
import { estadoMeta }         from "../../admin/pedidos/types";
import type { RowDataPacket } from "mysql2";

export const metadata = { title: "Inicio" };

async function fetchStats() {
  const [[s]] = await pool.execute<RowDataPacket[]>(`
    SELECT
      (SELECT COUNT(*) FROM productos WHERE deleted_at IS NULL AND estado = 'activo')   AS productos_activos,
      (SELECT COUNT(*) FROM productos WHERE deleted_at IS NULL AND estado = 'borrador') AS borradores,
      (SELECT COALESCE(SUM(stock), 0) FROM producto_variantes)                          AS stock_total,
      (SELECT COUNT(*) FROM pedidos WHERE DATE(created_at) = CURDATE())                 AS pedidos_hoy
  `);
  return s as {
    productos_activos: number;
    borradores:        number;
    stock_total:       number;
    pedidos_hoy:       number;
  };
}

async function fetchUltimosPedidos() {
  const [rows] = await pool.execute<RowDataPacket[]>(`
    SELECT id, numero, estado, envio_nombre AS cliente, email, total, moneda, created_at
    FROM pedidos
    ORDER BY created_at DESC
    LIMIT 6
  `);
  return rows as {
    id: number; numero: string; estado: string; cliente: string | null;
    email: string; total: number; moneda: string; created_at: string;
  }[];
}

const fecha = new Intl.DateTimeFormat("es-MX", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });

export default async function AdminDashboardPage() {
  const [stats, pedidos] = await Promise.all([fetchStats(), fetchUltimosPedidos()]);

  const hoy = new Intl.DateTimeFormat("es-MX", { weekday: "long", day: "numeric", month: "long" }).format(new Date());

  const cards = [
    {
      key:   "productos_activos",
      label: "Productos activos",
      href:  "/admin/productos?estado=activo",
      d:     "M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z",
      value: Number(stats.productos_activos),
    },
    {
      key:   "borradores",
      label: "Borradores",
      href:  "/admin/productos?estado=borrador",
      d:     "M12 20h9M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4z",
      value: Number(stats.borradores),
    },
    {
      key:   "stock_total",
      label: "Unidades en stock",
      href:  "/admin/productos",
      d:     "M12 2 2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5",
      value: Number(stats.stock_total),
    },
    {
      key:   "pedidos_hoy",
      label: "Pedidos hoy",
      href:  "/admin/pedidos",
      d:     "M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4zM3 6h18M16 10a4 4 0 0 1-8 0",
      value: Number(stats.pedidos_hoy),
    },
  ];

  return (
    <div className="min-h-full">
      <AdminPageHeader
        titulo="Inicio"
        descripcion={<span className="first-letter:uppercase inline-block">{hoy}</span>}
      />

      <div className="px-8 pb-10 space-y-8 max-w-6xl">
        <AdminStatCards cards={cards} />

        {/* ── Últimos pedidos ── */}
        <section className="cc-entrar" style={{ animationDelay: "250ms" }}>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-[15px] font-semibold tracking-tight" style={{ color: "#0a0a0a" }}>Últimos pedidos</h2>
            <Link href="/admin/pedidos" className="text-[13px] hover:underline underline-offset-4" style={{ color: "#737373" }}>
              Ver todos
            </Link>
          </div>

          <div className="rounded-xl overflow-hidden" style={{ background: "#fff", border: "1px solid #ebebeb" }}>
            {pedidos.length === 0 ? (
              <div className="px-6 py-14 text-center">
                <p className="text-[14px] font-medium" style={{ color: "#0a0a0a" }}>Todavía no hay pedidos</p>
                <p className="mt-1 text-[13px]" style={{ color: "#a3a3a3" }}>
                  Cuando alguien compre en la tienda, aparecerá aquí.
                </p>
              </div>
            ) : (
              <table className="w-full text-[13px]">
                <thead>
                  <tr style={{ color: "#a3a3a3", borderBottom: "1px solid #f5f5f5" }}>
                    <th className="text-left font-medium px-5 py-2.5">Pedido</th>
                    <th className="text-left font-medium px-5 py-2.5">Cliente</th>
                    <th className="text-left font-medium px-5 py-2.5">Estado</th>
                    <th className="text-right font-medium px-5 py-2.5">Total</th>
                    <th className="text-right font-medium px-5 py-2.5">Fecha</th>
                  </tr>
                </thead>
                <tbody>
                  {pedidos.map((p) => {
                    const e = estadoMeta(p.estado);
                    return (
                      <tr key={p.id} className="hover:bg-[#fafafa]" style={{ borderBottom: "1px solid #f5f5f5" }}>
                        <td className="px-5 py-3 font-mono text-[12.5px]" style={{ color: "#0a0a0a" }}>{p.numero}</td>
                        <td className="px-5 py-3 truncate max-w-[220px]" style={{ color: "#525252" }}>{p.cliente || p.email}</td>
                        <td className="px-5 py-3">
                          <span className="inline-flex items-center gap-1.5 h-6 px-2 rounded-md text-[12px] font-medium"
                            style={{ color: e.color, background: e.bg }}>
                            <span className="w-1.5 h-1.5 rounded-full" style={{ background: e.color }} />
                            {e.label}
                          </span>
                        </td>
                        <td className="px-5 py-3 text-right tabular-nums" style={{ color: "#0a0a0a" }}>
                          {formatMoneda(Number(p.total), p.moneda)}
                        </td>
                        <td className="px-5 py-3 text-right tabular-nums" style={{ color: "#a3a3a3" }}>
                          {fecha.format(new Date(p.created_at))}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
        </section>
      </div>
    </div>
  );
}
