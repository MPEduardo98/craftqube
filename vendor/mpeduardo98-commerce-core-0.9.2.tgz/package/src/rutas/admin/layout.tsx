// rutas/admin/layout.tsx
// ─────────────────────────────────────────────────────────────
// Capa 2 de autenticación + shell del panel admin.
// No hereda Header/Footer porque app/(main)/layout.tsx
// los inyecta solo para rutas dentro de (main)/.
//
// Nombre y logo salen de `configuracion`; el diseño (blanco y
// negro, Geist) es el mismo para todas las tiendas.
//
// El panel trae TODO lo suyo: providers (sesión, alertas), íconos,
// fuentes y su CSS ya compilado (admin/estilos/panel.css). No puede
// depender del layout ni del CSS de la tienda, porque el frontend de
// cada tienda se hace desde cero. Las variables del panel sólo valen
// mientras está en pantalla (:root:has(.cc-admin)); así no ensucian
// el diseño de la tienda y sí llegan a modales y avisos en portal.
// ─────────────────────────────────────────────────────────────
import { notFound }       from "next/navigation";
import { headers }        from "next/headers";
import { auth }           from "../../auth/auth";
import { getStoreConfig } from "../../config";
import { AdminSidebar }   from "../../admin/components/AdminSidebar";
import { AdminTopbar }    from "../../admin/components/AdminTopbar";
import { AdminUserButton } from "../../admin/components/AdminUserButton";
import { AuthProvider }   from "../../auth/AuthContext";
import { AlertProvider }  from "../../context/AlertContext";
import { AlertContainer } from "../../ui/AlertContainer";
import { Geist, Geist_Mono } from "next/font/google";
import "@fortawesome/fontawesome-free/css/all.min.css";
import "../../admin/estilos/panel.css";

const geist     = Geist({ subsets: ["latin"], display: "swap" });
const geistMono = Geist_Mono({ subsets: ["latin"], display: "swap" });

const ADMIN_ROLES = new Set(["admin", "superadmin"]);

export async function generateMetadata() {
  const { nombre } = await getStoreConfig({ fresh: true });
  return {
    title: {
      default:  `Admin — ${nombre}`,
      template: "%s — Admin",
    },
    robots: { index: false, follow: false },
  };
}

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // ── Auth Capa 2: sesión real + rol (Better Auth) ─────────
  const session = await auth.api.getSession({ headers: await headers() });
  const rol = (session?.user as { rol?: string } | undefined)?.rol ?? "";

  if (!session || !ADMIN_ROLES.has(rol)) notFound();

  const { nombre, logoUrl, colorSidebarFondo, colorSidebarTexto } = await getStoreConfig({ fresh: true });

  // ── Shell visual ─────────────────────────────────────────
  return (
    <AlertProvider>
      <AuthProvider>
        {/* Fuentes del panel, sólo mientras está abierto (también llegan a modales en portal) */}
        <style>{`:root:has(.cc-admin){--font-geist:${geist.style.fontFamily};--font-geist-mono:${geistMono.style.fontFamily};}`}</style>
        <div className="cc-admin flex h-screen w-screen overflow-hidden">
          <AdminSidebar nombre={nombre} logoUrl={logoUrl} colorFondo={colorSidebarFondo} colorTexto={colorSidebarTexto} />

          <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
            <AdminTopbar userButton={<AdminUserButton />} colorFondo={colorSidebarFondo} colorTexto={colorSidebarTexto} />
            <main className="admin-shell flex-1 overflow-y-auto">
              {children}
            </main>
          </div>
        </div>
        <AlertContainer />
      </AuthProvider>
    </AlertProvider>
  );
}
