import { NextResponse } from "next/server";
import { pool } from "../../../db";
import { consumirLimite, ipDeRequest } from "../../../lib/rate-limit";
import { validarEvento } from "../../../analytics/events";

export async function POST(req: Request) {
  const origin = req.headers.get("origin");
  const expected = process.env.NEXT_PUBLIC_SITE_URL;
  if (!origin || origin !== new URL(expected || req.url).origin) return new NextResponse(null, { status: 403 });
  if (req.headers.get("dnt") === "1") return new NextResponse(null, { status: 204 });
  const limit = consumirLimite(`analytics:${ipDeRequest(req)}`, 120, 60_000);
  if (!limit.permitido) return new NextResponse(null, { status: 429, headers: { "Retry-After": String(limit.esperaSegundos) } });
  if (!req.headers.get("content-type")?.startsWith("application/json")) return new NextResponse(null, { status: 415 });
  // Bound the stream, including requests without Content-Length.
  const reader = req.body?.getReader();
  if (!reader) return new NextResponse(null, { status: 400 });
  let size = 0; let raw = ""; const decoder = new TextDecoder();
  try {
    while (true) {
      const { done, value } = await reader.read(); if (done) break;
      size += value.byteLength;
      if (size > 2048) { await reader.cancel(); return new NextResponse(null, { status: 413 }); }
      raw += decoder.decode(value, { stream: true });
    }
    raw += decoder.decode();
  } catch { return new NextResponse(null, { status: 400 }); }
  let event;
  try { event = validarEvento(JSON.parse(raw)); } catch { return new NextResponse(null, { status: 400 }); }
  if (!event) return new NextResponse(null, { status: 400 });
  // Only trust Vercel geolocation when actually hosted there; no raw IP is persisted.
  const geo = process.env.VERCEL === "1" ? req.headers.get("x-vercel-ip-country") : null;
  const country = geo && /^[A-Z]{2}$/.test(geo) ? geo : null;
  try {
    await pool.execute(`INSERT INTO analytics_events
      (id, session_id, event, product_id, quantity, target, country, age_range, gender, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE id = id`,
    [event.id, event.session, event.event, event.productId ?? null, event.quantity ?? null,
      event.target ?? null, country, event.age ?? null, event.gender ?? null]);
    return new NextResponse(null, { status: 204 });
  } catch (error) {
    console.error("[analytics] No se pudo guardar el evento", (error as { code?: string }).code);
    return new NextResponse(null, { status: 503 });
  }
}
