import { NextRequest, NextResponse } from "next/server";
import { getContactoConfig, getContactoPublico } from "../../../contacto/config";
import { ErrorContacto, objeto, validarMensaje } from "../../../contacto/validacion";
import { recibirMensaje } from "../../../contacto/mensajes";
import { consumirLimite, ipDeRequest } from "../../../lib/rate-limit";

export const dynamic = "force-dynamic";
async function leerCuerpo(req: Request): Promise<string | null> {
  const reader = req.body?.getReader();
  if (!reader) return "";
  const chunks: Uint8Array[] = [];
  let bytes = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      bytes += value.byteLength;
      if (bytes > 32_000) { await reader.cancel(); return null; }
      chunks.push(value);
    }
    return Buffer.concat(chunks).toString("utf8");
  } finally { reader.releaseLock(); }
}
export async function GET() {
  return NextResponse.json({ success: true, data: await getContactoPublico() }, { headers: { "Cache-Control": "no-store" } });
}
export async function POST(req: NextRequest) {
  const limite = consumirLimite(`contacto:${ipDeRequest(req)}`, 5, 10 * 60_000);
  if (!limite.permitido) return NextResponse.json({ success: false, error: "Demasiados intentos. Espera unos minutos." }, { status: 429, headers: { "Retry-After": String(limite.esperaSegundos) } });
  try {
    const config = await getContactoConfig();
    if (!config.activo) return NextResponse.json({ success: false, error: "El formulario no está disponible." }, { status: 403 });
    const raw = await leerCuerpo(req);
    if (raw === null) return NextResponse.json({ success: false, error: "Mensaje demasiado grande." }, { status: 413 });
    const body = objeto(JSON.parse(raw));
    // Campo trampa: los clientes humanos lo dejan vacío.
    if (body.website) return NextResponse.json({ success: true });
    const datos = validarMensaje(body, config);
    const destinatario = consumirLimite(`contacto-email:${datos.email!.toLowerCase()}`, 3, 60 * 60_000);
    if (!destinatario.permitido) return NextResponse.json({ success: false, error: "Ya recibimos varias consultas de este correo. Inténtalo más tarde." }, { status: 429, headers: { "Retry-After": String(destinatario.esperaSegundos) } });
    await recibirMensaje(datos, config);
    return NextResponse.json({ success: true }, { status: 201 });
  } catch (e) {
    if (e instanceof ErrorContacto || e instanceof SyntaxError) return NextResponse.json({ success: false, error: e instanceof ErrorContacto ? e.message : "Datos inválidos." }, { status: 400 });
    console.error("[contacto] No se pudo recibir el mensaje");
    return NextResponse.json({ success: false, error: "No pudimos guardar tu mensaje. Inténtalo de nuevo." }, { status: 500 });
  }
}
