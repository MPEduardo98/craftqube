// rutas/api/resenas/route.ts
// ─────────────────────────────────────────────────────────────
// GET  /api/resenas?producto_id=12&page=1&limit=10&orden=recientes&estrellas=5&con_fotos=1
//      → { activas, resumen, resenas, meta }. Sólo reseñas aprobadas.
//      orden: recientes | mejores | peores
//
// POST /api/resenas  (multipart/form-data, requiere sesión)
//      producto_id, calificacion (1-5), titulo?, comentario, imagenes (0-3 archivos)
//      → { id, estado }. estado "pendiente" si la tienda modera.
//      Sólo quien compró el producto (ver resenas/elegibilidad.ts).
//      Desde la tienda conviene usar enviarResena() de resenas/cliente,
//      que comprime las fotos antes de mandarlas.
// ─────────────────────────────────────────────────────────────
import { NextRequest, NextResponse } from "next/server";
import { getResenasConfig }          from "../../../resenas/config";
import { getResumenResenas, listarResenas } from "../../../resenas/consultas";
import { crearResena, ErrorResena }  from "../../../resenas/crear";
import { clienteActual }             from "../../../resenas/sesion";
import type { ResenasOrden }         from "../../../resenas/types";
import { consumirLimite }            from "../../../lib/rate-limit";

const ORDENES = new Set<ResenasOrden>(["recientes", "mejores", "peores"]);

const idValido = (v: unknown) => {
  const n = Number(v);
  return Number.isInteger(n) && n > 0 ? n : null;
};

export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const productoId = idValido(sp.get("producto_id"));
  if (!productoId) {
    return NextResponse.json({ success: false, error: "producto_id requerido" }, { status: 400 });
  }

  try {
    const { activas } = await getResenasConfig();
    if (!activas) {
      return NextResponse.json({ success: true, data: { activas: false, resumen: null, resenas: [] } });
    }

    const orden = sp.get("orden") as ResenasOrden;
    const page  = Number(sp.get("page")  ?? 1) || 1;
    const limit = Number(sp.get("limit") ?? 10) || 10;

    const [resumen, lista] = await Promise.all([
      getResumenResenas(productoId),
      listarResenas({
        productoId, page, limit,
        orden:     ORDENES.has(orden) ? orden : "recientes",
        estrellas: Number(sp.get("estrellas")) || null,
        conFotos:  sp.get("con_fotos") === "1",
      }),
    ]);

    return NextResponse.json({
      success: true,
      data: { activas: true, resumen, resenas: lista.resenas },
      meta: { page, total: lista.total, pages: lista.pages },
    });
  } catch (err) {
    console.error("[GET /api/resenas]", err);
    return NextResponse.json({ success: false, error: "Error interno" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const cliente = await clienteActual();
  if (!cliente) {
    return NextResponse.json({ success: false, error: "Inicia sesión para dejar tu reseña" }, { status: 401 });
  }

  // Freno barato contra scripts: cada alta sube fotos y procesa con sharp.
  const limite = consumirLimite(`resena:${cliente.id}`, 10, 60 * 60 * 1000);
  if (!limite.permitido) {
    return NextResponse.json(
      { success: false, error: "Demasiados intentos. Intenta más tarde." },
      { status: 429, headers: { "Retry-After": String(limite.esperaSegundos) } }
    );
  }

  let fd: FormData;
  try {
    fd = await req.formData();
  } catch {
    return NextResponse.json({ success: false, error: "Se esperaba un formulario (multipart)" }, { status: 400 });
  }

  const productoId = idValido(fd.get("producto_id"));
  if (!productoId) {
    return NextResponse.json({ success: false, error: "producto_id requerido" }, { status: 400 });
  }

  const imagenes = fd.getAll("imagenes").filter((v): v is File => v instanceof File && v.size > 0);
  const texto = (k: string) => { const v = fd.get(k); return typeof v === "string" ? v : ""; };

  try {
    const res = await crearResena(cliente, {
      productoId,
      calificacion: Number(texto("calificacion")),
      titulo:       texto("titulo"),
      comentario:   texto("comentario"),
      imagenes,
    });
    return NextResponse.json({ success: true, data: res }, { status: 201 });
  } catch (err) {
    if (err instanceof ErrorResena) {
      return NextResponse.json({ success: false, error: err.message }, { status: err.status });
    }
    console.error("[POST /api/resenas]", err);
    return NextResponse.json({ success: false, error: "No se pudo guardar la reseña" }, { status: 500 });
  }
}
