// rutas/api/resenas/pendientes/route.ts
// ─────────────────────────────────────────────────────────────
// GET /api/resenas/pendientes → productos que el cliente compró y
// aún no reseña ("Opina sobre tus compras", en su cuenta).
// Con las reseñas apagadas devuelve una lista vacía.
// ─────────────────────────────────────────────────────────────
import { NextResponse }          from "next/server";
import { getResenasConfig }      from "../../../../resenas/config";
import { getResenasPendientes }  from "../../../../resenas/elegibilidad";
import { clienteActual }         from "../../../../resenas/sesion";

export async function GET() {
  const cliente = await clienteActual();
  if (!cliente) {
    return NextResponse.json({ success: false, error: "No autenticado" }, { status: 401 });
  }
  try {
    const { activas } = await getResenasConfig();
    const data = activas ? await getResenasPendientes(cliente) : [];
    return NextResponse.json({ success: true, data });
  } catch (err) {
    console.error("[GET /api/resenas/pendientes]", err);
    return NextResponse.json({ success: false, error: "Error interno" }, { status: 500 });
  }
}
