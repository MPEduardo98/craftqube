// rutas/api/resenas/elegibilidad/route.ts
// ─────────────────────────────────────────────────────────────
// GET /api/resenas/elegibilidad?producto_id=12
//   → { puede, motivo, resena? }
//   motivo: desactivadas | sin_sesion | sin_compra | ya_reseno
//   Con ya_reseno viene la reseña que dejó (y si está pendiente).
// Sirve para decidir en la ficha si se muestra el formulario, un
// "inicia sesión" o "sólo pueden opinar quienes lo compraron".
// ─────────────────────────────────────────────────────────────
import { NextRequest, NextResponse } from "next/server";
import { getElegibilidad }           from "../../../../resenas/elegibilidad";
import { clienteActual }             from "../../../../resenas/sesion";

export async function GET(req: NextRequest) {
  const productoId = Number(req.nextUrl.searchParams.get("producto_id"));
  if (!Number.isInteger(productoId) || productoId <= 0) {
    return NextResponse.json({ success: false, error: "producto_id requerido" }, { status: 400 });
  }
  try {
    const data = await getElegibilidad(await clienteActual(), productoId);
    return NextResponse.json({ success: true, data });
  } catch (err) {
    console.error("[GET /api/resenas/elegibilidad]", err);
    return NextResponse.json({ success: false, error: "Error interno" }, { status: 500 });
  }
}
