// rutas/api/cron/limpiar-pedidos/route.ts
// ─────────────────────────────────────────────────────────────
// Handler de GET /api/cron/limpiar-pedidos.
//
// Barrido periódico de pedidos abandonados en `pendiente_pago`.
// Lo dispara Vercel Cron según el `vercel.json` de cada tienda;
// también sirve para lanzarlo a mano cuando haga falta:
//
//   curl -H "Authorization: Bearer $CRON_SECRET" \
//        https://…/api/cron/limpiar-pedidos
//
// Requiere CRON_SECRET. Sin él la ruta responde 500 en vez de
// quedarse abierta: es un endpoint que cancela pedidos y devuelve
// inventario, no algo que pueda ejecutar cualquiera.
//
// La tienda solo reexporta este GET desde su archivo de ruta.
// `dynamic` y `runtime` se copian tal cual al enchufe (Next los lee
// del archivo de la ruta, no de un reexport).
// ─────────────────────────────────────────────────────────────
import { NextRequest, NextResponse } from "next/server";
import { timingSafeEqual }           from "node:crypto";
import { limpiarPedidosVencidos }    from "../../../../orders/lib/limpiarPedidosVencidos";

/** Comparación en tiempo constante: no filtra el secreto por timing. */
function secretoValido(recibido: string, esperado: string): boolean {
  const a = Buffer.from(recibido);
  const b = Buffer.from(esperado);
  if (a.length !== b.length) return false;
  return timingSafeEqual(a, b);
}

export async function GET(req: NextRequest) {
  const esperado = process.env.CRON_SECRET;
  if (!esperado) {
    console.error("[cron/limpiar-pedidos] Falta CRON_SECRET.");
    return NextResponse.json({ error: "Cron mal configurado" }, { status: 500 });
  }

  // Vercel Cron manda `Authorization: Bearer <CRON_SECRET>`.
  const recibido = req.headers.get("authorization")?.replace(/^Bearer\s+/i, "") ?? "";
  if (!secretoValido(recibido, esperado)) {
    return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  }

  try {
    const resultado = await limpiarPedidosVencidos();
    return NextResponse.json({ success: true, ...resultado });
  } catch (err) {
    console.error("[cron/limpiar-pedidos] Fallo en el barrido:", err);
    return NextResponse.json({ error: "Error ejecutando la limpieza" }, { status: 500 });
  }
}

export const dynamic = "force-dynamic";
export const runtime = "nodejs";
