// rutas/api/venta/route.ts
// ─────────────────────────────────────────────────────────────
// GET /api/venta → modo de venta ya resuelto (VentaPublica), para
// componentes de cliente que no lo reciben por props: si hay
// carrito, si se ven los precios y el WhatsApp para pedir informes.
// ─────────────────────────────────────────────────────────────
import { NextResponse }    from "next/server";
import { getVentaPublica } from "../../../venta/config";

export const dynamic = "force-dynamic";

export async function GET() {
  return NextResponse.json({ success: true, data: await getVentaPublica() });
}
