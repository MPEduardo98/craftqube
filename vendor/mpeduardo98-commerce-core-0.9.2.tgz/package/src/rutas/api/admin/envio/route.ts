// rutas/api/admin/envio/route.ts
// ─────────────────────────────────────────────────────────────
// Configuración de envíos (Ajustes → Envíos):
//   - Modo (dinámico / precio fijo) y envío gratis desde
//   - Parámetros de guía (modo dinámico)
//   - Zonas + estados + tarifas de guía / flete
//   - Paqueterías + precio por zona (modo precio fijo)
// GET carga todo; PUT reconcilia todo en una transacción.
// ─────────────────────────────────────────────────────────────
import { NextRequest, NextResponse } from "next/server";
import { pool }                       from "../../../../db";
import type { ResultSetHeader, RowDataPacket } from "mysql2";
import { exigirAdmin }                from "../../../../auth/exigirAdmin";
import { leerEnvioConfigAdmin, type PaqueteriaForm, type ZonaForm } from "../../../../admin/settings/lib/envioConfig";

const num = (v: unknown): number => {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
};

/** Entero ≥ 0 o null (días estimados). */
const diasONull = (v: unknown): number | null => {
  if (v === "" || v == null) return null;
  const n = Math.round(Number(v));
  return Number.isFinite(n) && n >= 0 ? n : null;
};

/* ── GET ────────────────────────────────────────────────────── */
export async function GET() {
  const bloqueo = await exigirAdmin();
  if (bloqueo) return bloqueo;

  try {
    return NextResponse.json({ success: true, data: await leerEnvioConfigAdmin() });
  } catch (err) {
    console.error("[GET /api/admin/envio]", err);
    return NextResponse.json({ success: false, error: "Error interno" }, { status: 500 });
  }
}

/* ── PUT ────────────────────────────────────────────────────── */
export async function PUT(req: NextRequest) {
  const bloqueo = await exigirAdmin();
  if (bloqueo) return bloqueo;

  const body = await req.json().catch(() => null);
  if (!body) return NextResponse.json({ success: false, error: "Petición inválida" }, { status: 400 });

  const modo  = body.modo === "fijo" ? "fijo" : "dinamico";
  const caps  = body.caps ?? {};
  const zonas: ZonaForm[]             = Array.isArray(body.zonas) ? body.zonas : [];
  const paqueterias: PaqueteriaForm[] = Array.isArray(body.paqueterias) ? body.paqueterias : [];

  const gratisRaw = String(body.gratis_desde ?? "").trim();
  if (gratisRaw && !(Number(gratisRaw) > 0)) {
    return NextResponse.json({ success: false, error: "El monto de envío gratis debe ser mayor a cero" }, { status: 400 });
  }
  if (paqueterias.some((p) => !String(p.nombre ?? "").trim())) {
    return NextResponse.json({ success: false, error: "Toda paquetería necesita un nombre" }, { status: 400 });
  }

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    // 1. Configuración
    const cfg: [string, string][] = [
      ["envio_modo",           modo],
      ["envio_gratis_desde",   gratisRaw ? String(num(gratisRaw)) : ""],
      ["envio_peso_max_kg",    String(num(caps.peso_max_kg)    || 5)],
      ["envio_volumen_max_m3", String(num(caps.volumen_max_m3) || 0.0109)],
      ["envio_dim_max_cm",     String(num(caps.dim_max_cm)     || 27)],
    ];
    for (const [clave, valor] of cfg) {
      await conn.execute(
        "INSERT INTO configuracion (clave, valor) VALUES (?, ?) ON DUPLICATE KEY UPDATE valor = VALUES(valor)",
        [clave, valor]
      );
    }

    // 2. Zonas que ya no están (+ sus estados, tarifas y precios)
    const idsZona = zonas.filter((z) => z.id).map((z) => Number(z.id));
    const [zonasActuales] = await conn.execute<RowDataPacket[]>("SELECT id FROM zonas_envio");
    for (const { id } of zonasActuales) {
      if (idsZona.includes(id)) continue;
      await conn.execute("DELETE FROM zona_estados       WHERE zona_id = ?", [id]);
      await conn.execute("DELETE FROM tarifas_envio      WHERE zona_id = ?", [id]);
      await conn.execute("DELETE FROM paqueteria_precios WHERE zona_id = ?", [id]);
      await conn.execute("DELETE FROM zonas_envio        WHERE id = ?", [id]);
    }

    // 3. Upsert de zonas. `claveAId` traduce las claves del formulario
    //    (también de zonas nuevas) al id real, para los precios.
    const claveAId = new Map<string, number>();
    const estadosUsados = new Set<string>();   // un estado, una sola zona
    for (const z of zonas) {
      if (!z.nombre?.trim()) continue;
      let zonaId = z.id ? Number(z.id) : 0;
      if (zonaId) {
        await conn.execute("UPDATE zonas_envio SET nombre = ?, activa = ? WHERE id = ?", [z.nombre.trim(), z.activa ? 1 : 0, zonaId]);
      } else {
        const [res] = await conn.execute<ResultSetHeader>("INSERT INTO zonas_envio (nombre, activa) VALUES (?, ?)", [z.nombre.trim(), z.activa ? 1 : 0]);
        zonaId = res.insertId;
      }
      if (z.clave) claveAId.set(z.clave, zonaId);

      await conn.execute("DELETE FROM zona_estados WHERE zona_id = ?", [zonaId]);
      for (const estado of new Set((z.estados ?? []).map((e) => String(e).trim()).filter(Boolean))) {
        if (estadosUsados.has(estado)) continue;
        estadosUsados.add(estado);
        await conn.execute("INSERT INTO zona_estados (zona_id, estado) VALUES (?, ?)", [zonaId, estado]);
      }

      // Tarifas del modo dinámico (se conservan aunque la tienda esté en fijo)
      await conn.execute("DELETE FROM tarifas_envio WHERE zona_id = ? AND tipo_calculo IN ('por_guia','flete')", [zonaId]);
      await conn.execute(
        "INSERT INTO tarifas_envio (zona_id, nombre, tipo_calculo, precio_base, activa) VALUES (?, 'Guía estándar', 'por_guia', ?, 1)",
        [zonaId, num(z.precio_guia)]
      );
      await conn.execute(
        "INSERT INTO tarifas_envio (zona_id, nombre, tipo_calculo, precio_base, precio_por_kg, activa) VALUES (?, 'Flete sobredimensionado', 'flete', ?, ?, 1)",
        [zonaId, num(z.flete_base), num(z.flete_por_kg)]
      );
    }

    // 4. Paqueterías que ya no están (sus precios caen por cascada)
    const idsPaq = paqueterias.filter((p) => p.id).map((p) => Number(p.id));
    const [paqActuales] = await conn.execute<RowDataPacket[]>("SELECT id FROM paqueterias");
    for (const { id } of paqActuales) {
      if (!idsPaq.includes(id)) await conn.execute("DELETE FROM paqueterias WHERE id = ?", [id]);
    }

    // 5. Upsert de paqueterías (el orden de la lista es el orden) + precios
    for (const [orden, p] of paqueterias.entries()) {
      const datos = [
        String(p.nombre).trim(),
        String(p.logo_url ?? "").trim() || null,
        diasONull(p.dias_min),
        diasONull(p.dias_max),
        p.activa ? 1 : 0,
        orden,
      ];
      let paqId = p.id ? Number(p.id) : 0;
      if (paqId) {
        await conn.execute(
          "UPDATE paqueterias SET nombre = ?, logo_url = ?, dias_min = ?, dias_max = ?, activa = ?, orden = ? WHERE id = ?",
          [...datos, paqId]
        );
      } else {
        const [res] = await conn.execute<ResultSetHeader>(
          "INSERT INTO paqueterias (nombre, logo_url, dias_min, dias_max, activa, orden) VALUES (?, ?, ?, ?, ?, ?)",
          datos
        );
        paqId = res.insertId;
      }

      await conn.execute("DELETE FROM paqueteria_precios WHERE paqueteria_id = ?", [paqId]);
      for (const [clave, valor] of Object.entries(p.precios ?? {})) {
        const zonaId = claveAId.get(clave);
        if (!zonaId || String(valor).trim() === "") continue;   // vacío = no envía ahí
        const precio = Number(valor);
        if (!Number.isFinite(precio) || precio < 0) continue;
        await conn.execute(
          "INSERT INTO paqueteria_precios (paqueteria_id, zona_id, precio) VALUES (?, ?, ?)",
          [paqId, zonaId, precio]
        );
      }
    }

    await conn.commit();
    return NextResponse.json({ success: true });
  } catch (err) {
    await conn.rollback();
    console.error("[PUT /api/admin/envio]", err);
    return NextResponse.json({ success: false, error: "Error al guardar" }, { status: 500 });
  } finally {
    conn.release();
  }
}
