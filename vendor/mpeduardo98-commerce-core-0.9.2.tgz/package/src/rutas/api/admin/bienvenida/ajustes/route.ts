// rutas/api/admin/bienvenida/ajustes/route.ts
// GET/PUT de Ajustes → Bienvenida: { activa: boolean, cupon_id: number | null }
import { NextRequest, NextResponse } from "next/server";
import type { RowDataPacket }        from "mysql2";
import { pool }                      from "../../../../../db/pool";
import { exigirAdmin }               from "../../../../../auth/exigirAdmin";
import { getBienvenidaConfig, setBienvenidaConfig } from "../../../../../bienvenida/config";
import type { BienvenidaConfig }     from "../../../../../bienvenida/types";

export async function GET() {
  const bloqueo = await exigirAdmin();
  if (bloqueo) return bloqueo;
  return NextResponse.json({ success: true, data: await getBienvenidaConfig() });
}

export async function PUT(req: NextRequest) {
  const bloqueo = await exigirAdmin();
  if (bloqueo) return bloqueo;

  try {
    const body  = await req.json() as { activa?: unknown; cupon_id?: unknown };
    const patch: Partial<BienvenidaConfig> = {};

    if (body.activa !== undefined) {
      if (typeof body.activa !== "boolean") {
        return NextResponse.json({ success: false, error: "activa debe ser true o false" }, { status: 400 });
      }
      patch.activa = body.activa;
    }
    if (body.cupon_id !== undefined) {
      if (body.cupon_id === null) {
        patch.cupon_id = null;
      } else {
        const id = Number(body.cupon_id);
        const [filas] = Number.isInteger(id) && id > 0
          ? await pool.execute<RowDataPacket[]>("SELECT id FROM cupones WHERE id = ?", [id])
          : [[]];
        if (!filas.length) {
          return NextResponse.json({ success: false, error: "El cupón no existe" }, { status: 400 });
        }
        patch.cupon_id = id;
      }
    }

    const final = { ...(await getBienvenidaConfig()), ...patch };
    if (final.activa && !final.cupon_id) {
      return NextResponse.json(
        { success: false, error: "Elige el cupón que se enviará antes de activar" }, { status: 400 }
      );
    }

    await setBienvenidaConfig(patch);
    return NextResponse.json({ success: true, data: await getBienvenidaConfig() });
  } catch (err) {
    console.error("[PUT /api/admin/bienvenida/ajustes]", err);
    return NextResponse.json({ success: false, error: "Error interno" }, { status: 500 });
  }
}
