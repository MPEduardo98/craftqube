// rutas/api/admin/bienvenida/suscriptores/route.ts
// GET ?q=&page=           → lista paginada
// GET ?formato=csv[&q=]   → descarga todos como CSV
import { NextRequest, NextResponse } from "next/server";
import { exigirAdmin }               from "../../../../../auth/exigirAdmin";
import { listarSuscriptores, suscriptoresCsv } from "../../../../../bienvenida/suscriptores";

export async function GET(req: NextRequest) {
  const bloqueo = await exigirAdmin();
  if (bloqueo) return bloqueo;

  try {
    const sp = req.nextUrl.searchParams;
    const q  = sp.get("q") ?? "";

    if (sp.get("formato") === "csv") {
      const { suscriptores } = await listarSuscriptores({ q, limit: 0 });
      return new NextResponse(suscriptoresCsv(suscriptores), {
        headers: {
          "Content-Type":        "text/csv; charset=utf-8",
          "Content-Disposition": `attachment; filename="suscriptores-${new Date().toISOString().slice(0, 10)}.csv"`,
        },
      });
    }

    const page  = Math.max(1, Number(sp.get("page")) || 1);
    const limit = 50;
    const r     = await listarSuscriptores({ q, page, limit });
    return NextResponse.json({
      success: true,
      data:    r.suscriptores,
      meta:    { total: r.total, compraron: r.compraron, page, pages: Math.max(1, Math.ceil(r.total / limit)) },
    });
  } catch (err) {
    console.error("[GET /api/admin/bienvenida/suscriptores]", err);
    return NextResponse.json({ success: false, error: "Error interno" }, { status: 500 });
  }
}
