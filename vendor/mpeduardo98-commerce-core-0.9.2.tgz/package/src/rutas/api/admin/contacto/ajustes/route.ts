import { NextRequest, NextResponse } from "next/server";
import { exigirAdmin } from "../../../../../auth/exigirAdmin";
import { getContactoConfig, setContactoConfig } from "../../../../../contacto/config";
import { ErrorContacto, validarConfig } from "../../../../../contacto/validacion";

export async function GET() {
  const bloqueo = await exigirAdmin(); if (bloqueo) return bloqueo;
  return NextResponse.json({ success: true, data: await getContactoConfig() });
}
export async function PUT(req: NextRequest) {
  const bloqueo = await exigirAdmin(); if (bloqueo) return bloqueo;
  try {
    const config = validarConfig(await req.json());
    await setContactoConfig(config);
    return NextResponse.json({ success: true, data: config });
  } catch (e) {
    const invalido = e instanceof ErrorContacto || e instanceof SyntaxError;
    return NextResponse.json({ success: false, error: e instanceof ErrorContacto ? e.message : "No se pudo guardar la configuración." }, { status: invalido ? 400 : 500 });
  }
}
