import { NextRequest, NextResponse } from "next/server";
import { exigirAdmin } from "../../../../auth/exigirAdmin";
import { listarMensajes } from "../../../../contacto/mensajes";
import { pool } from "../../../../db/pool";
import type { ResultSetHeader } from "mysql2";

export async function GET(req: NextRequest) {
  const bloqueo = await exigirAdmin(); if (bloqueo) return bloqueo;
  const pagina = Number(req.nextUrl.searchParams.get("pagina") ?? 1);
  if (!Number.isSafeInteger(pagina) || pagina < 1 || pagina > 100000) return NextResponse.json({ success: false, error: "Página inválida." }, { status: 400 });
  return NextResponse.json({ success: true, data: await listarMensajes(pagina) }, { headers: { "Cache-Control": "no-store" } });
}
export async function PATCH(req: NextRequest) {
  const bloqueo = await exigirAdmin(); if (bloqueo) return bloqueo;
  const b = await req.json().catch(() => null);
  if (!b || !Number.isSafeInteger(b.id) || b.id < 1 || !["nuevo", "leido", "resuelto"].includes(b.estado)) return NextResponse.json({ success: false, error: "Datos inválidos." }, { status: 400 });
  const [r] = await pool.execute<ResultSetHeader>("UPDATE contacto_mensajes SET estado = ? WHERE id = ?", [b.estado, b.id]);
  return NextResponse.json({ success: r.affectedRows > 0 }, { status: r.affectedRows ? 200 : 404 });
}
