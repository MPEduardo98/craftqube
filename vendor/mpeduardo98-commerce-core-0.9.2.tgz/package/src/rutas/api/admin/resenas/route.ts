// rutas/api/admin/resenas/route.ts
// GET /api/admin/resenas?q=&estado=pendiente&estrellas=1&page=1&limit=20
import { NextRequest, NextResponse } from "next/server";
import { exigirAdmin }               from "../../../../auth/exigirAdmin";
import { listarResenasAdmin, statsResenas } from "../../../../admin/resenas/lib/resenasAdmin";
import type { ResenaEstado }         from "../../../../resenas/types";

export async function GET(req: NextRequest) {
  const bloqueo = await exigirAdmin();
  if (bloqueo) return bloqueo;

  const sp = req.nextUrl.searchParams;
  const page  = Number(sp.get("page")  ?? 1)  || 1;
  const limit = Number(sp.get("limit") ?? 20) || 20;

  try {
    const [lista, stats] = await Promise.all([
      listarResenasAdmin({
        q:         sp.get("q") ?? "",
        estado:    (sp.get("estado") ?? "") as ResenaEstado | "",
        estrellas: Number(sp.get("estrellas")) || null,
        page, limit,
      }),
      statsResenas(),
    ]);
    return NextResponse.json({
      success: true,
      data:    lista.resenas,
      meta:    { page, limit, total: lista.total, pages: lista.pages },
      stats,
    });
  } catch (err) {
    console.error("[GET /api/admin/resenas]", err);
    return NextResponse.json({ success: false, error: "Error interno" }, { status: 500 });
  }
}
