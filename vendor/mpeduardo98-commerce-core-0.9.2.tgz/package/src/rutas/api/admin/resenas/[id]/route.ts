// rutas/api/admin/resenas/[id]/route.ts
// ─────────────────────────────────────────────────────────────
// PATCH  /api/admin/resenas/:id  { estado?, respuesta_tienda? }
//        Aprobar / rechazar y contestar públicamente. La reseña del
//        cliente no se edita: la tienda sólo decide si se publica.
// DELETE /api/admin/resenas/:id  Borra la reseña y sus fotos del bucket.
//        El cliente podrá volver a reseñar ese producto.
// ─────────────────────────────────────────────────────────────
import { NextRequest, NextResponse } from "next/server";
import type { RowDataPacket, ResultSetHeader } from "mysql2";
import { pool }                      from "../../../../../db";
import { exigirAdmin }               from "../../../../../auth/exigirAdmin";
import { parsearImagenes }           from "../../../../../resenas/consultas";
import { borrarImagenesResena }      from "../../../../../resenas/imagenes";

const ESTADOS = new Set(["pendiente", "aprobada", "rechazada"]);
const MAX_RESPUESTA = 2000;

async function idDe(ctx: { params: Promise<{ id: string }> }): Promise<number | null> {
  const n = Number((await ctx.params).id);
  return Number.isInteger(n) && n > 0 ? n : null;
}

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const bloqueo = await exigirAdmin();
  if (bloqueo) return bloqueo;

  const id = await idDe(ctx);
  if (!id) return NextResponse.json({ success: false, error: "ID inválido" }, { status: 400 });

  try {
    const body = await req.json() as { estado?: unknown; respuesta_tienda?: unknown };
    const sets: string[] = [];
    const params: (string | null)[] = [];

    if (body.estado !== undefined) {
      if (typeof body.estado !== "string" || !ESTADOS.has(body.estado)) {
        return NextResponse.json({ success: false, error: "Estado inválido" }, { status: 400 });
      }
      sets.push("estado = ?");
      params.push(body.estado);
    }
    if (body.respuesta_tienda !== undefined) {
      if (body.respuesta_tienda !== null && typeof body.respuesta_tienda !== "string") {
        return NextResponse.json({ success: false, error: "Respuesta inválida" }, { status: 400 });
      }
      const r = (body.respuesta_tienda ?? "").trim();
      if (r.length > MAX_RESPUESTA) {
        return NextResponse.json(
          { success: false, error: `La respuesta admite hasta ${MAX_RESPUESTA} caracteres` }, { status: 400 }
        );
      }
      sets.push("respuesta_tienda = ?");
      params.push(r || null);
    }
    if (!sets.length) {
      return NextResponse.json({ success: false, error: "Nada que actualizar" }, { status: 400 });
    }

    const [res] = await pool.execute<ResultSetHeader>(
      `UPDATE \`reseñas\` SET ${sets.join(", ")} WHERE id = ?`, [...params, id]
    );
    if (!res.affectedRows) {
      return NextResponse.json({ success: false, error: "Reseña no encontrada" }, { status: 404 });
    }
    return NextResponse.json({ success: true });
  } catch (err) {
    console.error("[PATCH /api/admin/resenas/:id]", err);
    return NextResponse.json({ success: false, error: "Error interno" }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const bloqueo = await exigirAdmin();
  if (bloqueo) return bloqueo;

  const id = await idDe(ctx);
  if (!id) return NextResponse.json({ success: false, error: "ID inválido" }, { status: 400 });

  try {
    const [rows] = await pool.execute<RowDataPacket[]>(
      "SELECT imagenes FROM `reseñas` WHERE id = ?", [id]
    );
    if (!rows[0]) {
      return NextResponse.json({ success: false, error: "Reseña no encontrada" }, { status: 404 });
    }
    await pool.execute("DELETE FROM `reseñas` WHERE id = ?", [id]);
    await borrarImagenesResena(parsearImagenes(rows[0].imagenes));
    return NextResponse.json({ success: true });
  } catch (err) {
    console.error("[DELETE /api/admin/resenas/:id]", err);
    return NextResponse.json({ success: false, error: "Error interno" }, { status: 500 });
  }
}
