// rutas/api/admin/resenas/ajustes/route.ts
// GET/PUT de Ajustes → Reseñas: { activas: boolean, moderacion: "auto" | "manual" }
import { NextRequest, NextResponse } from "next/server";
import { exigirAdmin }               from "../../../../../auth/exigirAdmin";
import { getResenasConfig, setResenasConfig } from "../../../../../resenas/config";
import type { ResenasConfig }        from "../../../../../resenas/types";

export async function GET() {
  const bloqueo = await exigirAdmin();
  if (bloqueo) return bloqueo;
  return NextResponse.json({ success: true, data: await getResenasConfig() });
}

export async function PUT(req: NextRequest) {
  const bloqueo = await exigirAdmin();
  if (bloqueo) return bloqueo;

  try {
    const body = await req.json() as { activas?: unknown; moderacion?: unknown };
    const patch: Partial<ResenasConfig> = {};

    if (body.activas !== undefined) {
      if (typeof body.activas !== "boolean") {
        return NextResponse.json({ success: false, error: "activas debe ser true o false" }, { status: 400 });
      }
      patch.activas = body.activas;
    }
    if (body.moderacion !== undefined) {
      if (body.moderacion !== "auto" && body.moderacion !== "manual") {
        return NextResponse.json({ success: false, error: "Moderación inválida" }, { status: 400 });
      }
      patch.moderacion = body.moderacion;
    }

    await setResenasConfig(patch);
    return NextResponse.json({ success: true, data: await getResenasConfig() });
  } catch (err) {
    console.error("[PUT /api/admin/resenas/ajustes]", err);
    return NextResponse.json({ success: false, error: "Error interno" }, { status: 500 });
  }
}
