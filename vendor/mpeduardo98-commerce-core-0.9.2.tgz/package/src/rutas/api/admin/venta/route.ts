// rutas/api/admin/venta/route.ts
// GET/PUT de Ajustes → Modo de venta:
// { modo: "tienda" | "catalogo", mostrarPrecios, whatsapp, mensajeWhatsapp }
import { NextRequest, NextResponse } from "next/server";
import { exigirAdmin }               from "../../../../auth/exigirAdmin";
import { getVentaConfig, setVentaConfig, normalizarWhatsapp } from "../../../../venta/config";
import type { VentaConfig }          from "../../../../venta/types";

const MAX_MENSAJE = 300;

export async function GET() {
  const bloqueo = await exigirAdmin();
  if (bloqueo) return bloqueo;
  return NextResponse.json({ success: true, data: await getVentaConfig() });
}

export async function PUT(req: NextRequest) {
  const bloqueo = await exigirAdmin();
  if (bloqueo) return bloqueo;

  try {
    const body = await req.json() as Record<string, unknown>;
    const patch: Partial<VentaConfig> = {};

    if (body.modo !== undefined) {
      if (body.modo !== "tienda" && body.modo !== "catalogo") {
        return NextResponse.json({ success: false, error: "Modo inválido" }, { status: 400 });
      }
      patch.modo = body.modo;
    }
    if (body.mostrarPrecios !== undefined) {
      if (typeof body.mostrarPrecios !== "boolean") {
        return NextResponse.json({ success: false, error: "mostrarPrecios debe ser true o false" }, { status: 400 });
      }
      patch.mostrarPrecios = body.mostrarPrecios;
    }
    if (body.whatsapp !== undefined) {
      if (typeof body.whatsapp !== "string") {
        return NextResponse.json({ success: false, error: "WhatsApp inválido" }, { status: 400 });
      }
      const numero = normalizarWhatsapp(body.whatsapp);
      // Vacío apaga el botón; si no, lada de país + número (E.164: hasta 15).
      if (numero && (numero.length < 11 || numero.length > 15)) {
        return NextResponse.json(
          { success: false, error: "El WhatsApp debe llevar lada de país, por ejemplo 52 55 1234 5678" },
          { status: 400 }
        );
      }
      patch.whatsapp = numero;
    }
    if (body.mensajeWhatsapp !== undefined) {
      if (typeof body.mensajeWhatsapp !== "string" || body.mensajeWhatsapp.length > MAX_MENSAJE) {
        return NextResponse.json(
          { success: false, error: `El mensaje debe tener como máximo ${MAX_MENSAJE} caracteres` },
          { status: 400 }
        );
      }
      patch.mensajeWhatsapp = body.mensajeWhatsapp;
    }

    await setVentaConfig(patch);
    return NextResponse.json({ success: true, data: await getVentaConfig() });
  } catch (err) {
    console.error("[PUT /api/admin/venta]", err);
    return NextResponse.json({ success: false, error: "Error interno" }, { status: 500 });
  }
}
