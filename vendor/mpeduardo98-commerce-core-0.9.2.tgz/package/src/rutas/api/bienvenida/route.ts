// rutas/api/bienvenida/route.ts
// ─────────────────────────────────────────────────────────────
// GET  /api/bienvenida → la oferta del modal, o null si no hay
//                        (apagado o el cupón ya no sirve).
// POST /api/bienvenida → { nombre, email, acepta_marketing? }
//                        Guarda al cliente potencial y le manda el
//                        devuelve el código para el modal (y lo manda
//                        por correo como copia).
// ─────────────────────────────────────────────────────────────
import { NextRequest, NextResponse }  from "next/server";
import { getOfertaBienvenida }        from "../../../bienvenida/oferta";
import { suscribirBienvenida }        from "../../../bienvenida/suscribir";
import { consumirLimite, ipDeRequest } from "../../../lib/rate-limit";

export const dynamic = "force-dynamic";

export async function GET() {
  return NextResponse.json({ success: true, data: await getOfertaBienvenida() });
}

export async function POST(req: NextRequest) {
  // Cada registro manda un correo: sin freno, sirve para bombardear
  // bandejas ajenas desde el dominio de la tienda.
  const limite = consumirLimite(`bienvenida:${ipDeRequest(req)}`, 5, 10 * 60_000);
  if (!limite.permitido) {
    return NextResponse.json(
      { success: false, error: "Demasiados intentos. Espera unos minutos." },
      { status: 429, headers: { "Retry-After": String(limite.esperaSegundos) } }
    );
  }

  try {
    const body = await req.json().catch(() => ({}));
    const r    = await suscribirBienvenida(body);
    if (!r.ok) {
      return NextResponse.json({ success: false, error: r.error }, { status: r.status });
    }
    return NextResponse.json({ success: true, codigo: r.codigo });
  } catch (err) {
    console.error("[POST /api/bienvenida]", err);
    return NextResponse.json({ success: false, error: "Error interno" }, { status: 500 });
  }
}
