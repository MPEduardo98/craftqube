// rutas/api/catalogo/route.ts
// La misma consulta que usan las páginas del servidor (getProductosCatalogo),
// para que el listado de la API y el de la página no se desfasen.
// sort: reciente | precio_asc | precio_desc | az | za | calificacion
import { NextRequest, NextResponse } from "next/server";
import { getProductosCatalogo }      from "../../../catalogo/getProductosCatalogo";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const page  = Math.max(1, Number(searchParams.get("page")  ?? 1));
  const limit = Math.min(48, Math.max(12, Number(searchParams.get("limit") ?? 24)));

  try {
    const { productos, total, pages } = await getProductosCatalogo({
      q:         searchParams.get("q")     ?? "",
      cat:       searchParams.get("cat")   ?? "",
      marca:     searchParams.get("marca") ?? "",
      soloStock: searchParams.get("stock") === "1",
      sort:      searchParams.get("sort")  ?? "reciente",
      page,
      limit,
    });

    return NextResponse.json(
      { success: true, data: productos, meta: { total, page, limit, pages } },
      { headers: { "Cache-Control": "public, s-maxage=60, stale-while-revalidate=300" } }
    );
  } catch (error) {
    console.error("[/api/catalogo] DB error:", error);
    return NextResponse.json(
      { success: false, error: "Error al conectar con la base de datos" },
      { status: 500 }
    );
  }
}
