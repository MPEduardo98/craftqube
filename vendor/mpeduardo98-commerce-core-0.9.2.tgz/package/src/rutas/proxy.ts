// rutas/proxy.ts
// ─────────────────────────────────────────────────────────────
// Proxy de Next.js 16 (antes middleware). Edge Runtime — corre
// ANTES de cualquier render.
//
// Capa 1 (optimista): solo PROTEGE rutas privadas comprobando la
// PRESENCIA de la cookie de sesión de Better Auth (sin validar firma
// ni consultar la BD; eso lo hace la Capa 2 en los layouts).
//
//   PROTEGIDAS (/cuenta, /admin)
//     → sin cookie de sesión → redirect /login
//
// El redirect de "invitado" (sacar a usuarios YA logueados de
// /login, /registro, …) NO se hace aquí: una cookie vieja/inválida
// pasaría el chequeo optimista y entraría en loop con la Capa 2.
// En su lugar, esas páginas usan `redirectIfAuthenticated()`, que
// valida la sesión REAL contra la BD.
//
// Uso en la tienda:
//   · Sin reglas propias → reexporta `proxy` (lo hace `instalar`).
//   · Con reglas propias → llama a `protegerRutas(req)` desde su
//     propio proxy y agrega lo suyo.
// El `config.matcher` siempre va escrito en el proxy de la tienda:
// Next lo lee del archivo, no de un reexport.
// ─────────────────────────────────────────────────────────────
import type { NextRequest } from "next/server";
import { NextResponse }     from "next/server";
import { getSessionCookie } from "better-auth/cookies";

/** Rutas que requieren estar autenticado */
const PROTEGIDAS: string[] = ["/cuenta", "/admin"];

function redirectToLogin(req: NextRequest): NextResponse {
  const url = req.nextUrl.clone();
  url.pathname = "/login";
  url.searchParams.set("redirect", req.nextUrl.pathname);
  return NextResponse.redirect(url);
}

/**
 * Redirige a /login si la ruta es privada y no hay cookie de sesión.
 * Devuelve null cuando no tiene nada que hacer con la petición.
 */
export function protegerRutas(req: NextRequest): NextResponse | null {
  const { pathname } = req.nextUrl;
  const esProtegida = PROTEGIDAS.some(
    (p) => pathname === p || pathname.startsWith(p + "/")
  );
  if (!esProtegida) return null;

  // Sin cookie de sesión → login. La Capa 2 valida firma + rol.
  if (!getSessionCookie(req)) return redirectToLogin(req);

  return null;
}

export function proxy(req: NextRequest) {
  return protegerRutas(req) ?? NextResponse.next();
}
