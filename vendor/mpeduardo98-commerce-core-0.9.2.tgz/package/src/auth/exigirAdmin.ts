// auth/exigirAdmin.ts
// ─────────────────────────────────────────────────────────────
// Candado de las APIs del panel (/api/admin/*). El proxy sólo mira
// que exista la cookie de sesión, y sólo en páginas: las APIs tienen
// que validar la sesión REAL y el rol por su cuenta. Sin esto,
// cualquiera podía leer pedidos o editar productos llamando a la API.
//
// Uso, primera línea de cada handler:
//   const bloqueo = await exigirAdmin();
//   if (bloqueo) return bloqueo;
// ─────────────────────────────────────────────────────────────
import { NextResponse } from "next/server";
import { headers }      from "next/headers";
import { auth }         from "./auth";

const ROLES_ADMIN = new Set(["admin", "superadmin"]);

/** null si quien llama es admin; si no, la respuesta 401/403 a devolver. */
export async function exigirAdmin(): Promise<NextResponse | null> {
  const session = await auth.api.getSession({ headers: await headers() });
  if (!session) {
    return NextResponse.json({ success: false, error: "Inicia sesión" }, { status: 401 });
  }
  const rol = (session.user as { rol?: string }).rol ?? "";
  if (!ROLES_ADMIN.has(rol)) {
    return NextResponse.json({ success: false, error: "No autorizado" }, { status: 403 });
  }
  return null;
}
