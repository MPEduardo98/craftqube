// venta/types.ts
// ─────────────────────────────────────────────────────────────
// Tipos del modo de venta. Sin dependencias: los usan el servidor,
// el panel y el frontend de la tienda.
// ─────────────────────────────────────────────────────────────

/**
 * tienda:   carrito, checkout y cobro en línea.
 * catalogo: sólo se muestran los productos; el cliente pide informes
 *           (WhatsApp, teléfono, correo) y la venta se cierra fuera.
 */
export type ModoVenta = "tienda" | "catalogo";

/** Ajustes → Modo de venta, tal como se guardan. */
export interface VentaConfig {
  modo:            ModoVenta;
  /** Sólo aplica en catálogo: en modo tienda los precios siempre se ven. */
  mostrarPrecios:  boolean;
  /** Número con lada de país, sólo dígitos (525512345678). Vacío = sin botón. */
  whatsapp:        string;
  /** Mensaje prellenado. Acepta {producto} y {url}. */
  mensajeWhatsapp: string;
}

/**
 * Lo que el frontend necesita para decidir qué pintar. Ya resuelto:
 * `mostrarPrecios` es true siempre que la tienda vende en línea.
 */
export interface VentaPublica {
  modo:            ModoVenta;
  /** true = hay carrito y checkout. */
  ventaEnLinea:    boolean;
  mostrarPrecios:  boolean;
  whatsapp:        string;
  mensajeWhatsapp: string;
}
