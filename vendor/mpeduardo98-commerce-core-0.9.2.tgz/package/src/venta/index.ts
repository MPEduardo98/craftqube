// Modo de venta: tienda en línea o catálogo. Este índice es de
// SERVIDOR (toca la base). En el navegador se importa
// "@mpeduardo98/commerce-core/venta/whatsapp" y "…/venta/types".
export * from "./config";
export * from "./exigirVentaEnLinea";
export * from "./whatsapp";
export type * from "./types";
