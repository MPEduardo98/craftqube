// venta/exigirVentaEnLinea.ts
// ─────────────────────────────────────────────────────────────
// Candado de las APIs de compra (resumen, cupones, envío, pago).
// Que el frontend esconda el carrito en modo catálogo no basta: las
// APIs siguen siendo alcanzables y un carrito viejo en localStorage
// podría llegar al checkout.
//
// No se aplica al webhook de Stripe: un pago iniciado antes de pasar
// a catálogo tiene que poder acreditarse.
//
// Uso, primera línea de cada handler:
//   const bloqueo = await exigirVentaEnLinea();
//   if (bloqueo) return bloqueo;
// ─────────────────────────────────────────────────────────────
import { NextResponse }  from "next/server";
import { ventaEnLinea }  from "./config";

/** null si la tienda vende en línea; si no, la respuesta 403 a devolver. */
export async function exigirVentaEnLinea(): Promise<NextResponse | null> {
  if (await ventaEnLinea()) return null;
  return NextResponse.json(
    {
      success: false,
      error:   "Esta tienda no acepta compras en línea. Contáctanos para hacer tu pedido.",
      codigo:  "modo_catalogo",
    },
    { status: 403 }
  );
}
