// venta/config.ts
// ─────────────────────────────────────────────────────────────
// Modo de venta (tabla `configuracion`). Se lee en cada página y en
// cada API de compra, así que va memoizado con un TTL corto, igual
// que getStoreConfig.
//
// Default "tienda": una tienda sin la clave sigue vendiendo como
// siempre. El modo catálogo se elige en Ajustes → Modo de venta.
// ─────────────────────────────────────────────────────────────
import { pool }               from "../db/pool";
import type { RowDataPacket } from "mysql2";
import type { VentaConfig, VentaPublica } from "./types";

export const MENSAJE_WHATSAPP_DEFAULT = "Hola, me interesa {producto} {url}";

const DEFAULTS: VentaConfig = {
  modo:            "tienda",
  mostrarPrecios:  true,
  whatsapp:        "",
  mensajeWhatsapp: MENSAJE_WHATSAPP_DEFAULT,
};
const TTL_MS = 30_000;

let cache: { value: VentaConfig; at: number } | null = null;

/**
 * Deja el número como lo pide wa.me: sólo dígitos, con lada de país.
 * Diez dígitos se asumen de México (la lada que casi siempre se olvida).
 */
export function normalizarWhatsapp(v: string): string {
  const digitos = v.replace(/\D/g, "");
  return digitos.length === 10 ? `52${digitos}` : digitos;
}

export async function getVentaConfig(): Promise<VentaConfig> {
  if (cache && Date.now() - cache.at < TTL_MS) return cache.value;
  try {
    const [rows] = await pool.query<RowDataPacket[]>(
      `SELECT clave, valor FROM configuracion
        WHERE clave IN ('venta_modo','venta_mostrar_precios','venta_whatsapp','venta_mensaje_whatsapp')`
    );
    const map = new Map(rows.map((r) => [r.clave as string, String(r.valor ?? "")]));
    const value: VentaConfig = {
      modo:            map.get("venta_modo") === "catalogo" ? "catalogo" : "tienda",
      mostrarPrecios:  map.get("venta_mostrar_precios") !== "0",
      whatsapp:        normalizarWhatsapp(map.get("venta_whatsapp") ?? ""),
      mensajeWhatsapp: map.get("venta_mensaje_whatsapp")?.trim() || DEFAULTS.mensajeWhatsapp,
    };
    cache = { value, at: Date.now() };
    return value;
  } catch (err) {
    console.error("[getVentaConfig]", err);
    return DEFAULTS;
  }
}

export async function setVentaConfig(patch: Partial<VentaConfig>): Promise<void> {
  const entries: [string, string][] = [];
  if (patch.modo            !== undefined) entries.push(["venta_modo", patch.modo]);
  if (patch.mostrarPrecios  !== undefined) entries.push(["venta_mostrar_precios", patch.mostrarPrecios ? "1" : "0"]);
  if (patch.whatsapp        !== undefined) entries.push(["venta_whatsapp", normalizarWhatsapp(patch.whatsapp)]);
  if (patch.mensajeWhatsapp !== undefined) entries.push(["venta_mensaje_whatsapp", patch.mensajeWhatsapp.trim()]);

  for (const [clave, valor] of entries) {
    await pool.execute(
      `INSERT INTO configuracion (clave, valor) VALUES (?, ?)
       ON DUPLICATE KEY UPDATE valor = VALUES(valor)`,
      [clave, valor]
    );
  }
  cache = null;
}

/** El modo ya resuelto para el frontend (ver VentaPublica). */
export async function getVentaPublica(): Promise<VentaPublica> {
  const cfg = await getVentaConfig();
  const ventaEnLinea = cfg.modo === "tienda";
  return {
    modo:            cfg.modo,
    ventaEnLinea,
    mostrarPrecios:  ventaEnLinea || cfg.mostrarPrecios,
    whatsapp:        cfg.whatsapp,
    mensajeWhatsapp: cfg.mensajeWhatsapp,
  };
}

/** true si la tienda cobra en línea. Atajo para las APIs de compra. */
export async function ventaEnLinea(): Promise<boolean> {
  return (await getVentaConfig()).modo === "tienda";
}
