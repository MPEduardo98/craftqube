// venta/whatsapp.ts
// ─────────────────────────────────────────────────────────────
// Enlace "Pedir informes por WhatsApp". Sin dependencias: se usa
// igual en páginas del servidor y en componentes de cliente.
//
//   enlaceWhatsApp(venta, { producto: p.titulo, url: location.href })
// ─────────────────────────────────────────────────────────────
import type { VentaPublica } from "./types";

/**
 * https://wa.me/… con el mensaje prellenado, o null si la tienda no
 * configuró número (entonces no se pinta el botón).
 * {producto} y {url} que no se pasen se quitan del mensaje.
 */
export function enlaceWhatsApp(
  venta: Pick<VentaPublica, "whatsapp" | "mensajeWhatsapp">,
  datos: { producto?: string; url?: string; mensaje?: string } = {},
): string | null {
  if (!venta.whatsapp) return null;

  const plantilla = datos.mensaje ?? venta.mensajeWhatsapp;
  const texto = plantilla
    .replace(/\{producto\}/g, datos.producto ?? "sus productos")
    .replace(/\{url\}/g, datos.url ?? "")
    .replace(/[ \t]+/g, " ")
    .trim();

  return `https://wa.me/${venta.whatsapp}${texto ? `?text=${encodeURIComponent(texto)}` : ""}`;
}
