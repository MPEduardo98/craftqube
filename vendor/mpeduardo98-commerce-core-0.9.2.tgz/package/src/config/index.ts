export * from "./store-config";
