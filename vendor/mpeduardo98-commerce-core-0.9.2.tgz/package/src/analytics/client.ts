"use client";
import type { Evento, EventoInput } from "./events";
const CONSENT = "cc-analytics-consent";
const SESSION = "cc-analytics-session";
export function analyticsConsent(): boolean {
  try { return navigator.doNotTrack !== "1" && localStorage.getItem(CONSENT) === "yes"; } catch { return false; }
}
export function setAnalyticsConsent(accepted: boolean) {
  try {
    localStorage.setItem(CONSENT, accepted ? "yes" : "no");
    if (!accepted) sessionStorage.removeItem(SESSION);
    window.dispatchEvent(new Event("cc-analytics-consent"));
  } catch { /* Storage unavailable: tracking stays disabled. */ }
}
export function track(event: Evento, data: Partial<Omit<EventoInput, "id" | "session" | "event">> = {}) {
  try {
    if (!analyticsConsent() || /^\/(admin|api)(\/|$)/.test(location.pathname)) return;
    const now = Date.now();
    let stored = JSON.parse(sessionStorage.getItem(SESSION) || "null") as { id: string; last: number } | null;
    if (!stored || now - stored.last > 30 * 60_000) stored = { id: crypto.randomUUID(), last: now };
    stored.last = now;
    sessionStorage.setItem(SESSION, JSON.stringify(stored));
    void fetch("/api/analytics", {
      method: "POST", headers: { "Content-Type": "application/json" }, keepalive: true,
      body: JSON.stringify({ ...data, event, id: crypto.randomUUID(), session: stored.id }),
    }).catch(() => {});
  } catch { /* Analytics must never interrupt shopping. */ }
}
