"use client";
import { useEffect, useRef, useState } from "react";
import { analyticsConsent, setAnalyticsConsent, track } from "./client";
import { EDADES, GENEROS } from "./events";

/** Mount once per public page, using a static page name (e.g. product, home). */
export function AnalyticsPage({ page, productId, checkout = false }: { page: string; productId?: number; checkout?: boolean }) {
  const last = useRef("");
  useEffect(() => {
    const visit = () => {
      if (!analyticsConsent()) { last.current = ""; return; }
      const key = `${page}:${productId ?? ""}:${checkout}`;
      if (last.current === key) return;
      last.current = key;
      track("page_view", { target: page });
      if (productId) track("product_view", { productId });
      if (checkout) track("checkout_start");
    };
    visit();
    window.addEventListener("cc-analytics-consent", visit);
    const click = (e: MouseEvent) => {
      const target = e.target instanceof Element ? e.target.closest("[data-analytics-click]")?.getAttribute("data-analytics-click") : null;
      if (target) track("click", { target });
    };
    document.addEventListener("click", click);
    return () => { window.removeEventListener("cc-analytics-consent", visit); document.removeEventListener("click", click); };
  }, [page, productId, checkout]);
  return null;
}

/** Place inside the registration form to measure the first actual interaction. */
export function AnalyticsRegistrationStart() {
  const ref = useRef<HTMLSpanElement>(null);
  useEffect(() => {
    const form = ref.current?.closest("form");
    let sent = false;
    const start = () => { if (!sent && analyticsConsent()) { sent = true; track("registration_start"); } };
    form?.addEventListener("input", start);
    return () => form?.removeEventListener("input", start);
  }, []);
  return <span ref={ref} hidden />;
}

export function AnalyticsConsent({ privacyUrl = "/privacidad" }: { privacyUrl?: string }) {
  const [visible, setVisible] = useState(false);
  useEffect(() => { try { setVisible(!localStorage.getItem("cc-analytics-consent") && navigator.doNotTrack !== "1"); } catch {} }, []);
  if (!visible) return null;
  return <aside aria-label="Preferencias de analítica" style={{ padding: 16, border: "1px solid #ddd", background: "white", color: "#171717" }}>
    <p>¿Nos permites medir visitas, clics y uso del carrito para mejorar la tienda? Es opcional. <a href={privacyUrl}>Aviso de privacidad</a></p>
    <button type="button" onClick={() => { setAnalyticsConsent(true); setVisible(false); }}>Aceptar</button>{" "}
    <button type="button" onClick={() => { setAnalyticsConsent(false); setVisible(false); }}>Rechazar</button>
  </aside>;
}

/** Optional, self-reported adult demographics. Never inferred from browsing. */
export function AnalyticsDemographics() {
  const [sent, setSent] = useState(false);
  const [allowed, setAllowed] = useState(false);
  useEffect(() => {
    const update = () => setAllowed(analyticsConsent());
    update(); window.addEventListener("cc-analytics-consent", update);
    return () => window.removeEventListener("cc-analytics-consent", update);
  }, []);
  if (!allowed) return null;
  if (sent) return <p>Gracias por compartir estos datos opcionales.</p>;
  return <form onSubmit={e => {
    e.preventDefault(); const data = new FormData(e.currentTarget);
    const age = String(data.get("age") || ""); const gender = String(data.get("gender") || "");
    if (!age && !gender) return;
    track("demographics", { age: age || undefined, gender: gender || undefined }); setSent(true);
  }}>
    <p>Encuesta opcional para mayores de 18 años. Puedes omitir cualquier respuesta.</p>
    <label>Rango de edad <select name="age"><option value="">No compartir</option>{EDADES.map(x => <option key={x}>{x}</option>)}</select></label>{" "}
    <label>Género <select name="gender"><option value="">No compartir</option>{GENEROS.map(x => <option key={x} value={x}>{x.replaceAll("_", " ")}</option>)}</select></label>{" "}
    <button type="submit">Compartir datos opcionales</button>
  </form>;
}
