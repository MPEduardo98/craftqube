export const EVENTOS = ["page_view", "product_view", "click", "registration_start", "registration_complete", "add_to_cart", "checkout_start", "demographics"] as const;
export type Evento = typeof EVENTOS[number];
export const EDADES = ["18-24", "25-34", "35-44", "45-54", "55-64", "65+"] as const;
export const GENEROS = ["mujer", "hombre", "no_binario", "otro", "prefiero_no_decir"] as const;
export interface EventoInput {
  id: string;
  session: string;
  event: Evento;
  productId?: number;
  quantity?: number;
  target?: string;
  age?: string;
  gender?: string;
}
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
export function validarEvento(value: unknown): EventoInput | null {
  if (!value || typeof value !== "object") return null;
  const v = value as Record<string, unknown>;
  if (typeof v.id !== "string" || !uuid.test(v.id) || typeof v.session !== "string" || !uuid.test(v.session) || !EVENTOS.includes(v.event as Evento)) return null;
  const result: EventoInput = { id: v.id, session: v.session, event: v.event as Evento };
  if (v.event === "product_view" || v.event === "add_to_cart") {
    if (!Number.isSafeInteger(v.productId) || Number(v.productId) < 1) return null;
    result.productId = Number(v.productId);
  }
  if (v.event === "add_to_cart") {
    if (!Number.isInteger(v.quantity) || Number(v.quantity) < 1 || Number(v.quantity) > 999) return null;
    result.quantity = Number(v.quantity);
  }
  if (v.event === "click" || v.event === "page_view") {
    // Static developer-defined labels only. Never URLs, form values or DOM text.
    if (typeof v.target !== "string" || !/^[a-z0-9_-]{1,80}$/.test(v.target)) return null;
    result.target = v.target;
  }
  if (v.event === "demographics") {
    if (v.age !== undefined && !EDADES.includes(v.age as typeof EDADES[number])) return null;
    if (v.gender !== undefined && !GENEROS.includes(v.gender as typeof GENEROS[number])) return null;
    if (!v.age && !v.gender) return null;
    result.age = v.age as string | undefined;
    result.gender = v.gender as string | undefined;
  }
  return result;
}
