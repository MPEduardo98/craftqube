import type { RowDataPacket } from "mysql2";
import { pool } from "../db";

export interface Bar { label: string; value: number }
export async function analyticsReport(days: number) {
  const start = new Date(); start.setUTCHours(0, 0, 0, 0); start.setUTCDate(start.getUTCDate() - days + 1);
  const from = start.toISOString().slice(0, 19).replace("T", " ");
  const query = async (sql: string, params: string[] = [from]) => (await pool.execute<RowDataPacket[]>(sql, params))[0];
  const [totals, accounts, daily, products, clicks, countries, ages, genders, registration] = await Promise.all([
    query(`SELECT COUNT(DISTINCT session_id) sessions,
      COALESCE(SUM(event='page_view'),0) views,
      COALESCE(SUM(CASE WHEN event='add_to_cart' THEN quantity ELSE 0 END),0) units,
      COUNT(DISTINCT CASE WHEN event='add_to_cart' THEN session_id END) carts,
      COUNT(DISTINCT CASE WHEN event='checkout_start' THEN session_id END) checkouts
      FROM analytics_events WHERE created_at >= ?`),
    query(`SELECT COUNT(*) total, COALESCE(SUM(created_at >= ?),0) recent FROM usuarios WHERE deleted_at IS NULL AND rol='cliente'`),
    query(`SELECT DATE_FORMAT(created_at,'%Y-%m-%d') label, COUNT(*) value FROM analytics_events WHERE created_at >= ? AND event='page_view' GROUP BY label ORDER BY label`),
    query(`SELECT COALESCE(p.titulo, CONCAT('Producto #',e.product_id)) label, COUNT(*) value
      FROM analytics_events e LEFT JOIN productos p ON p.id=e.product_id
      WHERE e.created_at >= ? AND e.event='product_view' GROUP BY e.product_id,p.titulo ORDER BY value DESC LIMIT 10`),
    query(`SELECT target label, COUNT(*) value FROM analytics_events WHERE created_at >= ? AND event='click' GROUP BY target ORDER BY value DESC LIMIT 10`),
    query(`SELECT COALESCE(country,'Sin determinar') label, COUNT(DISTINCT session_id) value FROM analytics_events WHERE created_at >= ? GROUP BY country ORDER BY value DESC LIMIT 20`),
    query(`SELECT age_range label, COUNT(*) value FROM analytics_events e WHERE created_at >= ? AND event='demographics' AND age_range IS NOT NULL
      AND NOT EXISTS (SELECT 1 FROM analytics_events n WHERE n.session_id=e.session_id AND n.event='demographics' AND (n.created_at>e.created_at OR (n.created_at=e.created_at AND n.id>e.id))) GROUP BY age_range ORDER BY age_range`),
    query(`SELECT gender label, COUNT(*) value FROM analytics_events e WHERE created_at >= ? AND event='demographics' AND gender IS NOT NULL
      AND NOT EXISTS (SELECT 1 FROM analytics_events n WHERE n.session_id=e.session_id AND n.event='demographics' AND (n.created_at>e.created_at OR (n.created_at=e.created_at AND n.id>e.id))) GROUP BY gender ORDER BY value DESC`),
    query(`SELECT COUNT(*) started, COALESCE(SUM(completed),0) completed,
      COALESCE(SUM(completed=0 AND last_seen < UTC_TIMESTAMP() - INTERVAL 30 MINUTE),0) abandoned
      FROM (SELECT session_id, MAX(created_at) last_seen,
        MAX(event='registration_complete') completed
        FROM analytics_events WHERE created_at >= ? GROUP BY session_id
        HAVING MAX(event='registration_start')=1) s`),
  ]);
  const bars = (rows: RowDataPacket[]): Bar[] => rows.map(r => ({ label: String(r.label).replaceAll("_", " "), value: Number(r.value) }));
  const dailyMap = new Map(bars(daily).map(r => [r.label, r.value]));
  const timeline = Array.from({ length: days }, (_, i) => {
    const d = new Date(start); d.setUTCDate(d.getUTCDate() + i); const label = d.toISOString().slice(0, 10);
    return { label, value: dailyMap.get(label) ?? 0 };
  });
  return { totals: totals[0], accounts: accounts[0], registration: registration[0], daily: timeline,
    products: bars(products), clicks: bars(clicks), countries: bars(countries), ages: bars(ages), genders: bars(genders) };
}
