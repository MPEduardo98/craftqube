// bienvenida/types.ts
import type { CuponTipo } from "../types/commerce";

/** Ajustes → Bienvenida. */
export interface BienvenidaConfig {
  activa:   boolean;
  /** Cupón que se entrega al suscribirse. null = ninguno elegido. */
  cupon_id: number | null;
}

/**
 * Lo que la tienda necesita para pintar el modal antes del registro.
 * El código no va aquí: se entrega al suscribirse.
 */
export interface OfertaBienvenida {
  tipo:          CuponTipo;
  /** % o monto según `tipo`; ya en la moneda de la tienda. */
  valor:         number;
  /** Texto listo para el modal: "10% de descuento", "Envío gratis"… */
  texto:         string;
  /** Compra mínima para usarlo, en moneda de la tienda. null = sin mínimo. */
  minimo_compra: number | null;
  moneda:        string;
}

/** Fila de `suscriptores` para el panel. */
export interface Suscriptor {
  id:               number;
  email:            string;
  nombre:           string;
  origen:           string;
  cupon_codigo:     string | null;
  acepta_marketing: boolean;
  /** Ya hizo un pedido pagado con ese correo. */
  compro:           boolean;
  created_at:       string;
}
