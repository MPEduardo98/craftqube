"use client";
// bienvenida/useBienvenida.ts
// ─────────────────────────────────────────────────────────────
// Lógica del modal de bienvenida; el diseño lo pone cada tienda.
//
//   const b = useBienvenida();
//   if (!b.visible || !b.oferta) return null;
//   … <h2>{b.oferta.texto}</h2> …
//   … <form onSubmit={() => b.enviar({ nombre, email })}> …
//   … b.estado === "enviado" → mostrar b.codigo (con botón de copiar) …
//   … <button onClick={b.cerrar}> …
//
// Decide cuándo aparece: sólo si la tienda tiene la promoción
// activa, tras `retrasoMs`, y no otra vez a quien ya se suscribió o
// lo cerró hace menos de `diasOcultar` días (se recuerda en este
// navegador).
// ─────────────────────────────────────────────────────────────
import { useCallback, useEffect, useState } from "react";
import type { OfertaBienvenida } from "./types";

const CLAVE = "commerce-core:bienvenida";

type Recuerdo = { suscrito: true; codigo?: string } | { cerradoHasta: number };

function leer(): Recuerdo | null {
  try {
    const raw = localStorage.getItem(CLAVE);
    return raw ? (JSON.parse(raw) as Recuerdo) : null;
  } catch { return null; }
}

function guardar(r: Recuerdo) {
  try { localStorage.setItem(CLAVE, JSON.stringify(r)); } catch { /* modo privado */ }
}

function debeOcultarse(): boolean {
  const r = leer();
  if (!r) return false;
  if ("suscrito" in r) return true;
  return r.cerradoHasta > Date.now();
}

export type EstadoBienvenida = "idle" | "enviando" | "enviado" | "error";

export interface OpcionesBienvenida {
  /** Milisegundos antes de mostrarlo. Default 5000. */
  retrasoMs?:   number;
  /** Días sin volver a mostrarlo tras cerrarlo. Default 7. */
  diasOcultar?: number;
  /** false para no mostrarlo en esta página (checkout, cuenta…). */
  habilitado?:  boolean;
}

export function useBienvenida(opciones: OpcionesBienvenida = {}) {
  const { retrasoMs = 5000, diasOcultar = 7, habilitado = true } = opciones;

  const [oferta,  setOferta]  = useState<OfertaBienvenida | null>(null);
  const [visible, setVisible] = useState(false);
  const [estado,  setEstado]  = useState<EstadoBienvenida>("idle");
  const [error,   setError]   = useState("");
  // Si ya se suscribió en este navegador, el código queda a la mano
  // (p. ej. para recordárselo en el carrito).
  const [codigo,  setCodigo]  = useState<string | null>(null);

  useEffect(() => {
    const r = leer();
    if (r && "suscrito" in r && r.codigo) setCodigo(r.codigo);
  }, []);

  // Trae la oferta sólo si hace falta: quien ya se suscribió no pide nada.
  useEffect(() => {
    if (!habilitado || debeOcultarse()) return;
    let vivo = true;
    fetch("/api/bienvenida")
      .then((r) => r.json())
      .then((j) => { if (vivo && j.success) setOferta(j.data ?? null); })
      .catch(() => {});
    return () => { vivo = false; };
  }, [habilitado]);

  useEffect(() => {
    if (!oferta || !habilitado) return;
    const t = setTimeout(() => { if (!debeOcultarse()) setVisible(true); }, retrasoMs);
    return () => clearTimeout(t);
  }, [oferta, habilitado, retrasoMs]);

  /** Cierra y no lo vuelve a mostrar en `diasOcultar` días (si ya se suscribió, nunca). */
  const cerrar = useCallback(() => {
    setVisible(false);
    if (!("suscrito" in (leer() ?? {}))) {
      guardar({ cerradoHasta: Date.now() + diasOcultar * 86_400_000 });
    }
  }, [diasOcultar]);

  /** Para abrirlo a mano (un botón "10% de descuento" en el footer, p. ej.). */
  const abrir = useCallback(() => { if (oferta) setVisible(true); }, [oferta]);

  const enviar = useCallback(async (datos: {
    nombre:            string;
    email:             string;
    /** Si aceptó recibir promociones. Default true. */
    acepta_marketing?: boolean;
  }): Promise<boolean> => {
    setEstado("enviando");
    setError("");
    try {
      const res  = await fetch("/api/bienvenida", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify(datos),
      });
      const json = await res.json();
      if (!json.success) {
        setEstado("error");
        setError(json.error ?? "No se pudo completar el registro.");
        return false;
      }
      guardar({ suscrito: true, codigo: json.codigo });
      setCodigo(json.codigo ?? null);
      setEstado("enviado");
      return true;
    } catch {
      setEstado("error");
      setError("Error de conexión. Intenta de nuevo.");
      return false;
    }
  }, []);

  return { oferta, visible, estado, error, codigo, enviar, cerrar, abrir };
}
