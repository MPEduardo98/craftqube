// bienvenida/restriccion.ts
// ─────────────────────────────────────────────────────────────
// El cupón de bienvenida es personal: sólo lo usa un correo que se
// suscribió y lo recibió. Así, si el código se comparte en redes,
// no sirve para nadie más.
//
// Un cupón queda restringido si es el que está elegido en Ajustes o
// si ya se le envió a alguien (aunque después se cambie por otro,
// quienes lo recibieron lo siguen pudiendo usar).
// ─────────────────────────────────────────────────────────────
import type { Pool, PoolConnection, RowDataPacket } from "mysql2/promise";
import { getBienvenidaConfig } from "./config";

/** null si el comprador puede usarlo; si no, el motivo para mostrar. */
export async function restriccionBienvenida(
  db:      Pool | PoolConnection,
  cuponId: number,
  email:   string | null,
): Promise<string | null> {
  const cfg = await getBienvenidaConfig();

  let filas: RowDataPacket[];
  try {
    [filas] = await db.execute<RowDataPacket[]>(
      `SELECT EXISTS(SELECT 1 FROM suscriptores WHERE cupon_id = ?)                     AS enviado,
              EXISTS(SELECT 1 FROM suscriptores WHERE cupon_id = ? AND email = ?)       AS suyo`,
      [cuponId, cuponId, (email ?? "").trim().toLowerCase()]
    );
  } catch (err) {
    // Tienda que aún no corre `migrar`: sin tabla no hay suscriptores,
    // y el resto de los cupones tiene que seguir funcionando.
    if ((err as { code?: string }).code === "ER_NO_SUCH_TABLE") return null;
    throw err;
  }
  const restringido = cfg.cupon_id === cuponId || Number(filas[0]?.enviado) === 1;
  if (!restringido) return null;

  // Sin correo todavía (vista previa antes de llenar el contacto) no
  // se puede comprobar: se permite y se vuelve a revisar al pagar.
  if (!email) return null;

  return Number(filas[0]?.suyo) === 1
    ? null
    : "Este cupón es de bienvenida: úsalo con el correo con el que te suscribiste.";
}
