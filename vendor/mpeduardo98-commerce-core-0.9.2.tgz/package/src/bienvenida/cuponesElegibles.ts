// bienvenida/cuponesElegibles.ts
// Cupones que el admin puede elegir en Ajustes → Bienvenida.
import type { RowDataPacket } from "mysql2";
import { pool }               from "../db/pool";
import type { CuponTipo, CuponAplica } from "../types/commerce";

export interface CuponElegible {
  id:                 number;
  codigo:             string;
  descripcion:        string | null;
  tipo:               CuponTipo;
  valor:              number;
  aplica_a:           CuponAplica;
  uso_maximo_usuario: number;
  /** Activo, dentro de fechas y sin agotar. */
  vigente:            boolean;
}

export async function listarCuponesElegibles(): Promise<CuponElegible[]> {
  const [filas] = await pool.query<RowDataPacket[]>(`
    SELECT id, codigo, descripcion, tipo, valor, aplica_a, uso_maximo_usuario,
           (activo = 1
             AND (valido_desde IS NULL OR valido_desde <= NOW())
             AND (valido_hasta IS NULL OR valido_hasta >= NOW())
             AND (uso_maximo_total IS NULL OR usos_actuales < uso_maximo_total)) AS vigente
      FROM cupones
     ORDER BY vigente DESC, created_at DESC
     LIMIT 200
  `);
  return filas.map((f) => ({
    id:                 Number(f.id),
    codigo:             String(f.codigo),
    descripcion:        f.descripcion ?? null,
    tipo:               f.tipo as CuponTipo,
    valor:              Number(f.valor),
    aplica_a:           f.aplica_a as CuponAplica,
    uso_maximo_usuario: Number(f.uso_maximo_usuario),
    vigente:            Number(f.vigente) === 1,
  }));
}
