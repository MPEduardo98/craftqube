// bienvenida/suscribir.ts
// ─────────────────────────────────────────────────────────────
// Registro desde el modal de bienvenida: guarda al cliente
// potencial y le devuelve el código para mostrarlo en el modal.
// También se lo manda por correo, como copia para después.
//
// Mostrarlo en pantalla no lo regala: el cupón sólo funciona al
// pagar con el correo suscrito (ver restriccion.ts).
//
// La respuesta es la misma para un correo nuevo que para uno ya
// suscrito: no se revela quién está en la lista.
// ─────────────────────────────────────────────────────────────
import type { ResultSetHeader, RowDataPacket } from "mysql2";
import { pool }                 from "../db/pool";
import { getStorePricing, toStoreCurrency } from "../currency/store-currency";
import { formatMoneda }         from "../lib/format";
import { sendCuponBienvenidaEmail } from "../email/send";
import { urlSitio }             from "../seo/sitio";
import type { CuponTipo }       from "../types/commerce";
import { getBienvenidaConfig }  from "./config";
import { cuponBienvenidaVigente, textoOferta } from "./oferta";
import { ventaEnLinea }         from "../venta/config";

/** Minutos antes de volver a mandar el correo al mismo suscriptor. */
const REENVIO_MIN = 10;

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export type ResultadoSuscripcion =
  | { ok: true; codigo: string }
  | { ok: false; error: string; status: number };

export async function suscribirBienvenida(datos: {
  nombre:            unknown;
  email:             unknown;
  acepta_marketing?: unknown;
}): Promise<ResultadoSuscripcion> {
  const nombre = typeof datos.nombre === "string" ? datos.nombre.trim().replace(/\s+/g, " ") : "";
  const email  = typeof datos.email  === "string" ? datos.email.trim().toLowerCase() : "";

  if (!nombre || nombre.length > 100) {
    return { ok: false, error: "Escribe tu nombre.", status: 400 };
  }
  if (!EMAIL_RE.test(email) || email.length > 180) {
    return { ok: false, error: "Escribe un correo válido.", status: 400 };
  }

  const cfg   = await getBienvenidaConfig();
  const vende = await ventaEnLinea();
  const cupon = vende && cfg.activa && cfg.cupon_id ? await cuponBienvenidaVigente(cfg.cupon_id) : null;
  if (!cupon) {
    return { ok: false, error: "Esta promoción ya no está disponible.", status: 409 };
  }

  const aceptaMarketing = datos.acepta_marketing === false ? 0 : 1;

  // Un correo, una fila. Si ya existía se conserva el nombre original
  // (quien escribe ahora podría no ser el dueño del correo).
  await pool.execute(
    `INSERT INTO suscriptores (email, nombre, cupon_id, acepta_marketing)
     VALUES (?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE cupon_id = VALUES(cupon_id)`,
    [email, nombre, cupon.id, aceptaMarketing]
  );

  // Reserva el envío de forma atómica: dos envíos del formulario casi
  // al mismo tiempo, o alguien metiendo el correo de otro una y otra
  // vez, no llenan su bandeja.
  const [reserva] = await pool.execute<ResultSetHeader>(
    `UPDATE suscriptores
        SET ultimo_envio_at = NOW()
      WHERE email = ?
        AND (ultimo_envio_at IS NULL OR ultimo_envio_at < NOW() - INTERVAL ${REENVIO_MIN} MINUTE)`,
    [email]
  );
  const codigo = String(cupon.codigo);
  if (reserva.affectedRows === 0) return { ok: true, codigo };

  const [[fila]] = await pool.query<RowDataPacket[]>(
    "SELECT nombre FROM suscriptores WHERE email = ?",
    [email]
  );

  const pricing = await getStorePricing();
  const tipo    = String(cupon.tipo) as CuponTipo;
  const valor   = tipo === "monto_fijo"
    ? toStoreCurrency(Number(cupon.valor), pricing) ?? 0
    : Number(cupon.valor);
  const minimo  = cupon.minimo_compra == null ? null : toStoreCurrency(Number(cupon.minimo_compra), pricing);

  const envio = await sendCuponBienvenidaEmail(email, {
    nombre:    String(fila?.nombre ?? nombre),
    codigo,
    oferta:    textoOferta(tipo, valor, pricing.monedaTienda),
    condicion: minimo ? `Compra mínima de ${formatMoneda(minimo, pricing.monedaTienda)}.` : "",
    vence:     cupon.valido_hasta
      ? new Date(cupon.valido_hasta).toLocaleDateString("es-MX", { day: "numeric", month: "long", year: "numeric" })
      : "",
    tiendaUrl: urlSitio(),
  });

  if (!envio.success) {
    // El código ya se muestra en el modal: un correo fallido no
    // bloquea el registro. Se libera la reserva para reintentarlo.
    await pool.execute("UPDATE suscriptores SET ultimo_envio_at = NULL WHERE email = ?", [email]);
  }

  return { ok: true, codigo };
}
