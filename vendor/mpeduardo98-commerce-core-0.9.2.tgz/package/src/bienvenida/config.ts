// bienvenida/config.ts
// ─────────────────────────────────────────────────────────────
// Ajustes del modal de bienvenida (tabla `configuracion`).
// Memoizado con TTL corto: la tienda lo consulta en cada visita y
// resolverCupon en cada cálculo de totales.
//
// Default apagado y sin cupón: una tienda no muestra el modal hasta
// que elige qué cupón regalar.
// ─────────────────────────────────────────────────────────────
import { pool }               from "../db/pool";
import type { RowDataPacket } from "mysql2";
import type { BienvenidaConfig } from "./types";

const DEFAULTS: BienvenidaConfig = { activa: false, cupon_id: null };
const TTL_MS = 30_000;

let cache: { value: BienvenidaConfig; at: number } | null = null;

export async function getBienvenidaConfig(): Promise<BienvenidaConfig> {
  if (cache && Date.now() - cache.at < TTL_MS) return cache.value;
  try {
    const [rows] = await pool.query<RowDataPacket[]>(
      "SELECT clave, valor FROM configuracion WHERE clave IN ('bienvenida_activa','bienvenida_cupon_id')"
    );
    const map = new Map(rows.map((r) => [r.clave as string, String(r.valor ?? "")]));
    const id  = Number(map.get("bienvenida_cupon_id"));
    const value: BienvenidaConfig = {
      activa:   map.get("bienvenida_activa") === "1",
      cupon_id: Number.isInteger(id) && id > 0 ? id : null,
    };
    cache = { value, at: Date.now() };
    return value;
  } catch (err) {
    console.error("[getBienvenidaConfig]", err);
    return DEFAULTS;
  }
}

export async function setBienvenidaConfig(patch: Partial<BienvenidaConfig>): Promise<void> {
  const entries: [string, string][] = [];
  if (patch.activa   !== undefined) entries.push(["bienvenida_activa", patch.activa ? "1" : "0"]);
  if (patch.cupon_id !== undefined) entries.push(["bienvenida_cupon_id", patch.cupon_id ? String(patch.cupon_id) : ""]);

  for (const [clave, valor] of entries) {
    await pool.execute(
      `INSERT INTO configuracion (clave, valor) VALUES (?, ?)
       ON DUPLICATE KEY UPDATE valor = VALUES(valor)`,
      [clave, valor]
    );
  }
  cache = null;
}
