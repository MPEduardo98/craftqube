// bienvenida/oferta.ts
// ─────────────────────────────────────────────────────────────
// El cupón de bienvenida tal como lo ve la tienda. Si el modal está
// apagado o el cupón elegido ya no sirve (desactivado, vencido,
// agotado), no hay oferta: la tienda no muestra el modal en vez de
// prometer un descuento que el checkout va a rechazar. Lo mismo en
// modo catálogo: no hay checkout donde usar el cupón.
// ─────────────────────────────────────────────────────────────
import type { RowDataPacket } from "mysql2";
import { pool }               from "../db/pool";
import { getStorePricing, toStoreCurrency } from "../currency/store-currency";
import { formatMoneda }       from "../lib/format";
import type { CuponTipo }     from "../types/commerce";
import { getBienvenidaConfig } from "./config";
import { ventaEnLinea }       from "../venta/config";
import type { OfertaBienvenida } from "./types";

/** Cupón vigente con sus datos crudos, o null. */
export async function cuponBienvenidaVigente(cuponId: number): Promise<RowDataPacket | null> {
  const [filas] = await pool.execute<RowDataPacket[]>(
    `SELECT id, codigo, tipo, valor, minimo_compra, valido_hasta
       FROM cupones
      WHERE id = ?
        AND activo = 1
        AND (valido_desde IS NULL OR valido_desde <= NOW())
        AND (valido_hasta IS NULL OR valido_hasta >= NOW())
        AND (uso_maximo_total IS NULL OR usos_actuales < uso_maximo_total)
      LIMIT 1`,
    [cuponId]
  );
  return filas[0] ?? null;
}

export function textoOferta(tipo: CuponTipo, valor: number, moneda: string): string {
  if (tipo === "porcentaje")   return `${Number(valor.toFixed(2))}% de descuento`;
  if (tipo === "monto_fijo")   return `${formatMoneda(valor, moneda)} de descuento`;
  if (tipo === "envio_gratis") return "Envío gratis";
  return "2x1";
}

/** Oferta pública del modal, o null si no se debe mostrar. */
export async function getOfertaBienvenida(): Promise<OfertaBienvenida | null> {
  const cfg = await getBienvenidaConfig();
  if (!cfg.activa || !cfg.cupon_id) return null;
  if (!(await ventaEnLinea())) return null;

  try {
    const cupon = await cuponBienvenidaVigente(cfg.cupon_id);
    if (!cupon) return null;

    const pricing = await getStorePricing();
    const tipo    = String(cupon.tipo) as CuponTipo;
    // El % no se convierte; los importes sí, como los precios.
    const valor   = tipo === "monto_fijo"
      ? toStoreCurrency(Number(cupon.valor), pricing) ?? 0
      : Number(cupon.valor);

    return {
      tipo,
      valor,
      texto:         textoOferta(tipo, valor, pricing.monedaTienda),
      minimo_compra: cupon.minimo_compra == null ? null : toStoreCurrency(Number(cupon.minimo_compra), pricing),
      moneda:        pricing.monedaTienda,
    };
  } catch (err) {
    console.error("[getOfertaBienvenida]", err);
    return null;
  }
}
