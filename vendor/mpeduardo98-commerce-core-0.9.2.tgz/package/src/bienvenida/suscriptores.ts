// bienvenida/suscriptores.ts
// Lista de clientes potenciales para el panel (y su exportación).
import type { RowDataPacket } from "mysql2";
import { pool }               from "../db/pool";
import type { Suscriptor }    from "./types";

/** Mismos estados que cuentan como compra real en los cupones. */
const ESTADOS_COMPRA = [
  "pago_recibido", "en_proceso", "listo_envio", "enviado", "entregado", "reembolsado", "disputa",
];

export async function listarSuscriptores(opciones: {
  q?:     string;
  page?:  number;
  /** 0 = todos (exportación). */
  limit?: number;
}): Promise<{ suscriptores: Suscriptor[]; total: number; compraron: number }> {
  const q     = (opciones.q ?? "").trim();
  const limit = opciones.limit ?? 50;
  const page  = Math.max(1, opciones.page ?? 1);

  const where  = q ? "WHERE s.email LIKE ? OR s.nombre LIKE ?" : "";
  const params = q ? [`%${q}%`, `%${q}%`] : [];
  const compro = `EXISTS(SELECT 1 FROM pedidos p
                          WHERE LOWER(p.email) = s.email
                            AND p.estado IN (${ESTADOS_COMPRA.map(() => "?").join(",")}))`;

  const [filas] = await pool.query<RowDataPacket[]>(
    `SELECT s.id, s.email, s.nombre, s.origen, s.acepta_marketing, s.created_at,
            c.codigo AS cupon_codigo,
            ${compro} AS compro
       FROM suscriptores s
       LEFT JOIN cupones c ON c.id = s.cupon_id
       ${where}
      ORDER BY s.created_at DESC, s.id DESC
      ${limit > 0 ? "LIMIT ? OFFSET ?" : ""}`,
    [...ESTADOS_COMPRA, ...params, ...(limit > 0 ? [limit, (page - 1) * limit] : [])]
  );

  const [[conteo]] = await pool.query<RowDataPacket[]>(
    `SELECT COUNT(*) AS total, COALESCE(SUM(${compro}), 0) AS compraron FROM suscriptores s ${where}`,
    [...ESTADOS_COMPRA, ...params]
  );

  return {
    suscriptores: filas.map((f) => ({
      id:               Number(f.id),
      email:            String(f.email),
      nombre:           String(f.nombre),
      origen:           String(f.origen),
      cupon_codigo:     f.cupon_codigo ? String(f.cupon_codigo) : null,
      acepta_marketing: Number(f.acepta_marketing) === 1,
      compro:           Number(f.compro) === 1,
      created_at:       new Date(f.created_at).toISOString(),
    })),
    total:     Number(conteo?.total ?? 0),
    compraron: Number(conteo?.compraron ?? 0),
  };
}

/** CSV para importar en herramientas de correo. */
export function suscriptoresCsv(filas: Suscriptor[]): string {
  const celda = (v: string) => {
    // Evita que Excel ejecute fórmulas escritas en el nombre.
    const seguro = /^[=+\-@]/.test(v) ? `'${v}` : v;
    return `"${seguro.replace(/"/g, '""')}"`;
  };
  const lineas = [
    ["nombre", "email", "acepta_marketing", "cupon", "compro", "fecha"].join(","),
    ...filas.map((s) => [
      celda(s.nombre),
      celda(s.email),
      s.acepta_marketing ? "si" : "no",
      celda(s.cupon_codigo ?? ""),
      s.compro ? "si" : "no",
      s.created_at.slice(0, 10),
    ].join(",")),
  ];
  // BOM para que Excel lea bien los acentos.
  return "﻿" + lineas.join("\r\n");
}
