export * from "./getProductoBySlug";
export * from "./getProductosCatalogo";
export * from "./getAllSlugs";
export * from "./getCategorias";
export * from "./getCategoriaBySlug";
export type * from "./types/product";
export type * from "./types/product-detail";
