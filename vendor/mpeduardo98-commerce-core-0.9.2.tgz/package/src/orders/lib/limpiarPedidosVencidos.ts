// features/orders/lib/limpiarPedidosVencidos.ts
// ─────────────────────────────────────────────────────────────
// Cancela los pedidos que llevan demasiado tiempo en
// `pendiente_pago` y devuelve lo que tenían apartado.
//
// Por qué hace falta: `createPedido` descuenta stock y quema el uso
// del cupón en el momento de crear el pedido, ANTES de cobrar. Si el
// comprador abandona el checkout, esos recursos quedan retenidos para
// siempre. Stripe cancela solo los PaymentIntent de OXXO y SPEI al
// vencer (y el webhook lo recoge), pero uno de tarjeta en
// `requires_payment_method` vive indefinidamente: sin este barrido,
// cada checkout de tarjeta abandonado es stock que nunca vuelve.
//
// El plazo depende del método porque la promesa al comprador también:
// un voucher OXXO vale 72 h y cancelarlo antes sería romperla.
// ─────────────────────────────────────────────────────────────
import type { PoolConnection, RowDataPacket, ResultSetHeader } from "mysql2/promise";
import Stripe        from "stripe";
import { pool }      from "../../db/pool";
import { getStripe } from "../../stripe/client";

/**
 * Minutos que un pedido puede esperar el pago según cómo se iba a
 * pagar. Tarjeta es el único caso donde Stripe no expira nada por su
 * cuenta, y también el más rápido de completar: 60 min es holgado.
 *
 * Para OXXO y SPEI el barrido NO es el mecanismo principal —lo es el
 * webhook— sino la red por si un evento se perdió; de ahí el margen
 * por encima de los 3 días de vigencia del voucher.
 */
const PLAZOS_MINUTOS = {
  tarjeta:       60,
  oxxo:          4 * 24 * 60,
  transferencia: 4 * 24 * 60,
} as const;

/** Sin método declarado se aplica el plazo más conservador. */
const PLAZO_PREDETERMINADO = 4 * 24 * 60;

/** Techo de pedidos por ejecución: acota la duración de la petición. */
const MAX_POR_EJECUCION = 100;

interface PedidoVencido {
  id:              number;
  numero:          string;
  metodo_pago:     string | null;
  referencia_pago: string | null;
  cupon_id:        number | null;
  minutos:         number;
}

export interface ResultadoLimpieza {
  revisados:  number;
  cancelados: number;
  omitidos:   number;
  numeros:    string[];
}

/**
 * Pedidos en `pendiente_pago` que ya pasaron su plazo. El plazo se
 * resuelve en SQL con el método de cada fila, así una sola consulta
 * cubre los tres a la vez sin traerse pedidos que aún están a tiempo.
 */
async function buscarVencidos(): Promise<PedidoVencido[]> {
  const [filas] = await pool.execute<RowDataPacket[]>(
    `SELECT id, numero, metodo_pago, referencia_pago, cupon_id,
            TIMESTAMPDIFF(MINUTE, created_at, NOW()) AS minutos
       FROM pedidos
      WHERE estado = 'pendiente_pago'
        AND TIMESTAMPDIFF(MINUTE, created_at, NOW()) >= CASE metodo_pago
              WHEN 'tarjeta'       THEN ?
              WHEN 'oxxo'          THEN ?
              WHEN 'transferencia' THEN ?
              ELSE ?
            END
      ORDER BY created_at ASC
      LIMIT ${MAX_POR_EJECUCION}`,
    [
      PLAZOS_MINUTOS.tarjeta,
      PLAZOS_MINUTOS.oxxo,
      PLAZOS_MINUTOS.transferencia,
      PLAZO_PREDETERMINADO,
    ]
  );
  return filas as PedidoVencido[];
}

/**
 * Anula el PaymentIntent en Stripe antes de tocar la BD.
 *
 * Es lo que cierra el hueco de que el comprador pague desde una
 * pestaña vieja un pedido cuyo stock ya devolvimos. Devuelve `false`
 * si el cobro ya no se puede anular —porque se pagó o está en curso—:
 * ese pedido se deja intacto y lo resuelve el webhook.
 */
async function anularCobro(referencia: string | null): Promise<boolean> {
  if (!referencia) return true; // nunca llegó a haber cobro que anular

  let stripe: Stripe;
  try {
    stripe = getStripe();
  } catch (err) {
    // Sin claves de Stripe no se puede garantizar que el cobro esté
    // muerto, así que no se cancela nada: mejor stock retenido que un
    // pedido cancelado que el comprador todavía puede pagar.
    console.error("[limpiarPedidos] Stripe no configurado:", err);
    return false;
  }

  try {
    const pi = await stripe.paymentIntents.retrieve(referencia);

    // Ya está muerto: no hay nada que anular y el pedido puede cerrarse.
    if (pi.status === "canceled") return true;

    // Pagado o cobrando: el pedido está vivo aunque la BD aún no lo
    // sepa. Se deja para el webhook.
    if (pi.status === "succeeded" || pi.status === "processing") return false;

    await stripe.paymentIntents.cancel(referencia, { cancellation_reason: "abandoned" });
    return true;
  } catch (err) {
    // `No such payment_intent`: referencia creada con las claves de
    // otra cuenta (migración de entorno). No hay cobro real que proteger.
    if (err instanceof Stripe.errors.StripeInvalidRequestError && err.code === "resource_missing") {
      return true;
    }
    console.warn(`[limpiarPedidos] No se pudo anular ${referencia}:`, err);
    return false;
  }
}

/** Devuelve al inventario lo que el pedido tenía apartado. */
async function devolverStock(conn: PoolConnection, pedidoId: number) {
  const [items] = await conn.execute<RowDataPacket[]>(
    "SELECT variante_id, cantidad FROM pedido_items WHERE pedido_id = ?",
    [pedidoId]
  );
  for (const item of items) {
    if (item.variante_id == null) continue;
    await conn.execute(
      `UPDATE producto_variantes
          SET stock = stock + ?
        WHERE id = ? AND vender_sin_existencia = 0`,
      [Number(item.cantidad), Number(item.variante_id)]
    );
  }
}

/**
 * Suelta el uso de cupón que `createPedido` había apuntado. Sin esto,
 * un cupón de un solo uso queda muerto tras un checkout abandonado.
 *
 * Sólo se descuenta el contador si el DELETE encontró realmente un uso
 * de ESTE pedido: así una segunda pasada no puede restar dos veces.
 */
async function liberarCupon(conn: PoolConnection, pedidoId: number, cuponId: number | null) {
  if (!cuponId) return;

  const [res] = await conn.execute<ResultSetHeader>(
    "DELETE FROM cupon_usos WHERE pedido_id = ?",
    [pedidoId]
  );

  if (res.affectedRows > 0) {
    await conn.execute(
      "UPDATE cupones SET usos_actuales = usos_actuales - 1 WHERE id = ? AND usos_actuales > 0",
      [cuponId]
    );
  }
}

/** Texto legible del tiempo que el pedido estuvo esperando. */
function formatEspera(minutos: number): string {
  if (minutos >= 24 * 60) {
    const dias = Math.floor(minutos / (24 * 60));
    return dias === 1 ? "1 día" : `${dias} días`;
  }
  if (minutos >= 60) {
    const horas = Math.floor(minutos / 60);
    return horas === 1 ? "1 hora" : `${horas} horas`;
  }
  return `${minutos} minutos`;
}

/**
 * Cancela un pedido y devuelve sus recursos en una transacción.
 *
 * El UPDATE lleva `estado = 'pendiente_pago'` en el WHERE: si el
 * webhook acreditó el pago entre la consulta y este momento,
 * `affectedRows` es 0 y no se devuelve nada. Es lo que impide que el
 * barrido pise una compra que acaba de completarse.
 */
async function cancelarPedido(pedido: PedidoVencido): Promise<boolean> {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    const [res] = await conn.execute<ResultSetHeader>(
      "UPDATE pedidos SET estado = 'cancelado' WHERE id = ? AND estado = 'pendiente_pago'",
      [pedido.id]
    );

    if (res.affectedRows === 0) {
      await conn.rollback();
      return false;
    }

    await devolverStock(conn, pedido.id);
    await liberarCupon(conn, pedido.id, pedido.cupon_id);

    await conn.execute(
      `INSERT INTO pedido_historial (pedido_id, estado_anterior, estado_nuevo, comentario, notificar)
       VALUES (?, 'pendiente_pago', 'cancelado', ?, 0)`,
      [
        pedido.id,
        `Cancelado automáticamente por falta de pago tras ${formatEspera(pedido.minutos)} ` +
        `de espera. Se devolvió el inventario apartado.`,
      ]
    );

    await conn.commit();
    return true;
  } catch (err) {
    await conn.rollback();
    console.error(`[limpiarPedidos] Fallo cancelando ${pedido.numero}:`, err);
    return false;
  } finally {
    conn.release();
  }
}

/**
 * Barre los pedidos vencidos. Cada pedido se procesa de forma
 * independiente: que uno falle no detiene a los demás.
 */
export async function limpiarPedidosVencidos(): Promise<ResultadoLimpieza> {
  const vencidos = await buscarVencidos();
  const resultado: ResultadoLimpieza = {
    revisados:  vencidos.length,
    cancelados: 0,
    omitidos:   0,
    numeros:    [],
  };

  for (const pedido of vencidos) {
    // Primero Stripe: mientras el cobro siga vivo, el pedido también.
    if (!(await anularCobro(pedido.referencia_pago))) {
      resultado.omitidos++;
      continue;
    }

    if (await cancelarPedido(pedido)) {
      resultado.cancelados++;
      resultado.numeros.push(pedido.numero);
    } else {
      resultado.omitidos++;
    }
  }

  if (resultado.cancelados > 0) {
    console.info(
      `[limpiarPedidos] ${resultado.cancelados} pedido(s) cancelado(s) por falta de pago: ` +
      resultado.numeros.join(", ")
    );
  }

  return resultado;
}
