// Almacenamiento de archivos. Este indice toca R2 y la base de datos:
// es de servidor. Para resolver la URL de una imagen desde el navegador
// se importa "@mpeduardo98/commerce-core/media/resolve-image-url", que
// no arrastra nada de eso.
export * from "./r2";
export * from "./paths";
export * from "./syncMediaUrl";
