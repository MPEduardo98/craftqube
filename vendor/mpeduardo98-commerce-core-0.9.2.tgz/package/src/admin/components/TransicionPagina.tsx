"use client";
// admin/components/TransicionPagina.tsx
// ─────────────────────────────────────────────────────────────
// Entrada suave de cada pantalla del panel. La usa rutas/admin/
// template.tsx, que Next vuelve a montar en cada navegación.
// ─────────────────────────────────────────────────────────────
import { motion, useReducedMotion } from "framer-motion";

export function TransicionPagina({ children }: { children: React.ReactNode }) {
  const reducir = useReducedMotion();
  return (
    <motion.div
      initial={reducir ? false : { opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
      className="min-h-full"
    >
      {children}
    </motion.div>
  );
}
