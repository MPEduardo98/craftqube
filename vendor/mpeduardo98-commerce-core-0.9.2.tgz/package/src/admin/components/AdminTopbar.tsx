"use client";
// admin/components/AdminTopbar.tsx
// ─────────────────────────────────────────────────────────────
// Barra superior del panel: búsqueda (con atajo "/" para enfocar),
// enlace a la tienda y botón de cuenta.
// ─────────────────────────────────────────────────────────────
import { useEffect, useRef, useState, type FormEvent } from "react";
import { useRouter, usePathname }   from "next/navigation";
import Link                         from "next/link";

interface AdminTopbarProps {
  /** Botón de cuenta de la esquina */
  userButton?: React.ReactNode;
  colorFondo?: string;
  colorTexto?: string;
}

const SCOPES = [
  { label: "Productos", path: "/admin/productos" },
  { label: "Pedidos",   path: "/admin/pedidos"   },
] as const;

type Scope = (typeof SCOPES)[number]["path"];

const detectScope = (p: string): Scope =>
  p.startsWith("/admin/pedidos") ? "/admin/pedidos" : "/admin/productos";

export function AdminTopbar({ userButton, colorFondo = "#ffffff", colorTexto = "#525252" }: AdminTopbarProps) {
  const router   = useRouter();
  const pathname = usePathname();
  const [q, setQ]         = useState("");
  const [scope, setScope] = useState<Scope>(detectScope(pathname));
  const input = useRef<HTMLInputElement>(null);

  useEffect(() => setScope(detectScope(pathname)), [pathname]);

  // "/" enfoca la búsqueda (salvo que ya se esté escribiendo en otro campo)
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement;
      if (e.key !== "/" || t.closest("input, textarea, select, [contenteditable=true]")) return;
      e.preventDefault();
      input.current?.focus();
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, []);

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    const t = q.trim();
    router.push(t ? `${scope}?q=${encodeURIComponent(t)}` : scope);
  };

  return (
    <header
      className="cc-topbar h-14 flex items-center gap-3 px-6 shrink-0"
      style={{
        background:     colorFondo,
        color:          colorTexto,
        backdropFilter: "saturate(180%) blur(12px)",
        borderBottom:   "1px solid color-mix(in srgb, currentColor 15%, transparent)",
      }}
    >
      {/* ── Búsqueda ── */}
      <form onSubmit={onSubmit}
        className="group flex items-center flex-1 max-w-md h-9 rounded-lg focus-within:bg-white"
        style={{ background: "#f5f5f5", border: "1px solid transparent" }}
      >
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
          strokeLinecap="round" strokeLinejoin="round" className="ml-3 shrink-0" style={{ color: "#a3a3a3" }}>
          <circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
        </svg>
        <input
          ref={input}
          type="text"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Buscar…"
          aria-label="Buscar en el panel"
          className="flex-1 min-w-0 h-full px-2.5 bg-transparent text-[13px] focus-visible:!shadow-none focus-visible:!border-transparent"
          style={{ color: "#0a0a0a", outline: "none" }}
        />
        <select
          value={scope}
          onChange={(e) => setScope(e.target.value as Scope)}
          aria-label="Buscar en"
          className="h-7 mr-1 px-2 rounded-md text-[12px] bg-transparent hover:bg-white focus-visible:!shadow-none"
          style={{ color: "#737373", appearance: "none", outline: "none", border: "none" }}
        >
          {SCOPES.map((s) => <option key={s.path} value={s.path}>en {s.label.toLowerCase()}</option>)}
        </select>
        <kbd className="hidden md:flex items-center justify-center h-5 min-w-5 px-1.5 mr-2 rounded text-[11px] font-mono group-focus-within:hidden"
          style={{ color: "#a3a3a3", background: "#fff", border: "1px solid #ebebeb" }}>
          /
        </kbd>
      </form>

      {/* ── Derecha ── */}
      <div className="flex items-center gap-2 ml-auto">
        <Link
          href="/"
          target="_blank"
          className="cc-topbar-link hidden sm:inline-flex items-center gap-1.5 h-8 px-3 rounded-lg text-[13px]"
          style={{ color: "inherit" }}
        >
          Ver tienda
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M7 17 17 7M8 7h9v9"/>
          </svg>
        </Link>
        <div className="shrink-0">{userButton}</div>
      </div>
    </header>
  );
}
