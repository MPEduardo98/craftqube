"use client";
// admin/components/AdminUserButton.tsx
// ─────────────────────────────────────────────────────────────
// Botón de cuenta del topbar del panel. Es del núcleo y no del
// header de cada tienda: el panel es el mismo para todas y no
// debe depender de componentes ni contextos del diseño público.
// Sólo usa sesión y alertas del núcleo.
// ─────────────────────────────────────────────────────────────
import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence }      from "framer-motion";
import Link                             from "next/link";
import { useRouter }                    from "next/navigation";
import { useAuth }                      from "../../auth/AuthContext";
import { useAlert }                     from "../../context/AlertContext";

export function AdminUserButton() {
  const [abierto,  setAbierto]  = useState(false);
  const [saliendo, setSaliendo] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const { usuario, logout } = useAuth();
  const router = useRouter();
  const alert  = useAlert();

  useEffect(() => {
    const fuera = (e: MouseEvent) => {
      if (!ref.current?.contains(e.target as Node)) setAbierto(false);
    };
    const esc = (e: KeyboardEvent) => e.key === "Escape" && setAbierto(false);
    document.addEventListener("mousedown", fuera);
    document.addEventListener("keydown", esc);
    return () => {
      document.removeEventListener("mousedown", fuera);
      document.removeEventListener("keydown", esc);
    };
  }, []);

  const salir = async () => {
    if (saliendo) return;
    setSaliendo(true);
    const r = await logout();
    setSaliendo(false);
    setAbierto(false);
    if (r.ok) alert.success("Cerraste sesión correctamente", "¡Hasta pronto!");
    else      alert.error(r.error ?? "No pudimos cerrar tu sesión", "Sesión cerrada localmente");
    router.push("/");
    router.refresh();
  };

  const inicial = (usuario?.nombre ?? usuario?.email ?? "?").trim().charAt(0).toUpperCase();

  return (
    <div ref={ref} className="relative">
      <motion.button
        whileTap={{ scale: 0.94 }}
        onClick={() => setAbierto((v) => !v)}
        className="flex items-center justify-center w-8 h-8 rounded-full text-[12px] font-semibold"
        style={{
          background: "#0a0a0a",
          color:      "#fff",
          boxShadow:  abierto ? "0 0 0 3px #fff, 0 0 0 4px #d4d4d4" : "none",
        }}
        aria-label="Cuenta"
        aria-expanded={abierto}
      >
        {inicial}
      </motion.button>

      <AnimatePresence>
        {abierto && (
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: -6 }}
            animate={{ opacity: 1, scale: 1,    y: 0  }}
            exit={{    opacity: 0, scale: 0.97, y: -4 }}
            transition={{ duration: 0.16, ease: [0.22, 1, 0.36, 1] }}
            className="absolute right-0 mt-2 w-60 rounded-xl overflow-hidden origin-top-right"
            style={{
              background: "#fff",
              border:     "1px solid #ebebeb",
              boxShadow:  "0 12px 32px -8px rgba(0,0,0,0.16), 0 2px 6px rgba(0,0,0,0.04)",
              zIndex:     50,
            }}
          >
            <div className="px-3.5 py-3">
              <p className="text-[13px] font-medium truncate" style={{ color: "#0a0a0a" }}>
                {usuario?.nombre} {usuario?.apellido}
              </p>
              <p className="text-[12px] truncate" style={{ color: "#737373" }}>{usuario?.email}</p>
            </div>

            <div className="p-1" style={{ borderTop: "1px solid #f5f5f5" }}>
              <Opcion href="/" onClick={() => setAbierto(false)}>Ver tienda</Opcion>
              <Opcion href="/cuenta" onClick={() => setAbierto(false)}>Mi cuenta</Opcion>
            </div>

            <div className="p-1" style={{ borderTop: "1px solid #f5f5f5" }}>
              <button
                onClick={salir}
                disabled={saliendo}
                className="w-full flex items-center h-8 px-2.5 rounded-md text-[13px] text-left hover:bg-[#f5f5f5]"
                style={{ color: "#0a0a0a", opacity: saliendo ? 0.5 : 1 }}
              >
                {saliendo ? "Cerrando sesión…" : "Cerrar sesión"}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function Opcion({ href, onClick, children }: { href: string; onClick: () => void; children: React.ReactNode }) {
  return (
    <Link href={href} onClick={onClick}
      className="flex items-center h-8 px-2.5 rounded-md text-[13px] hover:bg-[#f5f5f5]"
      style={{ color: "#262626" }}>
      {children}
    </Link>
  );
}
