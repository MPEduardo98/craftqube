"use client";
// admin/components/AdminStatCards.tsx
// ─────────────────────────────────────────────────────────────
// Tarjetas de métricas del inicio. Entran escalonadas y el número
// cuenta hacia arriba hasta su valor.
// ─────────────────────────────────────────────────────────────
import Link from "next/link";
import { useEffect, useState } from "react";
import { motion, animate, useReducedMotion } from "framer-motion";

export interface StatCard {
  key:    string;
  label:  string;
  href:   string;
  /** Path SVG del ícono (trazo) */
  d:      string;
  value:  number;
  /** Texto chico bajo el número */
  nota?:  string;
  /** Mostrar como dinero ($1,234.50) */
  moneda?: boolean;
  /** Decimales a mostrar (p. ej. 1 para un promedio de estrellas). Default 0. */
  decimales?: number;
}

function Contador({ valor, moneda, decimales = 0 }: { valor: number; moneda?: boolean; decimales?: number }) {
  const reducir = useReducedMotion();
  const [n, setN] = useState(reducir ? valor : 0);

  useEffect(() => {
    if (reducir) { setN(valor); return; }
    const c = animate(0, valor, {
      duration: Math.min(1.2, 0.5 + valor / 2000),
      ease: [0.22, 1, 0.36, 1],
      onUpdate: (v) => setN(moneda ? v : Math.round(v * 10 ** decimales) / 10 ** decimales),
    });
    return () => c.stop();
  }, [valor, reducir, moneda, decimales]);

  return moneda
    ? <>${n.toLocaleString("es-MX", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</>
    : <>{n.toLocaleString("es-MX", { minimumFractionDigits: decimales, maximumFractionDigits: decimales })}</>;
}

export function AdminStatCards({ cards }: { cards: StatCard[] }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3">
      {cards.map((c, i) => (
        <motion.div
          key={c.key}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, delay: 0.05 + i * 0.06, ease: [0.22, 1, 0.36, 1] }}
        >
          <Link
            href={c.href}
            className="group block p-5 rounded-xl hover:border-[#d4d4d4]"
            style={{
              background: "#fff",
              border:     "1px solid #ebebeb",
              boxShadow:  "0 1px 2px rgba(0,0,0,0.03)",
              textDecoration: "none",
            }}
          >
            <div className="flex items-center justify-between">
              <p className="text-[13px]" style={{ color: "#737373" }}>{c.label}</p>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"
                className="transition-colors duration-200 text-[#d4d4d4] group-hover:text-[#0a0a0a]">
                <path d={c.d} />
              </svg>
            </div>
            <p className="mt-3 text-[30px] font-semibold leading-none tracking-tight tabular-nums"
              style={{ color: "#0a0a0a" }}>
              <Contador valor={c.value} moneda={c.moneda} decimales={c.decimales} />
            </p>
            <div className="mt-3 flex items-center justify-between text-[12px]" style={{ color: "#a3a3a3" }}>
              <span>{c.nota ?? " "}</span>
              <span className="flex items-center gap-1 opacity-0 -translate-x-1 transition-all duration-200 group-hover:opacity-100 group-hover:translate-x-0"
                style={{ color: "#0a0a0a" }}>
                Ver
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M5 12h14M13 6l6 6-6 6"/>
                </svg>
              </span>
            </div>
          </Link>
        </motion.div>
      ))}
    </div>
  );
}
