// admin/components/AdminPageHeader.tsx
// ─────────────────────────────────────────────────────────────
// Encabezado de cada pantalla del panel: título, descripción y
// acciones a la derecha. Un solo componente para que todas las
// pantallas se vean igual.
// ─────────────────────────────────────────────────────────────
interface AdminPageHeaderProps {
  titulo:       string;
  descripcion?: React.ReactNode;
  /** Botones a la derecha */
  acciones?:    React.ReactNode;
}

export function AdminPageHeader({ titulo, descripcion, acciones }: AdminPageHeaderProps) {
  return (
    <header className="flex flex-wrap items-end justify-between gap-4 px-8 pt-8 pb-6">
      <div className="min-w-0">
        <h1 className="text-[24px] font-semibold tracking-tight leading-tight" style={{ color: "#0a0a0a" }}>
          {titulo}
        </h1>
        {descripcion && (
          <p className="mt-1 text-[14px]" style={{ color: "#737373" }}>{descripcion}</p>
        )}
      </div>
      {acciones && <div className="flex items-center gap-2 shrink-0">{acciones}</div>}
    </header>
  );
}
