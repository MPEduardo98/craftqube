"use client";
// admin/resenas/components/ModalResena.tsx
// ─────────────────────────────────────────────────────────────
// Detalle de una reseña: texto completo, fotos, de qué pedido
// viene, y las acciones de la tienda (aprobar, rechazar, responder
// en público, borrar). El texto del cliente no se edita.
// ─────────────────────────────────────────────────────────────
import { useEffect, useState } from "react";
import { Modal }     from "../../../ui/Modal";
import { useAlert }  from "../../../context/AlertContext";
import { Estrellas } from "./Estrellas";
import type { ResenaAdmin, ResenaEstado } from "../../../resenas/types";

export const ESTADO_META: Record<ResenaEstado, { label: string; bg: string; color: string }> = {
  pendiente: { label: "Pendiente", bg: "#fef3c7", color: "#92400e" },
  aprobada:  { label: "Publicada", bg: "#f0fdf4", color: "#166534" },
  rechazada: { label: "Rechazada", bg: "#f5f5f5", color: "#737373" },
};

interface Props {
  resena:    ResenaAdmin | null;
  onClose:   () => void;
  onUpdated: (id: number, patch: Partial<ResenaAdmin>) => void;
  onDeleted: (id: number) => void;
}

const btn = "px-3 py-2 rounded-lg text-[12.5px] font-semibold transition-opacity disabled:opacity-40 disabled:cursor-not-allowed";

export function ModalResena({ resena, onClose, onUpdated, onDeleted }: Props) {
  const alert = useAlert();
  const [respuesta, setRespuesta] = useState("");
  const [busy,      setBusy]      = useState(false);
  const [confirmar, setConfirmar] = useState(false);

  useEffect(() => {
    setRespuesta(resena?.respuesta_tienda ?? "");
    setConfirmar(false);
  }, [resena]);

  if (!resena) return <Modal open={false} onClose={onClose}>{null}</Modal>;
  const r = resena;

  const patch = async (body: { estado?: ResenaEstado; respuesta_tienda?: string }, ok: string) => {
    setBusy(true);
    try {
      const res  = await fetch(`/api/admin/resenas/${r.id}`, {
        method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
      });
      const json = await res.json().catch(() => ({}));
      if (!json.success) { alert.error(json.error ?? "No se pudo guardar"); return; }
      onUpdated(r.id, {
        ...(body.estado ? { estado: body.estado } : {}),
        ...(body.respuesta_tienda !== undefined ? { respuesta_tienda: body.respuesta_tienda.trim() || null } : {}),
      });
      alert.success(ok);
    } catch {
      alert.error("Error de red");
    } finally { setBusy(false); }
  };

  const borrar = async () => {
    setBusy(true);
    try {
      const res  = await fetch(`/api/admin/resenas/${r.id}`, { method: "DELETE" });
      const json = await res.json().catch(() => ({}));
      if (!json.success) { alert.error(json.error ?? "No se pudo borrar"); return; }
      alert.success("Reseña eliminada");
      onDeleted(r.id);
    } catch {
      alert.error("Error de red");
    } finally { setBusy(false); }
  };

  const meta = ESTADO_META[r.estado];
  const respuestaCambio = respuesta.trim() !== (r.respuesta_tienda ?? "");

  return (
    <Modal open onClose={onClose} title={r.producto_titulo} maxWidth="36rem">
      {/* Cabecera: estrellas, estado, autor */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-2">
          <Estrellas valor={r.calificacion} size={16} />
          <span className="px-2 py-0.5 rounded-md text-[11px] font-semibold" style={{ background: meta.bg, color: meta.color }}>
            {meta.label}
          </span>
        </div>
        <span className="text-[12px]" style={{ color: "#737373" }}>
          {new Date(r.created_at).toLocaleDateString("es-MX", { day: "numeric", month: "long", year: "numeric" })}
        </span>
      </div>

      <div className="text-[12.5px]" style={{ color: "#525252" }}>
        <span className="font-semibold" style={{ color: "#0a0a0a" }}>{r.nombre}</span>
        {r.email && <> · {r.email}</>}
        {r.pedido_numero && <> · Pedido <span className="font-mono">{r.pedido_numero}</span></>}
        {r.compra_verificada && <span className="ml-1.5 text-[11px] font-semibold" style={{ color: "#166534" }}>✓ Compra verificada</span>}
      </div>

      {/* Contenido */}
      <div className="flex flex-col gap-1.5">
        {r.titulo && <p className="text-[14px] font-semibold" style={{ color: "#0a0a0a" }}>{r.titulo}</p>}
        <p className="text-[13.5px] leading-relaxed whitespace-pre-wrap" style={{ color: "#262626" }}>{r.comentario}</p>
      </div>

      {r.imagenes.length > 0 && (
        <div className="flex gap-2">
          {r.imagenes.map((url) => (
            <a key={url} href={url} target="_blank" rel="noreferrer"
              className="block w-24 h-24 rounded-lg overflow-hidden" style={{ border: "1px solid #ebebeb" }}>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={url} alt="Foto del cliente" className="w-full h-full object-cover" />
            </a>
          ))}
        </div>
      )}

      {/* Respuesta pública */}
      <div className="flex flex-col gap-1.5">
        <label className="text-[12px] font-medium" style={{ color: "#525252" }}>Respuesta de la tienda (pública)</label>
        <textarea
          value={respuesta} onChange={(e) => setRespuesta(e.target.value)}
          rows={3} maxLength={2000} placeholder="Gracias por tu compra…"
          className="w-full rounded-lg px-3 py-2 text-[13px] resize-y outline-none"
          style={{ border: "1px solid #e5e5e5", background: "#fff", color: "#0a0a0a" }}
        />
        <div className="flex justify-end">
          <button type="button" disabled={busy || !respuestaCambio}
            onClick={() => patch({ respuesta_tienda: respuesta }, respuesta.trim() ? "Respuesta guardada" : "Respuesta quitada")}
            className={btn} style={{ border: "1px solid #e5e5e5", background: "#fff", color: "#0a0a0a" }}>
            Guardar respuesta
          </button>
        </div>
      </div>

      {/* Acciones */}
      <div className="flex items-center gap-2 pt-4 flex-wrap" style={{ borderTop: "1px solid #f0f0f0" }}>
        {confirmar ? (
          <>
            <span className="text-[12.5px]" style={{ color: "#b91c1c" }}>¿Borrar la reseña y sus fotos?</span>
            <button type="button" disabled={busy} onClick={borrar} className={btn} style={{ background: "#b91c1c", color: "#fff" }}>Sí, borrar</button>
            <button type="button" disabled={busy} onClick={() => setConfirmar(false)} className={btn} style={{ color: "#525252" }}>Cancelar</button>
          </>
        ) : (
          <button type="button" disabled={busy} onClick={() => setConfirmar(true)} className={btn} style={{ color: "#b91c1c" }}>
            Eliminar
          </button>
        )}
        <div className="ml-auto flex gap-2">
          {r.estado !== "rechazada" && (
            <button type="button" disabled={busy} onClick={() => patch({ estado: "rechazada" }, "Reseña ocultada")}
              className={btn} style={{ border: "1px solid #e5e5e5", background: "#fff", color: "#0a0a0a" }}>
              {r.estado === "aprobada" ? "Ocultar" : "Rechazar"}
            </button>
          )}
          {r.estado !== "aprobada" && (
            <button type="button" disabled={busy} onClick={() => patch({ estado: "aprobada" }, "Reseña publicada")}
              className={btn} style={{ background: "#0a0a0a", color: "#fff" }}>
              Publicar
            </button>
          )}
        </div>
      </div>
    </Modal>
  );
}
