"use client";
// admin/resenas/components/ResenasTable.tsx
// ─────────────────────────────────────────────────────────────
// Moderación de reseñas. Mismo patrón que PedidosTable: búsqueda,
// filtros por estado y estrellas, paginación y detalle en modal.
// Con selección se publican u ocultan varias a la vez.
// ─────────────────────────────────────────────────────────────
import { useCallback, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { useAlert }  from "../../../context/AlertContext";
import { Dropdown }  from "../../../ui/Dropdown";
import { Estrellas } from "./Estrellas";
import { ModalResena, ESTADO_META } from "./ModalResena";
import type { ResenaAdmin, ResenaEstado } from "../../../resenas/types";

const LIMIT = 20;

const ESTADO_TABS: { value: ResenaEstado | ""; label: string }[] = [
  { value: "",          label: "Todas"      },
  { value: "pendiente", label: "Pendientes" },
  { value: "aprobada",  label: "Publicadas" },
  { value: "rechazada", label: "Rechazadas" },
];

const ESTRELLAS_OPTIONS = [
  { value: "",  label: "Todas las estrellas" },
  { value: "5", label: "5 estrellas" },
  { value: "4", label: "4 estrellas" },
  { value: "3", label: "3 estrellas" },
  { value: "2", label: "2 estrellas" },
  { value: "1", label: "1 estrella"  },
];

const muted = "var(--color-cq-muted, #737373)";
const muted2 = "var(--color-cq-muted-2, #a3a3a3)";

function fechaCorta(v: string) {
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? "—" : d.toLocaleDateString("es-MX", { day: "2-digit", month: "short", year: "2-digit" });
}

interface Props {
  initialResenas: ResenaAdmin[];
  initialTotal:   number;
  /** Abrir directo en "Pendientes" (cuando la tienda modera). */
  initialEstado?: ResenaEstado | "";
}

export function ResenasTable({ initialResenas, initialTotal, initialEstado = "" }: Props) {
  const router = useRouter();
  const alert  = useAlert();

  const [resenas,   setResenas]   = useState(initialResenas);
  const [total,     setTotal]     = useState(initialTotal);
  const [q,         setQ]         = useState("");
  const [estado,    setEstado]    = useState<ResenaEstado | "">(initialEstado);
  const [estrellas, setEstrellas] = useState("");
  const [page,      setPage]      = useState(1);
  const [pages,     setPages]     = useState(Math.max(1, Math.ceil(initialTotal / LIMIT)));
  const [loading,   setLoading]   = useState(false);
  const [selected,  setSelected]  = useState<Set<number>>(new Set());
  const [bulkBusy,  setBulkBusy]  = useState(false);
  const [detalleId, setDetalleId] = useState<number | null>(null);

  const searchTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);

  const fetchData = useCallback(async (p: { q?: string; estado?: string; estrellas?: string; page?: number }) => {
    setLoading(true);
    const sp = new URLSearchParams({
      q:         p.q         ?? q,
      estado:    p.estado    ?? estado,
      estrellas: p.estrellas ?? estrellas,
      page:      String(p.page ?? page),
      limit:     String(LIMIT),
    });
    try {
      const res  = await fetch(`/api/admin/resenas?${sp}`);
      const json = await res.json();
      if (json.success) {
        setResenas(json.data);
        setTotal(json.meta.total);
        setPages(json.meta.pages);
        setSelected(new Set());
      }
    } finally { setLoading(false); }
  }, [q, estado, estrellas, page]);

  const patchLocal = useCallback((id: number, patch: Partial<ResenaAdmin>) =>
    setResenas((prev) => prev.map((r) => (r.id === id ? { ...r, ...patch } : r))), []);

  const toggle = (id: number) => setSelected((prev) => {
    const s = new Set(prev);
    if (s.has(id)) s.delete(id); else s.add(id);
    return s;
  });

  const cambiarEstadoMasivo = async (nuevo: ResenaEstado) => {
    setBulkBusy(true);
    try {
      const ids = Array.from(selected);
      const oks = await Promise.all(ids.map(async (id) => {
        const res = await fetch(`/api/admin/resenas/${id}`, {
          method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ estado: nuevo }),
        });
        const json = await res.json().catch(() => ({}));
        if (json.success) patchLocal(id, { estado: nuevo });
        return Boolean(json.success);
      }));
      const fallos = oks.filter((x) => !x).length;
      if (fallos) alert.error(`${fallos} reseña${fallos !== 1 ? "s" : ""} no se pudieron actualizar`);
      else alert.success(`${ids.length} reseña${ids.length !== 1 ? "s" : ""} → ${ESTADO_META[nuevo].label}`);
      setSelected(new Set());
      router.refresh();
    } finally { setBulkBusy(false); }
  };

  const handleSearch = (v: string) => {
    setQ(v); setPage(1);
    if (searchTimeout.current) clearTimeout(searchTimeout.current);
    searchTimeout.current = setTimeout(() => { void fetchData({ q: v, page: 1 }); }, 350);
  };

  const irA = (p: number) => { setPage(p); void fetchData({ page: p }); };

  const detalle = resenas.find((r) => r.id === detalleId) ?? null;
  const hayFiltros = Boolean(q || estado || estrellas);

  return (
    <>
      <style>{`
        .rtbl-row { border-bottom: 1px solid var(--color-cq-border, #ebebeb); transition: background .1s; cursor: pointer; }
        .rtbl-row:hover { background: var(--color-cq-surface-2, #fafafa); }
        .rtbl-row.sel { background: var(--color-cq-accent-glow, rgba(10,10,10,0.05)); }
        .rtbl-input {
          width: 100%; padding: 8px 12px 8px 32px;
          background: var(--color-cq-surface-2, #f5f5f5);
          border: 1px solid var(--color-cq-border, #ebebeb);
          border-radius: 8px; outline: none; font-size: 13px; color: var(--color-cq-text, #0a0a0a);
        }
        .rtbl-input:focus { border-color: #0a0a0a; background: #fff; }
        .rtbl-pgbtn {
          width:30px; height:30px; border-radius:7px; border:1px solid var(--color-cq-border, #ebebeb);
          display:flex; align-items:center; justify-content:center; font-size:12px; cursor:pointer;
          color: ${muted}; background: #fff;
        }
        .rtbl-pgbtn.act { background:#0a0a0a; color:#fff; border-color:#0a0a0a; }
        .rtbl-pgbtn:disabled { opacity:.35; cursor:not-allowed; }
      `}</style>

      {/* ── Barra de herramientas ── */}
      <div className="flex flex-col gap-3 px-5 py-4" style={{ borderBottom: "1px solid var(--color-cq-border, #ebebeb)" }}>
        <div className="flex items-center gap-3 flex-wrap">
          <div className="relative flex-1 min-w-[200px]">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"
              strokeLinecap="round" strokeLinejoin="round"
              className="absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" style={{ color: muted2 }}>
              <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
            </svg>
            <input type="text" value={q} className="rtbl-input"
              placeholder="Buscar por cliente, email, producto o texto…"
              onChange={(e) => handleSearch(e.target.value)} />
          </div>
          <Dropdown
            value={estrellas}
            onChange={(v) => { setEstrellas(v); setPage(1); void fetchData({ estrellas: v, page: 1 }); }}
            options={ESTRELLAS_OPTIONS}
            width={190}
            placeholder="Todas las estrellas"
          />
          <span className="text-[11px] tabular-nums shrink-0" style={{ color: muted2 }}>
            {total} resultado{total !== 1 ? "s" : ""}
          </span>
        </div>

        <div className="flex items-center gap-1.5 flex-wrap">
          {ESTADO_TABS.map((t) => {
            const active = estado === t.value;
            return (
              <button key={t.value} type="button"
                onClick={() => { setEstado(t.value); setPage(1); void fetchData({ estado: t.value, page: 1 }); }}
                className="px-3 py-1.5 rounded-lg text-[11px] font-semibold"
                style={{
                  border:     active ? "1px solid #0a0a0a" : "1px solid var(--color-cq-border, #ebebeb)",
                  background: active ? "rgba(10,10,10,0.06)" : "transparent",
                  color:      active ? "#0a0a0a" : muted,
                }}>
                {t.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* ── Acciones sobre la selección ── */}
      {selected.size > 0 && (
        <div className="flex items-center gap-2 flex-wrap px-5 py-3"
          style={{ background: "rgba(10,10,10,0.04)", borderBottom: "1px solid var(--color-cq-border, #ebebeb)" }}>
          <span className="text-[12px] font-semibold mr-2">
            {selected.size} seleccionada{selected.size !== 1 ? "s" : ""}
          </span>
          <button type="button" disabled={bulkBusy} onClick={() => cambiarEstadoMasivo("aprobada")}
            className="px-3 py-1.5 rounded-lg text-[12px] font-semibold disabled:opacity-50"
            style={{ background: "#0a0a0a", color: "#fff" }}>Publicar</button>
          <button type="button" disabled={bulkBusy} onClick={() => cambiarEstadoMasivo("rechazada")}
            className="px-3 py-1.5 rounded-lg text-[12px] font-semibold disabled:opacity-50"
            style={{ border: "1px solid #e5e5e5", background: "#fff" }}>Ocultar</button>
          <button type="button" disabled={bulkBusy} onClick={() => setSelected(new Set())}
            className="ml-auto text-[12px] font-semibold" style={{ color: muted }}>Limpiar selección</button>
        </div>
      )}

      {/* ── Tabla ── */}
      <div className={`transition-opacity duration-150 ${loading ? "opacity-40 pointer-events-none" : ""}`}>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ borderBottom: "1px solid var(--color-cq-border, #ebebeb)", background: "var(--color-cq-surface-2, #fafafa)" }}>
                <th className="pl-5 pr-3 py-3 w-10">
                  <input type="checkbox" className="w-3.5 h-3.5 rounded cursor-pointer"
                    checked={selected.size === resenas.length && resenas.length > 0}
                    onChange={() => setSelected((prev) =>
                      prev.size === resenas.length ? new Set() : new Set(resenas.map((r) => r.id)))} />
                </th>
                {["Calificación", "Reseña", "Producto", "Cliente", "Estado", "Fecha"].map((h) => (
                  <th key={h} className="px-4 py-3 text-[10px] font-bold text-left" style={{ color: muted }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {resenas.length === 0 ? (
                <tr><td colSpan={7} className="px-5 py-16 text-center">
                  <p className="text-[13px] font-medium" style={{ color: muted }}>
                    {hayFiltros ? "No hay reseñas con esos filtros" : "Todavía no hay reseñas"}
                  </p>
                </td></tr>
              ) : resenas.map((r) => {
                const meta = ESTADO_META[r.estado];
                return (
                  <tr key={r.id} className={`rtbl-row${selected.has(r.id) ? " sel" : ""}`} onClick={() => setDetalleId(r.id)}>
                    <td className="pl-5 pr-3 py-3.5" onClick={(e) => e.stopPropagation()}>
                      <input type="checkbox" className="w-3.5 h-3.5 rounded cursor-pointer"
                        checked={selected.has(r.id)} onChange={() => toggle(r.id)} />
                    </td>
                    <td className="px-4 py-3.5"><Estrellas valor={r.calificacion} /></td>
                    <td className="px-4 py-3.5">
                      <div className="flex items-center gap-2.5 max-w-[340px]">
                        <div className="min-w-0">
                          {r.titulo && <p className="text-[12.5px] font-semibold truncate" style={{ color: "#0a0a0a" }}>{r.titulo}</p>}
                          <p className="text-[12px] truncate" style={{ color: muted }}>{r.comentario}</p>
                        </div>
                        {r.imagenes.length > 0 && (
                          <span className="shrink-0 text-[10.5px] px-1.5 py-0.5 rounded" style={{ background: "#f5f5f5", color: muted }}
                            title={`${r.imagenes.length} foto${r.imagenes.length !== 1 ? "s" : ""}`}>
                            📷 {r.imagenes.length}
                          </span>
                        )}
                        {r.respuesta_tienda && (
                          <span className="shrink-0 text-[10.5px] px-1.5 py-0.5 rounded" style={{ background: "#f5f5f5", color: muted }}
                            title="La tienda respondió">↩</span>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className="text-[12px] truncate block max-w-[180px]" style={{ color: "#0a0a0a" }}>{r.producto_titulo}</span>
                    </td>
                    <td className="px-4 py-3.5">
                      <div className="flex flex-col gap-0.5 max-w-[170px]">
                        <span className="text-[12px] font-semibold truncate" style={{ color: "#0a0a0a" }}>{r.nombre}</span>
                        <span className="text-[10.5px] truncate" style={{ color: muted2 }}>{r.email ?? "—"}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className="px-2 py-1 rounded-md text-[10.5px] font-bold whitespace-nowrap"
                        style={{ background: meta.bg, color: meta.color }}>{meta.label}</span>
                    </td>
                    <td className="px-4 py-3.5 pr-5">
                      <span className="text-[12px] whitespace-nowrap" style={{ color: "#0a0a0a" }}>{fechaCorta(r.created_at)}</span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* ── Paginación ── */}
      {pages > 1 && (
        <div className="flex items-center justify-between px-5 py-3" style={{ borderTop: "1px solid var(--color-cq-border, #ebebeb)" }}>
          <p className="text-[11px]" style={{ color: muted2 }}>Página {page} de {pages}</p>
          <div className="flex items-center gap-1">
            <button className="rtbl-pgbtn" disabled={page === 1 || loading} onClick={() => irA(page - 1)}>←</button>
            {Array.from({ length: Math.min(5, pages) }, (_, i) => {
              const pg = Math.max(1, Math.min(page - 2, pages - 4)) + i;
              return (
                <button key={pg} className={`rtbl-pgbtn${pg === page ? " act" : ""}`} disabled={loading} onClick={() => irA(pg)}>
                  {pg}
                </button>
              );
            })}
            <button className="rtbl-pgbtn" disabled={page === pages || loading} onClick={() => irA(page + 1)}>→</button>
          </div>
        </div>
      )}

      <ModalResena
        resena={detalle}
        onClose={() => { setDetalleId(null); router.refresh(); }}
        onUpdated={patchLocal}
        onDeleted={(id) => {
          setResenas((prev) => prev.filter((r) => r.id !== id));
          setTotal((t) => Math.max(0, t - 1));
          setDetalleId(null);
          router.refresh();
        }}
      />
    </>
  );
}
