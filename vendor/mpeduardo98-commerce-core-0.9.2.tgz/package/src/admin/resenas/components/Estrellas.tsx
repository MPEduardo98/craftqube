// admin/resenas/components/Estrellas.tsx
// Cinco estrellas en línea, llenas hasta `valor`.
export function Estrellas({ valor, size = 13 }: { valor: number; size?: number }) {
  return (
    <span className="inline-flex items-center gap-px" aria-label={`${valor} de 5 estrellas`}>
      {[1, 2, 3, 4, 5].map((i) => (
        <svg key={i} width={size} height={size} viewBox="0 0 24 24"
          fill={i <= valor ? "#0a0a0a" : "none"} stroke={i <= valor ? "#0a0a0a" : "#d4d4d4"}
          strokeWidth="1.6" strokeLinejoin="round">
          <path d="M12 2.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.3l-5.9 3.2 1.2-6.5L2.5 9.4l6.6-.9z" />
        </svg>
      ))}
    </span>
  );
}
