// admin/resenas/lib/resenasAdmin.ts
// ─────────────────────────────────────────────────────────────
// Lecturas del panel de reseñas. Las usan la página (carga
// inicial) y GET /api/admin/resenas, así ambas ven lo mismo.
// ─────────────────────────────────────────────────────────────
import { pool }               from "../../../db";
import type { RowDataPacket } from "mysql2";
import { filaAPublica }       from "../../../resenas/consultas";
import type { ResenaAdmin, ResenaEstado } from "../../../resenas/types";

export interface FiltrosResenasAdmin {
  q?:         string;
  estado?:    ResenaEstado | "";
  estrellas?: number | null;
  page?:      number;
  limit?:     number;
}

export interface StatsResenas {
  total:      number;
  pendientes: number;
  /** Promedio de las aprobadas, 1 decimal. */
  promedio:   number;
  con_fotos:  number;
}

const ESTADOS = new Set(["pendiente", "aprobada", "rechazada"]);

export async function listarResenasAdmin({
  q = "", estado = "", estrellas = null, page = 1, limit = 20,
}: FiltrosResenasAdmin = {}): Promise<{ resenas: ResenaAdmin[]; total: number; pages: number }> {
  const safeLimit = Math.min(100, Math.max(1, Math.floor(limit)));
  const safePage  = Math.max(1, Math.floor(page));

  const wheres: string[] = [];
  const params: (string | number)[] = [];
  if (q.trim()) {
    const like = `%${q.trim()}%`;
    wheres.push("(r.nombre LIKE ? OR r.email LIKE ? OR pr.titulo LIKE ? OR r.titulo LIKE ? OR r.cuerpo LIKE ?)");
    params.push(like, like, like, like, like);
  }
  if (estado && ESTADOS.has(estado)) {
    wheres.push("r.estado = ?");
    params.push(estado);
  }
  if (estrellas && estrellas >= 1 && estrellas <= 5) {
    wheres.push("r.calificacion = ?");
    params.push(Math.floor(estrellas));
  }
  const where = wheres.length ? `WHERE ${wheres.join(" AND ")}` : "";
  const from = `
    FROM \`reseñas\` r
    JOIN productos pr        ON pr.id = r.producto_id
    LEFT JOIN pedido_items pi ON pi.id = r.pedido_item_id
    LEFT JOIN pedidos pe      ON pe.id = pi.pedido_id`;

  const [[{ total }]] = await pool.query<RowDataPacket[]>(
    `SELECT COUNT(*) AS total ${from} ${where}`, params
  ) as [RowDataPacket[], unknown];

  const [rows] = await pool.query<RowDataPacket[]>(
    `SELECT
       r.id, r.nombre, r.email, r.usuario_id, r.producto_id, r.estado,
       r.calificacion, r.titulo, r.cuerpo AS comentario, r.imagenes,
       r.pedido_item_id, r.respuesta_tienda, r.created_at,
       pr.titulo AS producto_titulo, pr.slug AS producto_slug,
       pe.numero AS pedido_numero
     ${from} ${where}
     ORDER BY r.created_at DESC, r.id DESC
     LIMIT ? OFFSET ?`,
    [...params, safeLimit, (safePage - 1) * safeLimit]
  );

  const resenas = rows.map((r): ResenaAdmin => ({
    ...filaAPublica(r),
    estado:          r.estado,
    email:           r.email ?? null,
    usuario_id:      r.usuario_id == null ? null : Number(r.usuario_id),
    producto_id:     Number(r.producto_id),
    producto_titulo: r.producto_titulo,
    producto_slug:   r.producto_slug,
    pedido_numero:   r.pedido_numero ?? null,
  }));

  const n = Number(total);
  return { resenas, total: n, pages: Math.max(1, Math.ceil(n / safeLimit)) };
}

export async function statsResenas(): Promise<StatsResenas> {
  const [[s]] = await pool.query<RowDataPacket[]>(`
    SELECT
      COUNT(*)                                                     AS total,
      COALESCE(SUM(estado = 'pendiente'), 0)                       AS pendientes,
      ROUND(AVG(CASE WHEN estado = 'aprobada' THEN calificacion END), 1) AS promedio,
      COALESCE(SUM(imagenes IS NOT NULL AND JSON_LENGTH(imagenes) > 0), 0) AS con_fotos
    FROM \`reseñas\`
  `) as [RowDataPacket[], unknown];
  return {
    total:      Number(s.total),
    pendientes: Number(s.pendientes),
    promedio:   Number(s.promedio ?? 0),
    con_fotos:  Number(s.con_fotos),
  };
}
