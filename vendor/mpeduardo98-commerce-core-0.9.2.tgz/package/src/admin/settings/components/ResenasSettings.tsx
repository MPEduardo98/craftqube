"use client";
// admin/settings/components/ResenasSettings.tsx
// ─────────────────────────────────────────────────────────────
// Ajustes → Reseñas: encender/apagar el sistema y elegir si las
// reseñas se publican solas o esperan aprobación. Las reglas de
// quién puede reseñar no se configuran: sólo quien compró.
// ─────────────────────────────────────────────────────────────
import { useState }  from "react";
import { useRouter } from "next/navigation";
import { useAlert }  from "../../../context/AlertContext";
import type { ResenasConfig, ResenaModeracion } from "../../../resenas/types";

const cardCls = "rounded-xl border border-slate-200 bg-white p-5";

const MODOS: { value: ResenaModeracion; titulo: string; desc: string }[] = [
  { value: "auto",   titulo: "Publicar al instante",  desc: "Aparecen en la tienda en cuanto el cliente las envía. Puedes ocultarlas después." },
  { value: "manual", titulo: "Revisar antes",         desc: "Quedan pendientes hasta que las apruebes en Reseñas." },
];

export function ResenasSettings({ inicial }: { inicial: ResenasConfig }) {
  const router = useRouter();
  const alert  = useAlert();

  const [activas,    setActivas]    = useState(inicial.activas);
  const [moderacion, setModeracion] = useState<ResenaModeracion>(inicial.moderacion);
  const [saving,     setSaving]     = useState(false);

  const dirty = activas !== inicial.activas || moderacion !== inicial.moderacion;

  const handleSave = async () => {
    setSaving(true);
    try {
      const res  = await fetch("/api/admin/resenas/ajustes", {
        method:  "PUT",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ activas, moderacion }),
      });
      const json = await res.json();
      if (json.success) {
        alert.success("Ajustes de reseñas guardados");
        router.refresh();
      } else {
        alert.error(json.error ?? "No se pudo guardar");
      }
    } catch {
      alert.error("Error de red al guardar");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="flex flex-col gap-5">
      <section className={cardCls}>
        <div className="flex items-start justify-between gap-4">
          <div>
            <h2 className="text-base font-semibold text-slate-800 mb-1">Reseñas de productos</h2>
            <p className="text-sm text-slate-400">
              Los clientes califican de 1 a 5 estrellas, dejan un comentario y hasta 3 fotos.
            </p>
          </div>
          <button
            type="button"
            role="switch"
            aria-checked={activas}
            aria-label="Activar reseñas"
            onClick={() => setActivas(!activas)}
            className="relative shrink-0 w-11 h-6 rounded-full transition-colors"
            style={{ background: activas ? "#0a0a0a" : "#d4d4d4" }}
          >
            <span
              className="absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white transition-transform"
              style={{ transform: activas ? "translateX(20px)" : "translateX(0)", boxShadow: "0 1px 2px rgba(0,0,0,.2)" }}
            />
          </button>
        </div>

        <div className="mt-5 rounded-lg bg-slate-50 border border-slate-100 p-4 flex flex-col gap-1.5 text-sm text-slate-500">
          <p><span className="font-medium text-slate-700">Sólo compras verificadas.</span> Puede opinar quien tiene un pedido pagado con ese producto (no cancelado ni reembolsado). Una reseña por cliente y producto.</p>
          <p>Las fotos se reducen y se les quitan los metadatos (ubicación GPS) antes de publicarse.</p>
          {!activas && <p className="text-slate-400">Apagadas, la tienda no muestra estrellas ni acepta reseñas nuevas. Las existentes se conservan.</p>}
        </div>
      </section>

      <section className={cardCls} style={{ opacity: activas ? 1 : 0.55 }}>
        <h2 className="text-base font-semibold text-slate-800 mb-1">Moderación</h2>
        <p className="text-sm text-slate-400 mb-4">Qué pasa cuando llega una reseña nueva.</p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {MODOS.map((m) => {
            const sel = moderacion === m.value;
            return (
              <button
                key={m.value}
                type="button"
                disabled={!activas}
                onClick={() => setModeracion(m.value)}
                className="text-left rounded-lg p-4 transition-colors"
                style={{
                  border:     sel ? "1px solid #0a0a0a" : "1px solid #e5e5e5",
                  background: sel ? "rgba(10,10,10,0.04)" : "#fff",
                  cursor:     activas ? "pointer" : "not-allowed",
                }}
              >
                <span className="block text-sm font-semibold text-slate-800">{m.titulo}</span>
                <span className="block mt-1 text-xs text-slate-500">{m.desc}</span>
              </button>
            );
          })}
        </div>
      </section>

      <div className="flex justify-end">
        <button
          type="button"
          onClick={handleSave}
          disabled={!dirty || saving}
          className="rounded-lg px-5 py-2.5 text-sm font-semibold transition-colors"
          style={{
            background: dirty && !saving ? "var(--color-cq-blue-900, #0a0a0a)" : "#d4d4d4",
            color:      "#fff",
            cursor:     dirty && !saving ? "pointer" : "not-allowed",
          }}
        >
          {saving ? "Guardando…" : "Guardar cambios"}
        </button>
      </div>
    </div>
  );
}
