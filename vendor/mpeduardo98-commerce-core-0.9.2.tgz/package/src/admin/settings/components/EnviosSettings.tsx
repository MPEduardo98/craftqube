"use client";
// admin/settings/components/EnviosSettings.tsx
// ─────────────────────────────────────────────────────────────
// Ajustes → Envíos. La tienda elige cómo cobra el envío:
//
//   Dinámico     → guías por peso/volumen + flete, por zona.
//   Precio fijo  → paqueterías (nombre, logo, días) con un precio
//                  por zona; el cliente elige una en el checkout.
//
// En los dos modos: zonas (grupos de estados) y envío gratis desde
// cierto subtotal. Todo se guarda de una vez (PUT /api/admin/envio).
// ─────────────────────────────────────────────────────────────
import { useRef, useState } from "react";
import { useRouter }        from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { useAlert }         from "../../../context/AlertContext";
import { ESTADOS_MX }       from "../../../data/estados-mx";
import { Modal }            from "../../../ui/Modal";
import MX                   from "country-flag-icons/react/3x2/MX";
import type { EnvioConfigForm, PaqueteriaForm, ZonaForm } from "../lib/envioConfig";
import type { EnvioModo }   from "../../../checkout/types";

const cardCls  = "rounded-xl border border-slate-200 bg-white p-5";
const campoCls = "h-9 rounded-lg px-3 text-sm bg-white border border-slate-200 text-slate-800 placeholder:text-slate-400";
const inputCls = `w-full ${campoCls}`;
const labelCls = "text-xs font-medium text-slate-600";
const linkBtn  = "text-[13px] font-medium text-slate-900 hover:underline underline-offset-4";
const iconBtn  = "shrink-0 w-8 h-8 rounded-lg border border-slate-200 text-slate-500 hover:text-slate-900 hover:border-slate-300 flex items-center justify-center disabled:opacity-30 disabled:pointer-events-none";

const suave = { duration: 0.25, ease: [0.22, 1, 0.36, 1] } as const;

let contadorClave = 0;
const claveNueva = (p: string) => `${p}n${Date.now().toString(36)}${contadorClave++}`;

/* ── Piezas pequeñas ───────────────────────────────────────── */
function Interruptor({ activo, onChange, etiqueta }: { activo: boolean; onChange: (v: boolean) => void; etiqueta: string }) {
  return (
    <button type="button" role="switch" aria-checked={activo} aria-label={etiqueta}
      onClick={() => onChange(!activo)}
      className="relative w-9 h-5 rounded-full shrink-0"
      style={{ background: activo ? "#0a0a0a" : "#d4d4d4" }}>
      <motion.span layout transition={{ type: "spring", stiffness: 600, damping: 35 }}
        className="absolute top-0.5 w-4 h-4 rounded-full bg-white"
        style={{ left: activo ? 18 : 2, boxShadow: "0 1px 2px rgba(0,0,0,0.2)" }} />
    </button>
  );
}

function CampoPesos({ value, onChange, placeholder }: { value: string; onChange: (v: string) => void; placeholder?: string }) {
  return (
    <div className="relative">
      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-slate-400">$</span>
      <input type="number" min="0" step="0.01" inputMode="decimal" value={value} placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)} className={`${inputCls} pl-6 tabular-nums`} />
    </div>
  );
}

function Seccion({ titulo, descripcion, accion, children }: {
  titulo: string; descripcion?: string; accion?: React.ReactNode; children: React.ReactNode;
}) {
  return (
    <motion.section layout="position" transition={suave} className={cardCls}>
      <div className="flex items-start justify-between gap-4 mb-4">
        <div>
          <h2 className="text-[15px] font-semibold text-slate-900">{titulo}</h2>
          {descripcion && <p className="mt-0.5 text-sm text-slate-500">{descripcion}</p>}
        </div>
        {accion}
      </div>
      {children}
    </motion.section>
  );
}

/* ══════════════════════════════════════════════════════════ */
export function EnviosSettings({ inicial }: { inicial: EnvioConfigForm }) {
  const router = useRouter();
  const alert  = useAlert();

  const [modo,        setModo]        = useState<EnvioModo>(inicial.modo);
  const [gratisActivo, setGratisActivo] = useState(inicial.gratis_desde.trim() !== "");
  const [gratisDesde, setGratisDesde] = useState(inicial.gratis_desde);
  const [caps,        setCaps]        = useState(inicial.caps);
  const [zonas,       setZonas]       = useState<ZonaForm[]>(inicial.zonas);
  const [paqs,        setPaqs]        = useState<PaqueteriaForm[]>(inicial.paqueterias);
  const [guardando,   setGuardando]   = useState(false);
  const [subiendo,    setSubiendo]    = useState<string | null>(null);
  const archivo = useRef<HTMLInputElement>(null);
  const paqParaLogo = useRef<string | null>(null);

  // Modal de estados
  const [modalZona,   setModalZona]   = useState<number | null>(null);
  const [buffer,      setBuffer]      = useState<Set<string>>(new Set());
  const [buscar,      setBuscar]      = useState("");
  const [paisAbierto, setPaisAbierto] = useState(false);

  /* ── Zonas ── */
  const updateZona = (i: number, patch: Partial<ZonaForm>) =>
    setZonas((zs) => zs.map((z, idx) => idx === i ? { ...z, ...patch } : z));
  const addZona = () =>
    setZonas((zs) => [...zs, { clave: claveNueva("z"), nombre: "", activa: true, estados: [], precio_guia: "", flete_base: "", flete_por_kg: "" }]);
  const removeZona = (i: number) => setZonas((zs) => zs.filter((_, idx) => idx !== i));

  const abrirModal = (zi: number) => { setBuffer(new Set(zonas[zi].estados)); setBuscar(""); setPaisAbierto(false); setModalZona(zi); };
  const cerrarModal = () => setModalZona(null);
  const toggleBuffer = (estado: string) =>
    setBuffer((prev) => { const n = new Set(prev); if (n.has(estado)) n.delete(estado); else n.add(estado); return n; });
  const toggleTodos = () =>
    setBuffer((prev) => prev.size === ESTADOS_MX.length ? new Set() : new Set(ESTADOS_MX));
  // Un estado pertenece a una sola zona: al confirmar se quita de las demás
  const confirmarModal = () => {
    if (modalZona === null) return;
    const zi = modalZona, sel = buffer;
    setZonas((zs) => zs.map((z, idx) =>
      idx === zi ? { ...z, estados: ESTADOS_MX.filter((e) => sel.has(e)) }
                 : { ...z, estados: z.estados.filter((e) => !sel.has(e)) }
    ));
    setModalZona(null);
  };

  /* ── Paqueterías ── */
  const updatePaq = (clave: string, patch: Partial<PaqueteriaForm>) =>
    setPaqs((ps) => ps.map((p) => p.clave === clave ? { ...p, ...patch } : p));
  const addPaq = () =>
    setPaqs((ps) => [...ps, { clave: claveNueva("p"), nombre: "", logo_url: "", dias_min: "", dias_max: "", activa: true, precios: {} }]);
  const removePaq = (clave: string) => setPaqs((ps) => ps.filter((p) => p.clave !== clave));
  const moverPaq = (i: number, d: -1 | 1) =>
    setPaqs((ps) => {
      const j = i + d;
      if (j < 0 || j >= ps.length) return ps;
      const n = [...ps]; [n[i], n[j]] = [n[j], n[i]]; return n;
    });

  const elegirLogo = (clave: string) => { paqParaLogo.current = clave; archivo.current?.click(); };
  const subirLogo = async (file: File) => {
    const clave = paqParaLogo.current;
    if (!clave) return;
    setSubiendo(clave);
    try {
      const fd = new FormData();
      fd.append("file", file);
      fd.append("prefix", "paqueterias");
      const res  = await fetch("/api/admin/media", { method: "POST", body: fd });
      const json = await res.json();
      if (json.success) updatePaq(clave, { logo_url: json.data.url });
      else alert.error(json.error ?? "No se pudo subir el logo");
    } catch {
      alert.error("Error de red al subir el logo");
    } finally {
      setSubiendo(null);
      if (archivo.current) archivo.current.value = "";
    }
  };

  /* ── Guardar ── */
  const guardar = async () => {
    if (zonas.some((z) => !z.nombre.trim())) { alert.error("Toda zona necesita un nombre"); return; }
    if (modo === "fijo" && paqs.some((p) => !p.nombre.trim())) { alert.error("Toda paquetería necesita un nombre"); return; }
    if (gratisActivo && !(Number(gratisDesde) > 0)) { alert.error("Escribe desde qué monto el envío es gratis"); return; }
    if (modo === "fijo" && !paqs.some((p) => p.activa && Object.values(p.precios).some((v) => v.trim() !== ""))) {
      alert.error("Agrega al menos una paquetería activa con precio en alguna zona", "Sin paqueterías");
      return;
    }

    setGuardando(true);
    try {
      const res = await fetch("/api/admin/envio", {
        method:  "PUT",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({
          modo,
          gratis_desde: gratisActivo ? gratisDesde : "",
          caps, zonas, paqueterias: paqs,
        }),
      });
      const json = await res.json();
      if (json.success) { alert.success("Configuración de envíos guardada"); router.refresh(); }
      else alert.error(json.error ?? "No se pudo guardar");
    } catch {
      alert.error("Error de red al guardar");
    } finally {
      setGuardando(false);
    }
  };

  const zonasConNombre = zonas.filter((z) => z.nombre.trim());

  return (
    <div className="flex flex-col gap-5">
      <input ref={archivo} type="file" accept="image/png,image/jpeg,image/webp,image/svg+xml" className="hidden"
        onChange={(e) => { const f = e.target.files?.[0]; if (f) void subirLogo(f); }} />

      {/* ── Modo ── */}
      <Seccion titulo="Cómo cobras el envío" descripcion="Elige un modo para toda la tienda.">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {([
            { valor: "dinamico", titulo: "Dinámico",    texto: "Se calcula con el peso y las medidas del pedido, según la zona." },
            { valor: "fijo",     titulo: "Precio fijo", texto: "El cliente elige paquetería. Tú pones el precio por zona." },
          ] as const).map((o) => {
            const sel = modo === o.valor;
            return (
              <button key={o.valor} type="button" onClick={() => setModo(o.valor)}
                className="relative text-left rounded-xl p-4 border border-slate-200 hover:border-slate-300"
                style={{ borderColor: sel ? "#0a0a0a" : undefined, boxShadow: sel ? "0 0 0 1px #0a0a0a" : undefined }}>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-semibold text-slate-900">{o.titulo}</span>
                  <span className="w-4 h-4 rounded-full border flex items-center justify-center"
                    style={{ borderColor: sel ? "#0a0a0a" : "#d4d4d4" }}>
                    <AnimatePresence>
                      {sel && (
                        <motion.span initial={{ scale: 0 }} animate={{ scale: 1 }} exit={{ scale: 0 }}
                          transition={{ type: "spring", stiffness: 600, damping: 30 }}
                          className="w-2 h-2 rounded-full bg-slate-900" />
                      )}
                    </AnimatePresence>
                  </span>
                </div>
                <p className="mt-1 text-[13px] text-slate-500">{o.texto}</p>
              </button>
            );
          })}
        </div>
      </Seccion>

      {/* ── Envío gratis ── */}
      <Seccion
        titulo="Envío gratis"
        descripcion="A partir de este subtotal, el envío no se cobra."
        accion={<Interruptor activo={gratisActivo} onChange={setGratisActivo} etiqueta="Envío gratis" />}
      >
        <AnimatePresence initial={false}>
          {gratisActivo ? (
            <motion.div key="on" initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }} transition={suave} className="overflow-hidden">
              <div className="flex flex-col gap-1.5 max-w-xs">
                <label className={labelCls}>Compras desde</label>
                <CampoPesos value={gratisDesde} onChange={setGratisDesde} placeholder="1500" />
              </div>
            </motion.div>
          ) : (
            <motion.p key="off" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="text-sm text-slate-400">Desactivado: el envío siempre se cobra.</motion.p>
          )}
        </AnimatePresence>
      </Seccion>

      {/* ── Zonas ── */}
      <Seccion
        titulo="Zonas"
        descripcion={modo === "dinamico"
          ? "Cada zona agrupa estados con su precio por guía y su flete (base + $/kg)."
          : "Cada zona agrupa estados. Las paqueterías tienen un precio por zona."}
        accion={<button type="button" onClick={addZona} className={linkBtn}>+ Agregar zona</button>}
      >
        {zonas.length === 0 && <p className="text-sm text-slate-400">Sin zonas. Agrega al menos una.</p>}
        <div className="flex flex-col gap-3">
          <AnimatePresence initial={false}>
            {zonas.map((z, zi) => (
              <motion.div key={z.clave} layout="position"
                initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, height: 0 }}
                transition={suave}
                className="rounded-lg border border-slate-200 p-4 flex flex-col gap-4">
                <div className="flex items-center gap-3">
                  <input type="text" value={z.nombre} placeholder="Nombre de la zona (ej. Centro)"
                    onChange={(e) => updateZona(zi, { nombre: e.target.value })}
                    className={`${inputCls} font-medium`} />
                  <label className="flex items-center gap-2 shrink-0 select-none text-sm text-slate-600">
                    <Interruptor activo={z.activa} onChange={(v) => updateZona(zi, { activa: v })} etiqueta="Zona activa" />
                    Activa
                  </label>
                  <button type="button" onClick={() => removeZona(zi)} className={iconBtn} title="Eliminar zona" aria-label="Eliminar zona">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>
                  </button>
                </div>

                {modo === "dinamico" && (
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="flex flex-col gap-1.5">
                      <label className={labelCls}>Precio por guía</label>
                      <CampoPesos value={z.precio_guia} onChange={(v) => updateZona(zi, { precio_guia: v })} />
                    </div>
                    <div className="flex flex-col gap-1.5">
                      <label className={labelCls}>Flete base</label>
                      <CampoPesos value={z.flete_base} onChange={(v) => updateZona(zi, { flete_base: v })} />
                    </div>
                    <div className="flex flex-col gap-1.5">
                      <label className={labelCls}>Flete por kg</label>
                      <CampoPesos value={z.flete_por_kg} onChange={(v) => updateZona(zi, { flete_por_kg: v })} />
                    </div>
                  </div>
                )}

                <div className="flex items-center justify-between gap-4">
                  <p className="text-[13px] text-slate-500 line-clamp-2 min-w-0">
                    {z.estados.length === 0 ? "Ningún estado asignado."
                      : z.estados.length === ESTADOS_MX.length ? "Todos los estados de México."
                      : [...z.estados].sort((a, b) => a.localeCompare(b)).join(", ")}
                  </p>
                  <button type="button" onClick={() => abrirModal(zi)} className={`${linkBtn} shrink-0`}>
                    Elegir estados ({z.estados.length})
                  </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </Seccion>

      {/* ── Según el modo ── */}
      <AnimatePresence mode="wait" initial={false}>
        {modo === "dinamico" ? (
          <motion.div key="dinamico" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }} transition={suave}>
            <Seccion titulo="Parámetros de guía"
              descripcion="Límites de una guía. Si un pedido los excede se cobran más guías; un artículo que supere la dimensión máxima va por flete.">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {([
                  ["peso_max_kg",    "Peso máximo por guía (kg)",   "0.1"],
                  ["volumen_max_m3", "Volumen máximo por guía (m³)", "0.0001"],
                  ["dim_max_cm",     "Dimensión máxima por lado (cm)", "1"],
                ] as const).map(([k, l, step]) => (
                  <div key={k} className="flex flex-col gap-1.5">
                    <label className={labelCls}>{l}</label>
                    <input type="number" min="0" step={step} value={caps[k]}
                      onChange={(e) => setCaps((p) => ({ ...p, [k]: e.target.value }))} className={inputCls} />
                  </div>
                ))}
              </div>
            </Seccion>
          </motion.div>
        ) : (
          <motion.div key="fijo" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }} transition={suave}>
            <Seccion titulo="Paqueterías"
              descripcion="Lo que el cliente podrá elegir. Deja un precio vacío si la paquetería no llega a esa zona."
              accion={<button type="button" onClick={addPaq} className={linkBtn}>+ Agregar paquetería</button>}>
              {paqs.length === 0 && (
                <div className="rounded-lg border border-dashed border-slate-200 px-6 py-10 text-center">
                  <p className="text-sm font-medium text-slate-900">Todavía no hay paqueterías</p>
                  <p className="mt-1 text-[13px] text-slate-500">Agrega Estafeta, FedEx, DHL… con su logo y sus precios.</p>
                  <button type="button" onClick={addPaq} className="btn-primary mt-4">Agregar paquetería</button>
                </div>
              )}

              <div className="flex flex-col gap-3">
                <AnimatePresence initial={false}>
                  {paqs.map((p, i) => (
                    <motion.div key={p.clave} layout="position"
                      initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.98 }}
                      transition={suave}
                      className="rounded-lg border border-slate-200 p-4 flex flex-col gap-4"
                      style={{ opacity: p.activa ? 1 : 0.6 }}>
                      <div className="flex items-start gap-3">
                        {/* Logo */}
                        <button type="button" onClick={() => elegirLogo(p.clave)}
                          className="group relative w-16 h-16 shrink-0 rounded-lg border border-slate-200 bg-slate-50 flex items-center justify-center overflow-hidden hover:border-slate-300"
                          title="Subir logo" aria-label="Subir logo">
                          {subiendo === p.clave ? (
                            <span className="w-4 h-4 rounded-full border-2 border-slate-300 border-t-slate-900 animate-spin" />
                          ) : p.logo_url ? (
                            // eslint-disable-next-line @next/next/no-img-element
                            <img src={p.logo_url} alt={p.nombre || "Logo"} className="w-full h-full object-contain p-1.5" />
                          ) : (
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" className="text-slate-400">
                              <rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.1-3.1a2 2 0 0 0-2.8 0L6 21"/>
                            </svg>
                          )}
                          {p.logo_url && subiendo !== p.clave && (
                            <span className="absolute inset-0 bg-black/50 text-white text-[11px] font-medium flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                              Cambiar
                            </span>
                          )}
                        </button>

                        <div className="flex-1 min-w-0 grid grid-cols-1 sm:grid-cols-[1fr_auto] gap-3">
                          <div className="flex flex-col gap-1.5">
                            <label className={labelCls}>Nombre</label>
                            <input type="text" value={p.nombre} placeholder="Estafeta"
                              onChange={(e) => updatePaq(p.clave, { nombre: e.target.value })} className={inputCls} />
                          </div>
                          <div className="flex flex-col gap-1.5">
                            <label className={labelCls}>Días estimados</label>
                            <div className="flex items-center gap-2">
                              <input type="number" min="0" value={p.dias_min} placeholder="2"
                                onChange={(e) => updatePaq(p.clave, { dias_min: e.target.value })} className={`${campoCls} w-16 tabular-nums`} />
                              <span className="text-slate-400 text-sm">a</span>
                              <input type="number" min="0" value={p.dias_max} placeholder="5"
                                onChange={(e) => updatePaq(p.clave, { dias_max: e.target.value })} className={`${campoCls} w-16 tabular-nums`} />
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5 shrink-0 pt-6">
                          <Interruptor activo={p.activa} onChange={(v) => updatePaq(p.clave, { activa: v })} etiqueta="Paquetería activa" />
                          <button type="button" onClick={() => moverPaq(i, -1)} disabled={i === 0} className={iconBtn} aria-label="Subir">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="m18 15-6-6-6 6"/></svg>
                          </button>
                          <button type="button" onClick={() => moverPaq(i, 1)} disabled={i === paqs.length - 1} className={iconBtn} aria-label="Bajar">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="m6 9 6 6 6-6"/></svg>
                          </button>
                          <button type="button" onClick={() => removePaq(p.clave)} className={iconBtn} aria-label="Eliminar paquetería">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>
                          </button>
                        </div>
                      </div>

                      {/* Precio por zona */}
                      {zonasConNombre.length === 0 ? (
                        <p className="text-[13px] text-slate-400">Crea zonas arriba para ponerle precios.</p>
                      ) : (
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                          {zonasConNombre.map((z) => (
                            <div key={z.clave} className="flex flex-col gap-1.5">
                              <label className={`${labelCls} truncate`}>{z.nombre}</label>
                              <CampoPesos value={p.precios[z.clave] ?? ""} placeholder="No envía"
                                onChange={(v) => updatePaq(p.clave, { precios: { ...p.precios, [z.clave]: v } })} />
                            </div>
                          ))}
                        </div>
                      )}
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            </Seccion>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Guardar ── */}
      <div className="flex justify-end">
        <button type="button" onClick={guardar} disabled={guardando} className="btn-primary">
          {guardando ? "Guardando…" : "Guardar cambios"}
        </button>
      </div>

      {/* ── Modal de estados ── */}
      <Modal
        open={modalZona !== null}
        onClose={cerrarModal}
        title="Estados de la zona"
        maxWidth="34rem"
        footer={
          <>
            <button type="button" onClick={cerrarModal} className="btn-secondary">Cancelar</button>
            <button type="button" onClick={confirmarModal} className="btn-primary">Listo</button>
          </>
        }
      >
        {modalZona !== null && (() => {
          const q = buscar.trim().toLowerCase();
          const filtrados = ESTADOS_MX.filter((e) => e.toLowerCase().includes(q));
          const todosSel = buffer.size === ESTADOS_MX.length;
          const enOtraZona = new Map<string, string>();
          zonas.forEach((z, idx) => {
            if (idx !== modalZona) z.estados.forEach((e) => enOtraZona.set(e, z.nombre.trim() || `Zona ${idx + 1}`));
          });
          return (
            <div className="flex flex-col gap-3">
              <div className="relative">
                <svg className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-4.35-4.35M17 11a6 6 0 11-12 0 6 6 0 0112 0z" />
                </svg>
                <input value={buscar} onChange={(e) => setBuscar(e.target.value)} placeholder="Buscar estado" className={`${inputCls} pl-9`} />
              </div>

              <div className="rounded-lg border border-slate-200 overflow-hidden">
                <div className="flex items-center gap-3 px-3 py-2.5 bg-slate-50 border-b border-slate-100">
                  <input type="checkbox" checked={todosSel} onChange={toggleTodos} onClick={(e) => e.stopPropagation()}
                    className="w-4 h-4 rounded accent-slate-900" />
                  <button type="button" onClick={() => setPaisAbierto((o) => !o)} className="flex items-center gap-3 flex-1 min-w-0 text-left">
                    <MX title="México" style={{ width: 22, height: 15, borderRadius: 2, flexShrink: 0 }} />
                    <span className="text-sm font-semibold text-slate-700 flex-1">México</span>
                    <span className="text-xs text-slate-400">{buffer.size} de {ESTADOS_MX.length}</span>
                    <svg className={`w-4 h-4 text-slate-400 transition-transform ${(paisAbierto || q) ? "rotate-180" : ""}`}
                      fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 9l6 6 6-6" />
                    </svg>
                  </button>
                </div>

                {(paisAbierto || q) && (
                  <div className="max-h-[320px] overflow-y-auto">
                    {filtrados.length === 0 ? (
                      <p className="text-sm text-slate-400 px-3 py-4 text-center">Sin resultados.</p>
                    ) : filtrados.map((estado) => (
                      <label key={estado} className="flex items-center gap-3 pl-9 pr-3 py-2 hover:bg-slate-50 cursor-pointer select-none border-b border-slate-50 last:border-b-0">
                        <input type="checkbox" checked={buffer.has(estado)} onChange={() => toggleBuffer(estado)}
                          className="w-4 h-4 rounded accent-slate-900" />
                        <span className="text-sm text-slate-700">{estado}</span>
                        {!buffer.has(estado) && enOtraZona.has(estado) && (
                          <span className="ml-auto text-xs text-slate-400">en {enOtraZona.get(estado)}</span>
                        )}
                      </label>
                    ))}
                  </div>
                )}
              </div>
              <p className="text-xs text-slate-400">
                Un estado pertenece a una sola zona: al confirmar, se quita de la zona donde estuviera.
              </p>
            </div>
          );
        })()}
      </Modal>
    </div>
  );
}
