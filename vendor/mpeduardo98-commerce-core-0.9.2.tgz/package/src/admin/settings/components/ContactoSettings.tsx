"use client";
import Link from "next/link";
import { useState, type FormEvent } from "react";
import { CAMPOS_CONTACTO, type ContactoConfig, type ReglaCampo } from "../../../contacto/types";

const input = "w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm";
export function ContactoSettings({ inicial, correoConfigurado }: { inicial: ContactoConfig; correoConfigurado: boolean }) {
  const [config, setConfig] = useState(inicial);
  const [guardado, setGuardado] = useState(inicial);
  const [saving, setSaving] = useState(false);
  const [aviso, setAviso] = useState("");
  async function guardar(e: FormEvent) {
    e.preventDefault(); setSaving(true); setAviso("");
    try {
      const res = await fetch("/api/admin/contacto/ajustes", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(config) });
      const json = await res.json();
      if (!res.ok || !json.success) throw new Error(json.error || "No se pudo guardar.");
      setConfig(json.data); setGuardado(json.data); setAviso("Configuración guardada.");
    } catch (e) { setAviso(e instanceof Error ? e.message : "Error de conexión."); }
    finally { setSaving(false); }
  }
  return <form onSubmit={guardar} className="flex flex-col gap-5">
    <fieldset disabled={saving} className="rounded-xl border border-slate-200 bg-white p-5 flex flex-col gap-4">
      <h2 className="text-base font-semibold">Página de contacto</h2>
      <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={config.activo} onChange={e => setConfig({ ...config, activo: e.target.checked })} />Activar formulario de contacto</label>
      <label className="text-sm">Título<input className={input} required maxLength={120} value={config.titulo} onChange={e => setConfig({ ...config, titulo: e.target.value })} /></label>
      <label className="text-sm">Descripción<textarea className={input} rows={3} maxLength={600} value={config.descripcion} onChange={e => setConfig({ ...config, descripcion: e.target.value })} /></label>
      <label className="text-sm">Recibir consultas en<input className={input} type="email" required={config.activo} maxLength={254} value={config.destinatario} onChange={e => setConfig({ ...config, destinatario: e.target.value })} placeholder="contacto@tutienda.com" /></label>
      <p className="text-sm text-slate-500">El cliente recibe un acuse de recibo. Tú recibes los datos de la consulta y puedes responder directamente desde tu correo.</p>
      {!correoConfigurado && <p role="status" className="text-sm text-amber-700">Falta configurar Resend en el servidor. Las consultas se conservan en el panel, pero no se enviarán correos hasta configurar RESEND_API_KEY y RESEND_FROM_EMAIL.</p>}
      <h3 className="font-semibold text-sm">Datos que solicitar</h3>
      <p className="text-sm text-slate-500">Correo y mensaje siempre son obligatorios. Los demás campos los eliges tú.</p>
      {CAMPOS_CONTACTO.map(c => <label key={c.id} className="flex flex-wrap items-center justify-between gap-2 text-sm">
        <span>{c.etiqueta}</span>
        <select aria-label={`Solicitar ${c.etiqueta}`} className="rounded-lg border border-slate-200 bg-white px-3 py-2" value={config.campos[c.id]} disabled={c.id === "email" || c.id === "mensaje"} onChange={e => setConfig({ ...config, campos: { ...config.campos, [c.id]: e.target.value as ReglaCampo } })}>
          <option value="oculto">No solicitar</option><option value="opcional">Opcional</option><option value="obligatorio">Obligatorio</option>
        </select>
      </label>)}
    </fieldset>
    <p role="status" className="text-sm">{aviso}</p>
    <div className="flex flex-wrap items-center justify-between gap-3">
      <Link className="text-sm underline" href="/admin/contacto">Ver mensajes recibidos</Link>
      <button type="submit" disabled={saving || JSON.stringify(config) === JSON.stringify(guardado)} className="rounded-lg bg-black px-5 py-2.5 text-sm font-semibold text-white disabled:opacity-50">{saving ? "Guardando…" : "Guardar cambios"}</button>
    </div>
  </form>;
}
