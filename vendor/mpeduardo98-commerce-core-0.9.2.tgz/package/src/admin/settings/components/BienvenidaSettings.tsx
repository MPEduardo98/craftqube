"use client";
// admin/settings/components/BienvenidaSettings.tsx
// ─────────────────────────────────────────────────────────────
// Ajustes → Bienvenida: encender el modal de la tienda, elegir el
// cupón que se regala y ver a los clientes potenciales captados.
// El diseño del modal lo hace cada tienda; aquí sólo se configura.
// ─────────────────────────────────────────────────────────────
import { useCallback, useEffect, useState } from "react";
import Link          from "next/link";
import { useRouter } from "next/navigation";
import { useAlert }  from "../../../context/AlertContext";
import type { BienvenidaConfig, Suscriptor } from "../../../bienvenida/types";
import type { CuponElegible } from "../../../bienvenida/cuponesElegibles";

const cardCls = "rounded-xl border border-slate-200 bg-white p-5";

function describir(c: CuponElegible): string {
  if (c.tipo === "porcentaje")   return `${Number(c.valor.toFixed(2))}% de descuento`;
  if (c.tipo === "monto_fijo")   return `$${c.valor.toFixed(2)} de descuento`;
  if (c.tipo === "envio_gratis") return "Envío gratis";
  return "2x1";
}

export function BienvenidaSettings({ inicial, cupones }: { inicial: BienvenidaConfig; cupones: CuponElegible[] }) {
  const router = useRouter();
  const alert  = useAlert();

  const [activa,  setActiva]  = useState(inicial.activa);
  const [cuponId, setCuponId] = useState<number | null>(inicial.cupon_id);
  const [saving,  setSaving]  = useState(false);

  const dirty = activa !== inicial.activa || cuponId !== inicial.cupon_id;
  const cupon = cupones.find((c) => c.id === cuponId) ?? null;

  const handleSave = async () => {
    if (activa && !cuponId) { alert.error("Elige el cupón que se enviará"); return; }
    setSaving(true);
    try {
      const res  = await fetch("/api/admin/bienvenida/ajustes", {
        method:  "PUT",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ activa, cupon_id: cuponId }),
      });
      const json = await res.json();
      if (json.success) {
        alert.success("Ajustes de bienvenida guardados");
        router.refresh();
      } else {
        alert.error(json.error ?? "No se pudo guardar");
      }
    } catch {
      alert.error("Error de red al guardar");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="flex flex-col gap-5">
      <section className={cardCls}>
        <div className="flex items-start justify-between gap-4">
          <div>
            <h2 className="text-base font-semibold text-slate-800 mb-1">Modal de bienvenida</h2>
            <p className="text-sm text-slate-400">
              Los visitantes dejan su nombre y correo y reciben un cupón de descuento.
            </p>
          </div>
          <button
            type="button"
            role="switch"
            aria-checked={activa}
            aria-label="Activar modal de bienvenida"
            onClick={() => setActiva(!activa)}
            className="relative shrink-0 w-11 h-6 rounded-full transition-colors"
            style={{ background: activa ? "#0a0a0a" : "#d4d4d4" }}
          >
            <span
              className="absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white transition-transform"
              style={{ transform: activa ? "translateX(20px)" : "translateX(0)", boxShadow: "0 1px 2px rgba(0,0,0,.2)" }}
            />
          </button>
        </div>

        <div className="mt-5 rounded-lg bg-slate-50 border border-slate-100 p-4 flex flex-col gap-1.5 text-sm text-slate-500">
          <p><span className="font-medium text-slate-700">El código aparece en el modal</span> en cuanto se suscribe, y también le llega por correo.</p>
          <p><span className="font-medium text-slate-700">Es personal.</span> El cupón elegido sólo funciona al pagar con un correo suscrito: si alguien lo comparte, a otros no les sirve.</p>
          {!activa && <p className="text-slate-400">Apagado, la tienda no muestra el modal. Los suscriptores y sus cupones se conservan.</p>}
        </div>
      </section>

      <section className={cardCls}>
        <h2 className="text-base font-semibold text-slate-800 mb-1">Cupón que se envía</h2>
        <p className="text-sm text-slate-400 mb-4">
          Crea un cupón exclusivo para la bienvenida en{" "}
          <Link href="/admin/cupones" className="underline text-slate-600">Cupones</Link>{" "}
          y elígelo aquí. No uses uno que ya compartiste: al elegirlo, deja de servir para quien no esté suscrito.
        </p>

        <select
          value={cuponId ?? ""}
          onChange={(e) => setCuponId(e.target.value ? Number(e.target.value) : null)}
          className="w-full rounded-lg border border-slate-200 px-3 py-2.5 text-sm bg-white"
        >
          <option value="">Sin cupón</option>
          {cupones.map((c) => (
            <option key={c.id} value={c.id}>
              {c.codigo} · {describir(c)}{c.vigente ? "" : " (no vigente)"}
            </option>
          ))}
        </select>

        {cupon && (
          <div className="mt-3 flex flex-col gap-1.5 text-xs">
            {!cupon.vigente && (
              <p className="text-red-600">Este cupón está desactivado, vencido o agotado: el modal no se mostrará hasta que lo corrijas.</p>
            )}
            {cupon.uso_maximo_usuario !== 1 && (
              <p className="text-amber-600">Recomendado: que se pueda usar 1 vez por cliente (ahora: {cupon.uso_maximo_usuario || "sin límite"}).</p>
            )}
            {cupon.aplica_a !== "primera_compra" && (
              <p className="text-slate-500">Si quieres que sólo sirva a clientes nuevos, márcalo como “primera compra”.</p>
            )}
          </div>
        )}
      </section>

      <div className="flex justify-end">
        <button
          type="button"
          onClick={handleSave}
          disabled={!dirty || saving}
          className="rounded-lg px-5 py-2.5 text-sm font-semibold transition-colors"
          style={{
            background: dirty && !saving ? "var(--color-cq-blue-900, #0a0a0a)" : "#d4d4d4",
            color:      "#fff",
            cursor:     dirty && !saving ? "pointer" : "not-allowed",
          }}
        >
          {saving ? "Guardando…" : "Guardar cambios"}
        </button>
      </div>

      <ListaSuscriptores />
    </div>
  );
}

function ListaSuscriptores() {
  const [filas,   setFilas]   = useState<Suscriptor[]>([]);
  const [meta,    setMeta]    = useState({ total: 0, compraron: 0, page: 1, pages: 1 });
  const [q,       setQ]       = useState("");
  const [page,    setPage]    = useState(1);
  const [loading, setLoading] = useState(true);
  const [error,   setError]   = useState("");

  const cargar = useCallback((busqueda: string, pagina: number) => {
    setLoading(true);
    setError("");
    fetch(`/api/admin/bienvenida/suscriptores?q=${encodeURIComponent(busqueda)}&page=${pagina}`)
      .then((r) => r.json())
      .then((j) => {
        if (j.success) { setFilas(j.data); setMeta(j.meta); }
        else setError(j.error ?? "Error al cargar");
      })
      .catch(() => setError("Error de conexión"))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    const t = setTimeout(() => cargar(q, page), q ? 300 : 0);
    return () => clearTimeout(t);
  }, [q, page, cargar]);

  return (
    <section className={cardCls}>
      <div className="flex flex-wrap items-start justify-between gap-3 mb-4">
        <div>
          <h2 className="text-base font-semibold text-slate-800 mb-1">Suscriptores</h2>
          <p className="text-sm text-slate-400">
            {meta.total} {meta.total === 1 ? "persona" : "personas"} · {meta.compraron} ya compraron
          </p>
        </div>
        <a
          href={`/api/admin/bienvenida/suscriptores?formato=csv&q=${encodeURIComponent(q)}`}
          className="rounded-lg border border-slate-200 px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
        >
          Descargar CSV
        </a>
      </div>

      <input
        type="search"
        value={q}
        onChange={(e) => { setQ(e.target.value); setPage(1); }}
        placeholder="Buscar por nombre o correo…"
        className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm mb-3"
      />

      {error && <p className="text-sm text-red-600 mb-3">{error}</p>}

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs text-slate-400 border-b border-slate-100">
              <th className="py-2 pr-3 font-medium">Nombre</th>
              <th className="py-2 pr-3 font-medium">Correo</th>
              <th className="py-2 pr-3 font-medium">Cupón</th>
              <th className="py-2 pr-3 font-medium">Compró</th>
              <th className="py-2 font-medium">Fecha</th>
            </tr>
          </thead>
          <tbody>
            {filas.map((s) => (
              <tr key={s.id} className="border-b border-slate-50">
                <td className="py-2 pr-3 text-slate-700">{s.nombre}</td>
                <td className="py-2 pr-3 text-slate-600">{s.email}</td>
                <td className="py-2 pr-3 font-mono text-xs text-slate-500">{s.cupon_codigo ?? "—"}</td>
                <td className="py-2 pr-3 text-slate-600">{s.compro ? "Sí" : "No"}</td>
                <td className="py-2 text-slate-500 whitespace-nowrap">{new Date(s.created_at).toLocaleDateString("es-MX")}</td>
              </tr>
            ))}
            {!loading && filas.length === 0 && (
              <tr><td colSpan={5} className="py-6 text-center text-slate-400">{q ? "Sin resultados." : "Todavía no hay suscriptores."}</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {meta.pages > 1 && (
        <div className="flex items-center justify-end gap-2 mt-3 text-sm">
          <button type="button" disabled={page <= 1} onClick={() => setPage(page - 1)}
            className="rounded-lg border border-slate-200 px-3 py-1.5 disabled:opacity-40">Anterior</button>
          <span className="text-slate-500">{page} / {meta.pages}</span>
          <button type="button" disabled={page >= meta.pages} onClick={() => setPage(page + 1)}
            className="rounded-lg border border-slate-200 px-3 py-1.5 disabled:opacity-40">Siguiente</button>
        </div>
      )}
    </section>
  );
}
