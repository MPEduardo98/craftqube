"use client";
// admin/settings/components/VentaSettings.tsx
// ─────────────────────────────────────────────────────────────
// Ajustes → Modo de venta: tienda en línea (carrito y cobro) o
// catálogo (sólo mostrar productos y pedir informes). En catálogo
// se eligen además si se ven los precios y el WhatsApp de contacto.
// ─────────────────────────────────────────────────────────────
import { useState }       from "react";
import { useRouter }      from "next/navigation";
import { useAlert }       from "../../../context/AlertContext";
import { enlaceWhatsApp } from "../../../venta/whatsapp";
import type { ModoVenta, VentaConfig } from "../../../venta/types";

const cardCls  = "rounded-xl border border-slate-200 bg-white p-5";
const inputCls =
  "w-full rounded-lg px-3 py-2 text-sm bg-white border border-slate-200 text-slate-800 " +
  "focus:outline-none focus:border-blue-400 focus:ring-1 focus:ring-blue-100";

const MODOS: { value: ModoVenta; titulo: string; desc: string }[] = [
  { value: "tienda",   titulo: "Tienda en línea", desc: "Carrito, checkout y cobro con tarjeta, OXXO o transferencia." },
  { value: "catalogo", titulo: "Catálogo",        desc: "Sólo se muestran los productos. El cliente te contacta para comprar." },
];

export function VentaSettings({ inicial }: { inicial: VentaConfig }) {
  const router = useRouter();
  const alert  = useAlert();

  const [modo,           setModo]           = useState<ModoVenta>(inicial.modo);
  const [mostrarPrecios, setMostrarPrecios] = useState(inicial.mostrarPrecios);
  const [whatsapp,       setWhatsapp]       = useState(inicial.whatsapp);
  const [mensaje,        setMensaje]        = useState(inicial.mensajeWhatsapp);
  const [saving,         setSaving]         = useState(false);

  const catalogo = modo === "catalogo";
  const dirty =
    modo           !== inicial.modo           ||
    mostrarPrecios !== inicial.mostrarPrecios ||
    whatsapp       !== inicial.whatsapp       ||
    mensaje        !== inicial.mensajeWhatsapp;

  // Vista previa con los dígitos tal como se guardarán.
  const digitos = whatsapp.replace(/\D/g, "");
  const prueba  = enlaceWhatsApp(
    { whatsapp: digitos.length === 10 ? `52${digitos}` : digitos, mensajeWhatsapp: mensaje },
    { producto: "Producto de ejemplo", url: "https://tutienda.mx/productos/ejemplo" },
  );

  const handleSave = async () => {
    setSaving(true);
    try {
      const res  = await fetch("/api/admin/venta", {
        method:  "PUT",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ modo, mostrarPrecios, whatsapp, mensajeWhatsapp: mensaje }),
      });
      const json = await res.json();
      if (json.success) {
        setWhatsapp(json.data.whatsapp);
        setMensaje(json.data.mensajeWhatsapp);
        alert.success("Modo de venta guardado");
        router.refresh();
      } else {
        alert.error(json.error ?? "No se pudo guardar");
      }
    } catch {
      alert.error("Error de red al guardar");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="flex flex-col gap-5">
      <section className={cardCls}>
        <h2 className="text-base font-semibold text-slate-800 mb-1">Cómo vende la tienda</h2>
        <p className="text-sm text-slate-400 mb-4">
          Puedes cambiarlo cuando quieras; productos, pedidos y clientes se conservan.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {MODOS.map((m) => {
            const sel = modo === m.value;
            return (
              <button
                key={m.value}
                type="button"
                onClick={() => setModo(m.value)}
                className="text-left rounded-lg p-4 transition-colors"
                style={{
                  border:     sel ? "1px solid #0a0a0a" : "1px solid #e5e5e5",
                  background: sel ? "rgba(10,10,10,0.04)" : "#fff",
                }}
              >
                <span className="block text-sm font-semibold text-slate-800">{m.titulo}</span>
                <span className="block mt-1 text-xs text-slate-500">{m.desc}</span>
              </button>
            );
          })}
        </div>

        {catalogo && (
          <div className="mt-5 rounded-lg bg-slate-50 border border-slate-100 p-4 flex flex-col gap-1.5 text-sm text-slate-500">
            <p><span className="font-medium text-slate-700">Sin carrito ni checkout.</span> La tienda oculta los botones de compra y el servidor rechaza cualquier intento de pago.</p>
            <p>El modal de bienvenida se desactiva: no habría dónde usar el cupón.</p>
            <p>Los pagos que ya estaban en curso (OXXO, transferencia) se siguen acreditando.</p>
          </div>
        )}
      </section>

      <section className={cardCls} style={{ opacity: catalogo ? 1 : 0.55 }}>
        <div className="flex items-start justify-between gap-4">
          <div>
            <h2 className="text-base font-semibold text-slate-800 mb-1">Mostrar precios</h2>
            <p className="text-sm text-slate-400">
              Apagado, el catálogo dice “Precio a consultar” y Google no recibe el precio.
            </p>
          </div>
          <button
            type="button"
            role="switch"
            aria-checked={mostrarPrecios}
            aria-label="Mostrar precios en el catálogo"
            disabled={!catalogo}
            onClick={() => setMostrarPrecios(!mostrarPrecios)}
            className="relative shrink-0 w-11 h-6 rounded-full transition-colors"
            style={{ background: mostrarPrecios ? "#0a0a0a" : "#d4d4d4", cursor: catalogo ? "pointer" : "not-allowed" }}
          >
            <span
              className="absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white transition-transform"
              style={{ transform: mostrarPrecios ? "translateX(20px)" : "translateX(0)", boxShadow: "0 1px 2px rgba(0,0,0,.2)" }}
            />
          </button>
        </div>
        {!catalogo && (
          <p className="mt-3 text-xs text-slate-400">Sólo aplica en modo catálogo: una tienda en línea siempre muestra precios.</p>
        )}
      </section>

      <section className={cardCls}>
        <h2 className="text-base font-semibold text-slate-800 mb-1">Pedir informes por WhatsApp</h2>
        <p className="text-sm text-slate-400 mb-5">
          En catálogo, cada producto muestra un botón que abre WhatsApp con el mensaje ya escrito.
          Déjalo vacío si prefieres que te contacten por teléfono o correo.
        </p>

        <div className="grid grid-cols-1 gap-4">
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-medium text-slate-600">Número de WhatsApp</label>
            <input
              type="tel" value={whatsapp}
              onChange={(e) => setWhatsapp(e.target.value)}
              placeholder="52 55 1234 5678" className={inputCls}
            />
            <span className="text-xs text-slate-400">Con lada de país. Si escribes sólo 10 dígitos se toma como número de México.</span>
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-medium text-slate-600">Mensaje</label>
            <textarea
              value={mensaje} maxLength={300} rows={2}
              onChange={(e) => setMensaje(e.target.value)}
              placeholder="Hola, me interesa {producto} {url}" className={inputCls}
            />
            <span className="text-xs text-slate-400">
              <code>{"{producto}"}</code> se cambia por el nombre del producto y <code>{"{url}"}</code> por su enlace.
            </span>
          </div>

          {prueba && (
            <a href={prueba} target="_blank" rel="noopener noreferrer" className="text-sm font-medium underline text-slate-700 w-fit">
              Probar el enlace
            </a>
          )}
        </div>
      </section>

      <div className="flex justify-end">
        <button
          type="button"
          onClick={handleSave}
          disabled={!dirty || saving}
          className="rounded-lg px-5 py-2.5 text-sm font-semibold transition-colors"
          style={{
            background: dirty && !saving ? "var(--color-cq-blue-900, #0a0a0a)" : "#d4d4d4",
            color:      "#fff",
            cursor:     dirty && !saving ? "pointer" : "not-allowed",
          }}
        >
          {saving ? "Guardando…" : "Guardar cambios"}
        </button>
      </div>
    </div>
  );
}
