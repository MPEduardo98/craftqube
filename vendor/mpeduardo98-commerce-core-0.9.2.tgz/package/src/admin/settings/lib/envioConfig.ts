// admin/settings/lib/envioConfig.ts
// ─────────────────────────────────────────────────────────────
// Lectura de la configuración de envíos para Ajustes → Envíos.
// La usan la página (carga inicial) y GET /api/admin/envio.
//
// Los precios de cada paquetería se indexan por la "clave" de la
// zona (`z<id>`): el formulario también crea zonas nuevas que aún
// no tienen id, y al guardar la API traduce clave → id real.
// ─────────────────────────────────────────────────────────────
import { pool }               from "../../../db";
import type { RowDataPacket } from "mysql2";
import type { EnvioModo }     from "../../../checkout/types";

export interface CapsForm { peso_max_kg: string; volumen_max_m3: string; dim_max_cm: string; }

export interface ZonaForm {
  id?:          number;
  /** Identificador estable en el formulario: `z<id>` o uno temporal. */
  clave:        string;
  nombre:       string;
  activa:       boolean;
  estados:      string[];
  precio_guia:  string;
  flete_base:   string;
  flete_por_kg: string;
}

export interface PaqueteriaForm {
  id?:      number;
  clave:    string;
  nombre:   string;
  logo_url: string;
  dias_min: string;
  dias_max: string;
  activa:   boolean;
  /** Precio por clave de zona; "" = no envía a esa zona. */
  precios:  Record<string, string>;
}

export interface EnvioConfigForm {
  modo:         EnvioModo;
  gratis_desde: string;
  caps:         CapsForm;
  zonas:        ZonaForm[];
  paqueterias:  PaqueteriaForm[];
}

export async function leerEnvioConfigAdmin(): Promise<EnvioConfigForm> {
  const [cfgRows] = await pool.execute<RowDataPacket[]>(
    `SELECT clave, valor FROM configuracion
     WHERE clave IN ('envio_peso_max_kg','envio_volumen_max_m3','envio_dim_max_cm','envio_modo','envio_gratis_desde')`
  );
  const cfg = new Map(cfgRows.map((r) => [r.clave as string, String(r.valor ?? "")]));

  const [zonas]   = await pool.execute<RowDataPacket[]>("SELECT id, nombre, activa FROM zonas_envio ORDER BY id ASC");
  const [estados] = await pool.execute<RowDataPacket[]>("SELECT zona_id, estado FROM zona_estados ORDER BY estado ASC");
  const [tarifas] = await pool.execute<RowDataPacket[]>(
    "SELECT zona_id, tipo_calculo, precio_base, precio_por_kg FROM tarifas_envio WHERE tipo_calculo IN ('por_guia','flete')"
  );
  const [paqs]    = await pool.execute<RowDataPacket[]>(
    "SELECT id, nombre, logo_url, dias_min, dias_max, activa FROM paqueterias ORDER BY orden ASC, id ASC"
  );
  const [precios] = await pool.execute<RowDataPacket[]>("SELECT paqueteria_id, zona_id, precio FROM paqueteria_precios");

  return {
    modo:         cfg.get("envio_modo") === "fijo" ? "fijo" : "dinamico",
    gratis_desde: cfg.get("envio_gratis_desde") ?? "",
    caps: {
      peso_max_kg:    cfg.get("envio_peso_max_kg")    || "5",
      volumen_max_m3: cfg.get("envio_volumen_max_m3") || "0.0109",
      dim_max_cm:     cfg.get("envio_dim_max_cm")     || "27",
    },
    zonas: zonas.map((z): ZonaForm => {
      const guia  = tarifas.find((t) => t.zona_id === z.id && t.tipo_calculo === "por_guia");
      const flete = tarifas.find((t) => t.zona_id === z.id && t.tipo_calculo === "flete");
      return {
        id:           z.id,
        clave:        `z${z.id}`,
        nombre:       z.nombre,
        activa:       Boolean(z.activa),
        estados:      estados.filter((e) => e.zona_id === z.id).map((e) => e.estado as string),
        precio_guia:  guia  ? String(guia.precio_base)  : "",
        flete_base:   flete ? String(flete.precio_base) : "",
        flete_por_kg: flete ? String(flete.precio_por_kg ?? "") : "",
      };
    }),
    paqueterias: paqs.map((p): PaqueteriaForm => ({
      id:       p.id,
      clave:    `p${p.id}`,
      nombre:   p.nombre,
      logo_url: p.logo_url ?? "",
      dias_min: p.dias_min == null ? "" : String(p.dias_min),
      dias_max: p.dias_max == null ? "" : String(p.dias_max),
      activa:   Boolean(p.activa),
      precios:  Object.fromEntries(
        precios.filter((x) => x.paqueteria_id === p.id).map((x) => [`z${x.zona_id}`, String(Number(x.precio))])
      ),
    })),
  };
}
