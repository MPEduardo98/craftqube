"use client";
import { useEffect, useState } from "react";
import { CAMPOS_CONTACTO, type MensajeContacto } from "../../contacto/types";

export function MensajesContacto() {
  const [pagina, setPagina] = useState(1);
  const [mensajes, setMensajes] = useState<MensajeContacto[]>([]);
  const [hayMas, setHayMas] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [revision, setRevision] = useState(0);
  const [saving, setSaving] = useState<number | null>(null);
  useEffect(() => {
    const controller = new AbortController();
    setLoading(true); setError("");
    fetch(`/api/admin/contacto?pagina=${pagina}`, { signal: controller.signal }).then(async res => {
      const json = await res.json();
      if (!res.ok || !json.success) throw new Error("No se pudieron cargar los mensajes.");
      if (!controller.signal.aborted) { setMensajes(json.data.mensajes); setHayMas(json.data.hayMas); }
    }).catch(e => { if (!controller.signal.aborted) setError(e.message); }).finally(() => { if (!controller.signal.aborted) setLoading(false); });
    return () => controller.abort();
  }, [pagina, revision]);
  async function cambiar(id: number, estado: MensajeContacto["estado"]) {
    setSaving(id); setError("");
    try {
      const res = await fetch("/api/admin/contacto", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, estado }) });
      if (!res.ok) throw new Error("No se pudo cambiar el estado.");
      setMensajes(actual => actual.map(m => m.id === id ? { ...m, estado } : m));
    } catch (e) { setError(e instanceof Error ? e.message : "Error de conexión."); }
    finally { setSaving(null); }
  }
  const envio = { enviada: "Enviada", pendiente: "Pendiente", error: "No enviada" };
  return <div className="flex flex-col gap-4">
    <div><button disabled={loading || saving !== null} onClick={() => setRevision(r => r + 1)} className="text-sm underline">Actualizar mensajes</button></div>
    {error && <p role="alert">{error}</p>}
    {loading ? <p role="status">Cargando mensajes…</p> : mensajes.length === 0 ? <p>No hay mensajes recibidos.</p> : mensajes.map(m => <article key={m.id} className="rounded-xl border border-slate-200 bg-white p-5">
      <div className="flex flex-wrap justify-between gap-3 mb-4">
        <h2 className="font-semibold">Consulta #{m.id} · {m.datos.nombre || m.datos.email}</h2>
        <select aria-label={`Estado de consulta ${m.id}`} value={m.estado} disabled={saving !== null} onChange={e => cambiar(m.id, e.target.value as MensajeContacto["estado"])} className="rounded-lg border border-slate-200 px-3 py-2 text-sm">
          <option value="nuevo">Nuevo</option><option value="leido">Leído</option><option value="resuelto">Resuelto</option>
        </select>
      </div>
      <p className="text-xs text-slate-500 mb-4">{new Date(m.creado_at).toLocaleString("es-MX")} · Aviso a tienda: {envio[m.notificacion]} · Acuse al cliente: {envio[m.confirmacion]}</p>
      <dl className="flex flex-col gap-3 text-sm">{CAMPOS_CONTACTO.filter(c => m.datos[c.id]).map(c => <div key={c.id}><dt className="font-semibold">{c.etiqueta}</dt><dd className="whitespace-pre-wrap break-words">{m.datos[c.id]}</dd></div>)}</dl>
      <a className="inline-block mt-4 text-sm underline" href={`mailto:${encodeURIComponent(m.datos.email || "")}?subject=${encodeURIComponent(`Re: Consulta #${m.id}`)}`}>Responder por correo</a>
    </article>)}
    <div className="flex items-center gap-4 text-sm"><button disabled={loading || saving !== null || pagina === 1} onClick={() => setPagina(p => p - 1)} className="disabled:opacity-40">Anterior</button><span>Página {pagina}</span><button disabled={loading || saving !== null || !hayMas} onClick={() => setPagina(p => p + 1)} className="disabled:opacity-40">Siguiente</button></div>
  </div>;
}
