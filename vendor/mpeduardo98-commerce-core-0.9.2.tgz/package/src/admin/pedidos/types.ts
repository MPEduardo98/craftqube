// features/admin/pedidos/types.ts
// Tipos y catálogos compartidos del módulo de pedidos admin
import type { PedidoEstado } from "../../orders/order";

/** Fila de la tabla de pedidos (proyección ligera del listado). */
export interface PedidoRow {
  id:              number;
  numero:          string;
  estado:          PedidoEstado;
  cliente:         string;
  email:           string;
  telefono:        string | null;
  total:           number;
  moneda:          string;
  metodo_pago:     string | null;
  paqueteria:      string | null;
  numero_guia:     string | null;
  envio_ciudad:    string;
  envio_estado:    string;
  total_items:     number;
  usuario_id:      number | null;
  pagado_en:       string | null;
  created_at:      string;
}

/** Ítem del pedido tal como lo devuelve el detalle. */
export interface PedidoItemRow {
  id:              number;
  variante_id:     number | null;
  titulo:          string;
  sku:             string;
  imagen_url:      string | null;
  precio_unitario: number;
  cantidad:        number;
  descuento_linea: number;
  total_linea:     number;
  producto_slug:   string | null;
}

/** Entrada del historial de estados. */
export interface PedidoHistorialRow {
  id:              number;
  estado_anterior: string | null;
  estado_nuevo:    string;
  comentario:      string | null;
  notificar:       number | boolean;
  created_at:      string;
}

/** Detalle completo del pedido para el modal. */
export interface PedidoDetalle {
  id:                number;
  numero:            string;
  estado:            PedidoEstado;
  usuario_id:        number | null;
  envio_nombre:      string;
  envio_empresa:     string | null;
  envio_telefono:    string | null;
  envio_calle:       string;
  envio_numero_ext:  string;
  envio_numero_int:  string | null;
  envio_colonia:     string;
  envio_ciudad:      string;
  envio_municipio:   string | null;
  envio_estado:      string;
  envio_cp:          string;
  envio_pais:        string;
  envio_referencias: string | null;
  email:             string;
  telefono:          string | null;
  subtotal:          number;
  descuento:         number;
  costo_envio:       number;
  impuestos:         number;
  total:             number;
  moneda:            string;
  cupon_codigo:      string | null;
  cupon_descuento:   number | null;
  metodo_pago:       string | null;
  referencia_pago:   string | null;
  pagado_en:         string | null;
  paqueteria:        string | null;
  numero_guia:       string | null;
  url_rastreo:       string | null;
  enviado_en:        string | null;
  entregado_en:      string | null;
  notas_cliente:     string | null;
  notas_internas:    string | null;
  fuente:            string;
  created_at:        string;
  updated_at:        string;
  items:             PedidoItemRow[];
  historial:         PedidoHistorialRow[];
}

/** Métricas del encabezado. */
export interface PedidosStats {
  total:          number;
  pendientes:     number;
  en_curso:       number;
  entregados:     number;
  ingresos_mes:   number;
}

/* ── Catálogo de estados ─────────────────────────────────────── */

export interface EstadoMeta {
  label: string;
  color: string;
  bg:    string;
}

/** Estados del pedido en el panel: neutros, y color sólo donde importa (pago, entrega, problema). */
export const ESTADOS: Record<PedidoEstado, EstadoMeta> = {
  pendiente_pago: { label: "Pendiente de pago", color: "#a16207", bg: "rgba(161,98,7,0.08)"  },
  pago_recibido:  { label: "Pago recibido",     color: "#15803d", bg: "rgba(21,128,61,0.08)" },
  en_proceso:     { label: "En proceso",        color: "#404040", bg: "rgba(10,10,10,0.05)"  },
  listo_envio:    { label: "Listo para envío",  color: "#404040", bg: "rgba(10,10,10,0.05)"  },
  enviado:        { label: "Enviado",           color: "#0a0a0a", bg: "rgba(10,10,10,0.07)"  },
  entregado:      { label: "Entregado",         color: "#15803d", bg: "rgba(21,128,61,0.08)" },
  cancelado:      { label: "Cancelado",         color: "#b91c1c", bg: "rgba(185,28,28,0.07)" },
  reembolsado:    { label: "Reembolsado",       color: "#737373", bg: "rgba(10,10,10,0.04)"  },
  disputa:        { label: "En disputa",        color: "#b91c1c", bg: "rgba(185,28,28,0.07)" },
};

export const ESTADO_ORDEN: PedidoEstado[] = [
  "pendiente_pago", "pago_recibido", "en_proceso", "listo_envio",
  "enviado", "entregado", "cancelado", "reembolsado", "disputa",
];

export function estadoMeta(estado: string): EstadoMeta {
  return ESTADOS[estado as PedidoEstado] ?? { label: estado, color: "#737373", bg: "rgba(10,10,10,0.04)" };
}

export const METODOS_PAGO: Record<string, string> = {
  tarjeta:        "Tarjeta",
  transferencia:  "Transferencia (SPEI)",
  oxxo:           "OXXO",
};

export function metodoPagoLabel(metodo: string | null): string {
  if (!metodo) return "—";
  return METODOS_PAGO[metodo] ?? metodo;
}

/** Paqueterías soportadas para la captura de guía. */
export const PAQUETERIAS = [
  "DHL", "FedEx", "Estafeta", "UPS", "Redpack", "Paquetexpress", "99 Minutos", "Correos de México",
];
