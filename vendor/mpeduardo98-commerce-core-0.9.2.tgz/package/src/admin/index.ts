// Panel de administracion. El mismo para todas las tiendas: la
// identidad (nombre, logo, colores) entra por props desde la
// configuracion de cada una, no esta escrita aqui.
export { AdminSidebar }    from "./components/AdminSidebar";
export { AdminTopbar }     from "./components/AdminTopbar";
export { AdminStatCards }  from "./components/AdminStatCards";

// Productos
export { ProductoForm }             from "./productos/components/ProductoForm";
export { ProductosTable }           from "./productos/components/ProductosTable";
export { ImportarProductosButton }  from "./productos/components/ImportarProductosButton";
export { crearProducto }            from "./productos/lib/crearProducto";

// Categorias, cupones y pedidos
export { CategoriasTable }      from "./categorias/components/CategoriasTable";
export { CrearCategoriaButton } from "./categorias/components/CrearCategoriaButton";
export { CuponesTable }         from "./cupones/components/CuponesTable";
export { CrearCuponButton }     from "./cupones/components/CrearCuponButton";
export { PedidosTable }         from "./pedidos/components/PedidosTable";

// Ajustes
export { GeneralSettings } from "./settings/components/GeneralSettings";
export { VentaSettings }   from "./settings/components/VentaSettings";
export { EnviosSettings }  from "./settings/components/EnviosSettings";
export { BienvenidaSettings } from "./settings/components/BienvenidaSettings";
export { SettingsSidebar } from "./settings/components/SettingsSidebar";
export { ContactoSettings } from "./settings/components/ContactoSettings";
