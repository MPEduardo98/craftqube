// shared/components/ui/Modal.tsx
// ─────────────────────────────────────────────────────────────
// Modal global reutilizable en todo el sitio.
//
// - Se renderiza vía portal sobre <body> (z-index alto).
// - Cierra con Escape, clic en el backdrop (configurable) y botón "×".
// - Bloquea el scroll del fondo mientras está abierto.
// - Estructura: cabecera (icono opcional + título + cerrar), cuerpo
//   (children) y pie opcional (footer).
//
// Ejemplo:
//   <Modal open={open} onClose={() => setOpen(false)} title="Nueva marca">
//     …contenido…
//   </Modal>
// ─────────────────────────────────────────────────────────────
"use client";

import { useEffect, useSyncExternalStore } from "react";
import { createPortal } from "react-dom";
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";

const suscribirNada = () => () => {};

interface ModalProps {
  open:             boolean;
  onClose:          () => void;
  title?:           string;
  icon?:            React.ReactNode;
  children:         React.ReactNode;
  footer?:          React.ReactNode;
  /** Ancho máximo del panel (px o cualquier valor CSS). Default 28rem. */
  maxWidth?:        number | string;
  /** Cerrar al hacer clic fuera del panel. Default true. */
  closeOnBackdrop?: boolean;
}

export function Modal({
  open,
  onClose,
  title,
  icon,
  children,
  footer,
  maxWidth = "28rem",
  closeOnBackdrop = true,
}: ModalProps) {
  // Escape para cerrar + bloqueo de scroll de fondo.
  useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", handler);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", handler);
      document.body.style.overflow = prevOverflow;
    };
  }, [open, onClose]);

  // document.body sólo existe en el navegador; false también durante
  // la hidratación para no chocar con lo que pintó el servidor.
  const montado = useSyncExternalStore(suscribirNada, () => true, () => false);
  const reducir = useReducedMotion();
  if (!montado) return null;

  return createPortal(
    <AnimatePresence>
      {open && (
    <motion.div
      key="fondo"
      className="fixed inset-0 z-[999] flex items-center justify-center p-4"
      style={{ background: "rgba(0,0,0,0.4)", backdropFilter: "blur(4px)" }}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.18 }}
      onClick={closeOnBackdrop ? onClose : undefined}
    >
      <motion.div
        className="w-full rounded-2xl flex flex-col gap-5 p-6"
        style={{
          maxWidth,
          background: "var(--color-cq-surface)",
          border:     "1px solid var(--color-cq-border)",
          boxShadow:  "0 24px 64px -12px rgba(0,0,0,0.25)",
        }}
        initial={reducir ? { opacity: 0 } : { opacity: 0, scale: 0.96, y: 8 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={reducir ? { opacity: 0 } : { opacity: 0, scale: 0.98, y: 4 }}
        transition={{ type: "spring", stiffness: 420, damping: 32, mass: 0.8 }}
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
      >
        {/* Cabecera */}
        {(title || icon) && (
          <div className="flex items-start gap-3">
            {icon}
            <h2
              className="flex-1"
              style={{
                fontFamily: "var(--font-display)",
                fontSize:   "1rem",
                fontWeight: 700,
                color:      "var(--color-cq-text)",
                margin:     0,
              }}
            >
              {title}
            </h2>
            <button
              type="button"
              onClick={onClose}
              aria-label="Cerrar"
              className="shrink-0 flex items-center justify-center rounded-lg transition-colors"
              style={{
                width:      "28px",
                height:     "28px",
                border:     "1px solid var(--color-cq-border)",
                background: "transparent",
                color:      "var(--color-cq-muted)",
                cursor:     "pointer",
              }}
            >
              ×
            </button>
          </div>
        )}

        {/* Cuerpo */}
        <div className="flex flex-col gap-4">{children}</div>

        {/* Pie */}
        {footer && (
          <div className="flex items-center gap-2 justify-end">{footer}</div>
        )}
      </motion.div>
    </motion.div>
      )}
    </AnimatePresence>,
    document.body
  );
}
