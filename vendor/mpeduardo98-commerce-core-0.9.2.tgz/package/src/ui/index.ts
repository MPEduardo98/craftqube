// Piezas de interfaz compartidas por el panel y la tienda.
// Son neutras: no traen marca ni diseno de ninguna tienda.
export { Modal }                from "./Modal";
export { Dropdown }             from "./Dropdown";
export type { DropdownOption }  from "./Dropdown";
export { Loader }               from "./Loader";
export { LoadingOverlay }       from "./LoadingOverlay";
export { ModalUnsavedChanges }  from "./ModalUnsavedChanges";
export { AlertContainer }       from "./AlertContainer";
export { BulkEditProvider, useBulkEdit, HideOnBulkEdit } from "./BulkEditContext";
