// scripts/build-css.mjs
// ─────────────────────────────────────────────────────────────
// Compila src/admin/estilos/panel.fuente.css → panel.css (el que
// carga el layout del admin) y encierra las variables para que sólo
// valgan mientras el panel está en pantalla:
//
//   :root, :host        → :root:has(.cc-admin)
//   :root               → :root:has(.cc-admin)
//   html[data-theme=…]  → html[data-theme=…]:has(.cc-admin)
//
// Correr después de tocar clases del panel:  npm run build:css
// panel.css se versiona: las tiendas no compilan nada.
// ─────────────────────────────────────────────────────────────
import { execFileSync } from "node:child_process";
import fs   from "node:fs";
import path from "node:path";
import url  from "node:url";

const ROOT   = path.resolve(path.dirname(url.fileURLToPath(import.meta.url)), "..");
const DIR    = path.join(ROOT, "src", "admin", "estilos");
const FUENTE = path.join(DIR, "panel.fuente.css");
const SALIDA = path.join(DIR, "panel.css");
const CLI    = path.join(ROOT, "node_modules", "@tailwindcss", "cli", "dist", "index.mjs");

execFileSync(process.execPath, [CLI, "-i", FUENTE, "-o", SALIDA, "--minify"], {
  cwd: ROOT, stdio: ["ignore", "ignore", "inherit"],
});

let css = fs.readFileSync(SALIDA, "utf8");
const antes = css.length;
css = css
  .replace(/:root,:host\{/g, ":root:has(.cc-admin){")
  .replace(/:root\{/g, ":root:has(.cc-admin){")
  .replace(/html\[data-theme=(["']?)dark\1\]\{/g, 'html[data-theme="dark"]:has(.cc-admin){');

// (`html,:host{` del reset de Tailwind no son variables: no cuentan)
const sueltos = css.match(/:root(?!:has)[^{]*\{/g);
if (sueltos) {
  console.error("✗ Quedaron variables sin encerrar:", sueltos.slice(0, 3));
  process.exit(1);
}

fs.writeFileSync(SALIDA,
  "/* Generado por scripts/build-css.mjs desde panel.fuente.css — no editar a mano. */\n" + css);
console.log(`✓ panel.css (${Math.round(css.length / 1024)} KB, antes de encerrar ${Math.round(antes / 1024)} KB)`);
