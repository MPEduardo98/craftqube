// scripts/migrar-db.mjs
// ─────────────────────────────────────────────────────────────
// Pone al día la base de una tienda que YA existe: aplica las
// migraciones de db/migrations que le falten, sin borrar nada.
// (`npx commerce-core db` es para tiendas nuevas: deja la base
// vacía y aplica el esquema completo.)
//
// Cada migración se aplica una vez; la tabla `migraciones` guarda
// cuáles ya corrieron. Si una falla, se detiene ahí y no la marca:
// al corregir el problema, se vuelve a correr y sigue desde esa.
//
// REGLA para escribir migraciones: deben ser re-ejecutables
// (IF NOT EXISTS, INSERT IGNORE…). Una tienda de antes de este
// comando no tiene la tabla `migraciones`, así que la primera vez
// corren todas, incluso las que ya se aplicaron a mano.
//
//   npx commerce-core migrar                 # usa .env.local
//   npx commerce-core migrar --env .env.luna
//   npx commerce-core migrar --dry-run       # sólo lista las pendientes
// ─────────────────────────────────────────────────────────────
import mysql from "mysql2/promise";
import fs    from "node:fs";
import path  from "node:path";
import {
  DIR_MIGRACIONES, readEnv, splitStatements,
  listarMigraciones, crearTablaMigraciones, marcarMigraciones,
} from "./db-comun.mjs";

const argv    = process.argv.slice(2);
const optVal  = (n, d) => { const i = argv.indexOf(n); return i >= 0 ? argv[i + 1] : d; };
const ENV_FILE = optVal("--env", ".env.local");
const DRY_RUN  = argv.includes("--dry-run");

const env = readEnv(ENV_FILE);
const { DB_HOST: host, DB_USER: user, DB_PASSWORD: password, DB_NAME: database } = env;
if (!host || !user || !database) {
  console.error("✗ Faltan DB_HOST / DB_USER / DB_NAME en " + ENV_FILE);
  process.exit(1);
}

const conn = await mysql.createConnection({
  host, user, password, database,
  port: Number(env.DB_PORT) || 3306,
  ssl: { rejectUnauthorized: false },
  multipleStatements: false,
  connectTimeout: 20_000,
});

await crearTablaMigraciones(conn);
const [filas] = await conn.query("SELECT nombre FROM `migraciones`");
const hechas = new Set(filas.map((f) => f.nombre));
const pendientes = listarMigraciones().filter((m) => !hechas.has(m));

console.log(`\n▸ Base '${database}' — ${pendientes.length} migración(es) pendiente(s)`);
if (!pendientes.length) {
  console.log("  ✓ Ya está al día");
  await conn.end();
  process.exit(0);
}

for (const nombre of pendientes) {
  if (DRY_RUN) { console.log(`  · ${nombre}`); continue; }
  const sentencias = splitStatements(fs.readFileSync(path.join(DIR_MIGRACIONES, nombre), "utf8"));
  try {
    for (const s of sentencias) await conn.query(s);
  } catch (err) {
    console.error(`\n✗ Falló ${nombre}:\n  ${err.message}`);
    console.error("  No se marcó como aplicada. Corrige el problema y vuelve a correr  npx commerce-core migrar");
    await conn.end();
    process.exit(1);
  }
  await marcarMigraciones(conn, [nombre]);
  console.log(`  ✓ ${nombre}`);
}

if (DRY_RUN) console.log("  [dry-run] no se aplicó nada");
await conn.end();
