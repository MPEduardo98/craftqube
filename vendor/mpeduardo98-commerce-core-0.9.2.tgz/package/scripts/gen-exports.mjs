// scripts/gen-exports.mjs
// ─────────────────────────────────────────────────────────────
// Regenera el campo "exports" del package.json a partir de los
// archivos que hay en src/.
//
// Existe porque Turbopack no resuelve un comodín con varios
// candidatos (se queda con el primero, así que un .ts declarado
// como .tsx falla). Cada archivo tiene que aparecer con su
// extensión real, y mantener esa lista a mano se rompe en cuanto
// se agrega un archivo.
//
//   npm run gen:exports
// ─────────────────────────────────────────────────────────────
import fs   from "node:fs";
import path from "node:path";
import url  from "node:url";

const ROOT = path.resolve(path.dirname(url.fileURLToPath(import.meta.url)), "..");
const SRC  = path.join(ROOT, "src");

/** Carpetas cuyo index.ts se expone con nombre corto (./ui, ./db, …). */
const ATAJOS = {
  ui:       "./ui",
  context:  "./context",
  lib:      "./lib",
  db:       "./db",
  types:    "./types",
  hooks:    "./hooks",
  data:     "./data",
  config:   "./config",
  currency: "./currency",
  media:    "./media",
  admin:    "./admin",
  orders:   "./orders",
  cart:     "./cart",
  stripe:   "./stripe",
  auth:     "./auth",
  email:    "./email",
  catalogo: "./catalogo",
  resenas:  "./resenas",
  seo:      "./seo",
  bienvenida: "./bienvenida",
  venta:    "./venta",
  contacto: "./contacto",
};

function walk(dir, base, out = []) {
  if (!fs.existsSync(dir)) return out;
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, e.name);
    if (e.isDirectory()) walk(full, base, out);
    else if (/\.tsx?$/.test(e.name)) {
      out.push(path.relative(base, full).split(path.sep).join("/"));
    }
  }
  return out;
}

const exportsMap = {
  ".": "./src/index.ts",
  "./package.json": "./package.json",
};

// Atajos por carpeta, cuando tienen index.
for (const [carpeta, alias] of Object.entries(ATAJOS)) {
  const index = path.join(SRC, carpeta, "index.ts");
  if (fs.existsSync(index)) exportsMap[alias] = `./src/${carpeta}/index.ts`;
}

// Cada archivo por su ruta, con la extensión que realmente tiene.
// Se recorren TODAS las carpetas de src/, tengan atajo o no: una
// carpeta sin index.ts igual necesita que sus archivos se resuelvan.
const CARPETAS = fs.readdirSync(SRC, { withFileTypes: true })
  .filter((e) => e.isDirectory())
  .map((e) => e.name);

for (const carpeta of CARPETAS) {
  const dir = path.join(SRC, carpeta);
  for (const rel of walk(dir, dir)) {
    const sinExt = rel.replace(/\.tsx?$/, "");
    if (sinExt === "index") continue;
    exportsMap[`./${carpeta}/${sinExt}`] = `./src/${carpeta}/${rel}`;
  }
}

const pkgPath = path.join(ROOT, "package.json");
const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf8"));
pkg.exports = exportsMap;
fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2) + "\n", "utf8");

console.log(`exports regenerado: ${Object.keys(exportsMap).length} entradas`);
