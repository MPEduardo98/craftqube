import assert from "node:assert/strict";
import fs from "node:fs";
import ts from "typescript";
import vm from "node:vm";
function load(file, globals = {}) {
  const source = ts.transpileModule(fs.readFileSync(file, "utf8"), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
  const context = { exports: {}, ...globals }; vm.runInNewContext(source, context); return context.exports;
}
const { validarEvento } = load("src/analytics/events.ts");
const base = { id: "12345678-1234-4234-8234-123456789012", session: "12345678-1234-4234-8234-123456789013", event: "page_view", target: "home" };
assert.ok(validarEvento(base));
for (const patch of [{ id: "bad" }, { event: "purchase" }, { target: "email@example.com" }, { target: "/?token=secret" }, { event: "add_to_cart", productId: 1, quantity: -1 }, { event: "product_view", productId: 1.5 }, { event: "demographics", age: "unknown" }]) assert.equal(validarEvento({ ...base, ...patch }), null);
assert.equal(validarEvento(null), null);
assert.equal(validarEvento({ ...base, email: "private" }).email, undefined);
assert.ok(validarEvento({ ...base, event: "add_to_cart", productId: 10, quantity: 2 }));
assert.ok(validarEvento({ ...base, event: "demographics", age: "25-34" }));
const storage = () => { const map = new Map(); return { getItem: k => map.get(k) ?? null, setItem: (k,v) => map.set(k,v), removeItem: k => map.delete(k) }; };
const requests = [];
const localStorage = storage(); const sessionStorage = storage();
const navigator = { doNotTrack: "0" }; const location = { pathname: "/" };
const client = load("src/analytics/client.ts", { localStorage, sessionStorage, navigator, location, crypto: { randomUUID: () => base.id }, window: { dispatchEvent() {} }, Event: class {}, fetch: (...args) => { requests.push(args); return Promise.resolve(); } });
client.track("page_view", { target: "home" }); assert.equal(requests.length, 0);
client.setAnalyticsConsent(true); client.track("page_view", { target: "home" }); assert.equal(requests.length, 1);
location.pathname = "/admin"; client.track("click", { target: "test" }); assert.equal(requests.length, 1);
location.pathname = "/"; navigator.doNotTrack = "1"; client.track("click", { target: "test" }); assert.equal(requests.length, 1);
navigator.doNotTrack = "0"; client.setAnalyticsConsent(false); client.track("click", { target: "test" }); assert.equal(requests.length, 1);
assert.equal(sessionStorage.getItem("cc-analytics-session"), null);
console.log("Analytics validation, consent, DNT, admin exclusion and revocation: OK");
