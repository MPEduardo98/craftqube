// scripts/db-comun.mjs
// ─────────────────────────────────────────────────────────────
// Piezas que comparten `db` (init-store-db.mjs) y `migrar`
// (migrar-db.mjs): leer el .env de la tienda, partir un .sql en
// sentencias y llevar la cuenta de las migraciones aplicadas.
// ─────────────────────────────────────────────────────────────
import fs   from "node:fs";
import path from "node:path";
import url  from "node:url";

// ROOT: el paquete del núcleo (de ahí salen los .sql).
export const ROOT = path.resolve(path.dirname(url.fileURLToPath(import.meta.url)), "..");
export const DIR_MIGRACIONES = path.join(ROOT, "db", "migrations");

export function readEnv(file, cwd = process.cwd()) {
  const full = path.resolve(cwd, file);
  if (!fs.existsSync(full)) {
    console.error(`✗ No existe ${file}`);
    process.exit(1);
  }
  return Object.fromEntries(
    fs.readFileSync(full, "utf8")
      .split(/\r?\n/)
      .filter((l) => /^\s*[A-Z_][A-Z_0-9]*\s*=/.test(l))
      .map((l) => {
        const i = l.indexOf("=");
        return [l.slice(0, i).trim(), l.slice(i + 1).trim().replace(/^["']|["']$/g, "")];
      })
  );
}

// Parte un .sql en sentencias. El esquema sólo trae DDL con `;`
// al final de cada statement, sin procedimientos ni delimitadores
// personalizados, así que basta con respetar comillas y comentarios.
export function splitStatements(sql) {
  const out = [];
  let buf = "", quote = null, lineComment = false, blockComment = false;

  for (let i = 0; i < sql.length; i++) {
    const c = sql[i], next = sql[i + 1];

    if (lineComment) { if (c === "\n") { lineComment = false; buf += c; } continue; }
    if (blockComment) { if (c === "*" && next === "/") { blockComment = false; i++; } continue; }

    if (!quote) {
      if (c === "-" && next === "-") { lineComment = true; continue; }
      if (c === "#")                 { lineComment = true; continue; }
      if (c === "/" && next === "*") { blockComment = true; i++; continue; }
    }

    if (quote) {
      if (c === "\\") { buf += c + (next ?? ""); i++; continue; }  // escape
      if (c === quote) quote = null;
    } else if (c === "'" || c === '"' || c === "`") {
      quote = c;
    }

    if (c === ";" && !quote) { if (buf.trim()) out.push(buf.trim()); buf = ""; continue; }
    buf += c;
  }
  if (buf.trim()) out.push(buf.trim());
  return out;
}

// ── Migraciones ──────────────────────────────────────────────
// Cada archivo de db/migrations se aplica una sola vez por base;
// la tabla `migraciones` recuerda cuáles ya se aplicaron. El orden
// es el alfabético del nombre (empiezan con la fecha).

/** Nombres de los archivos de migración, en orden. */
export function listarMigraciones() {
  if (!fs.existsSync(DIR_MIGRACIONES)) return [];
  return fs.readdirSync(DIR_MIGRACIONES).filter((f) => f.endsWith(".sql")).sort();
}

export async function crearTablaMigraciones(conn) {
  await conn.query(`
    CREATE TABLE IF NOT EXISTS \`migraciones\` (
      \`nombre\` varchar(200) NOT NULL,
      \`aplicada_en\` timestamp NOT NULL DEFAULT current_timestamp(),
      PRIMARY KEY (\`nombre\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
      COMMENT='Migraciones de db/migrations ya aplicadas (npx commerce-core migrar)'`);
}

export async function marcarMigraciones(conn, nombres) {
  for (const n of nombres) {
    await conn.query("INSERT IGNORE INTO `migraciones` (nombre) VALUES (?)", [n]);
  }
}
