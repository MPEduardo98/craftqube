// scripts/init-store-db.mjs
// ─────────────────────────────────────────────────────────────
// Prepara la base de datos de una tienda: aplica db/schema.sql
// y, si se pide, db/seed.sql.
//
// Existe porque el esquema son 42 tablas con 41 llaves foráneas:
// crearlas a mano para cada tienda nueva es lento y se presta a
// olvidar un índice que luego falla en producción.
//
// No usa el cliente `mysql` del sistema — habla por mysql2, que
// ya es dependencia del proyecto.
//
//   npx commerce-core db                 # usa .env.local de la tienda
//   npx commerce-core db --env .env.luna # otro archivo de entorno
//   npx commerce-core db --no-seed       # sólo esquema
//   npx commerce-core db --dry-run       # sin escribir
// ─────────────────────────────────────────────────────────────
import mysql from "mysql2/promise";
import fs    from "node:fs";
import path  from "node:path";
import readline from "node:readline/promises";
import {
  ROOT, readEnv, splitStatements,
  listarMigraciones, crearTablaMigraciones, marcarMigraciones,
} from "./db-comun.mjs";

// ── Argumentos ───────────────────────────────────────────────
const argv    = process.argv.slice(2);
const flag    = (n) => argv.includes(n);
const optVal  = (n, d) => { const i = argv.indexOf(n); return i >= 0 ? argv[i + 1] : d; };

const ENV_FILE = optVal("--env", ".env.local");
const WITH_SEED = !flag("--no-seed");
const DRY_RUN   = flag("--dry-run");
const FORCE     = flag("--force");

async function runFile(conn, file, label) {
  const full = path.join(ROOT, file);
  if (!fs.existsSync(full)) {
    console.error(`✗ No existe ${file}`);
    process.exit(1);
  }
  const statements = splitStatements(fs.readFileSync(full, "utf8"));
  console.log(`\n▸ ${label} (${statements.length} sentencias)`);

  if (DRY_RUN) { console.log("  [dry-run] no se ejecuta nada"); return; }

  let n = 0;
  for (const stmt of statements) {
    try {
      await conn.query(stmt);
      n++;
    } catch (err) {
      console.error(`\n✗ Falló la sentencia ${n + 1}:`);
      console.error(stmt.slice(0, 200));
      console.error(`  ${err.message}`);
      process.exit(1);
    }
  }
  console.log(`  ✓ ${n} sentencias aplicadas`);
}

// ── Main ─────────────────────────────────────────────────────
const env = readEnv(ENV_FILE);
const { DB_HOST: host, DB_USER: user, DB_PASSWORD: password, DB_NAME: database } = env;
const port = Number(env.DB_PORT) || 3306;

if (!host || !user || !database) {
  console.error("✗ Faltan DB_HOST / DB_USER / DB_NAME en " + ENV_FILE);
  process.exit(1);
}

console.log("─".repeat(58));
console.log(`  Inicializar tienda`);
console.log("─".repeat(58));
console.log(`  env      ${ENV_FILE}`);
console.log(`  host     ${host}:${port}`);
console.log(`  base     ${database}`);
console.log(`  semilla  ${WITH_SEED ? "sí" : "no"}`);
if (DRY_RUN) console.log(`  modo     DRY RUN (no escribe)`);
console.log("─".repeat(58));

// La instalación deja la base LIMPIA: borra todas sus tablas y
// vistas (también las que no son del núcleo, p. ej. restos de otra
// versión) y aplica el esquema. Por eso se confirma salvo --force
// o --dry-run.
const conn = await mysql.createConnection({
  host, user, password, database, port,
  ssl: { rejectUnauthorized: false },
  multipleStatements: false,
  connectTimeout: 20_000,
});

const [tablas] = await conn.query(
  "SELECT COUNT(*) AS n FROM information_schema.TABLES WHERE TABLE_SCHEMA = ?",
  [database]
);
const existentes = tablas[0].n;

if (existentes > 0 && !FORCE && !DRY_RUN) {
  console.log(`\n⚠  La base '${database}' ya tiene ${existentes} tablas.`);
  console.log(`   Instalar BORRA TODAS las tablas con sus datos y deja la base limpia.`);
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  const ans = await rl.question(`   Escribe el nombre de la base para confirmar: `);
  rl.close();
  if (ans.trim() !== database) {
    console.log("   Cancelado. No se tocó nada.");
    await conn.end();
    process.exit(0);
  }
}

// ── Limpieza total ───────────────────────────────────────────
const [objetos] = await conn.query(
  "SELECT TABLE_NAME AS n, TABLE_TYPE AS t FROM information_schema.TABLES WHERE TABLE_SCHEMA = ?",
  [database]
);
if (objetos.length) {
  console.log(`\n▸ Limpieza (${objetos.length} tablas/vistas)`);
  if (DRY_RUN) {
    console.log("  [dry-run] no se borra nada");
  } else {
    await conn.query("SET FOREIGN_KEY_CHECKS = 0");
    for (const { n, t } of objetos) {
      await conn.query(`DROP ${t === "VIEW" ? "VIEW" : "TABLE"} IF EXISTS \`${n}\``);
    }
    await conn.query("SET FOREIGN_KEY_CHECKS = 1");
    console.log(`  ✓ ${objetos.length} borradas`);
  }
}

await runFile(conn, "db/schema.sql", "Esquema");
if (WITH_SEED) await runFile(conn, "db/seed.sql", "Datos semilla");

// El esquema ya trae todo lo de db/migrations: se registran como
// aplicadas para que `npx commerce-core migrar` no las repita.
if (!DRY_RUN) {
  await crearTablaMigraciones(conn);
  await marcarMigraciones(conn, listarMigraciones());
}

const [final] = await conn.query(
  "SELECT COUNT(*) AS n FROM information_schema.TABLES WHERE TABLE_SCHEMA = ?",
  [database]
);

console.log("\n" + "─".repeat(58));
console.log(`  ✓ Listo — ${final[0].n} tablas en '${database}'`);
console.log("─".repeat(58));
if (!DRY_RUN && WITH_SEED) {
  console.log(`\n  Admin por defecto:  admin@tienda.com  /  admin123`);
  console.log(`  Cámbiale la contraseña antes de publicar la tienda.`);
}
await conn.end();
