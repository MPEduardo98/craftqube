-- ─────────────────────────────────────────────────────────────
-- Envío a precio fijo por paquetería.
--
-- Además del cálculo dinámico (guías por peso/volumen + flete), la
-- tienda puede cobrar un precio fijo por paquetería y por zona, y el
-- cliente elige la paquetería en el checkout. La tienda escoge UN
-- modo en Ajustes → Envíos (`envio_modo`).
--
--   paqueterias         → nombre, logo, días estimados, orden.
--   paqueteria_precios  → precio de cada paquetería en cada zona.
--                         Sin fila = esa paquetería no llega ahí.
--
-- `envio_gratis_desde`: subtotal a partir del cual el envío es $0
-- (en ambos modos). Vacío = sin envío gratis.
--
-- Re-ejecutable: IF NOT EXISTS / INSERT IGNORE.
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `paqueterias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(80) NOT NULL,
  `logo_url` varchar(500) DEFAULT NULL,
  `dias_min` int(11) DEFAULT NULL,
  `dias_max` int(11) DEFAULT NULL,
  `activa` tinyint(1) NOT NULL DEFAULT 1,
  `orden` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `paqueteria_precios` (
  `paqueteria_id` int(11) NOT NULL,
  `zona_id` int(11) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  PRIMARY KEY (`paqueteria_id`, `zona_id`),
  KEY `idx_zona` (`zona_id`),
  CONSTRAINT `fk_pp_paqueteria` FOREIGN KEY (`paqueteria_id`) REFERENCES `paqueterias` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pp_zona` FOREIGN KEY (`zona_id`) REFERENCES `zonas_envio` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `configuracion` (`clave`, `valor`) VALUES
  ('envio_modo',         'dinamico'),
  ('envio_gratis_desde', '');
