CREATE TABLE IF NOT EXISTS analytics_events (
  id CHAR(36) NOT NULL PRIMARY KEY,
  session_id CHAR(36) NOT NULL,
  event VARCHAR(32) NOT NULL,
  product_id INT NULL,
  quantity SMALLINT UNSIGNED NULL,
  target VARCHAR(80) NULL,
  country CHAR(2) NULL,
  age_range VARCHAR(12) NULL,
  gender VARCHAR(24) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_analytics_date (created_at, event),
  KEY idx_analytics_session (session_id, event, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
