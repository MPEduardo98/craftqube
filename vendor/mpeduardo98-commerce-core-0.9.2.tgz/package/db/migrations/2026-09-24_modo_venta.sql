-- ─────────────────────────────────────────────────────────────
-- Modo de venta: la tienda puede funcionar sólo como catálogo
-- (mostrar productos, sin carrito ni cobro).
--
-- Ajustes (Ajustes → Modo de venta):
--   venta_modo             → 'tienda' / 'catalogo'. En catálogo las
--                            APIs de checkout, envío y cupones
--                            responden 403 (codigo: modo_catalogo).
--   venta_mostrar_precios  → '1' / '0'. Sólo aplica en catálogo.
--   venta_whatsapp         → número con lada de país, sólo dígitos.
--                            Vacío = sin botón de WhatsApp.
--   venta_mensaje_whatsapp → mensaje prellenado; {producto} y {url}.
--
-- Re-ejecutable: INSERT IGNORE. Sin la clave, el núcleo asume
-- 'tienda', así que las tiendas existentes siguen vendiendo igual.
-- ─────────────────────────────────────────────────────────────
INSERT IGNORE INTO `configuracion` (`clave`, `valor`) VALUES
  ('venta_modo',             'tienda'),
  ('venta_mostrar_precios',  '1'),
  ('venta_whatsapp',         ''),
  ('venta_mensaje_whatsapp', 'Hola, me interesa {producto} {url}');
