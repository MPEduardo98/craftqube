-- ─────────────────────────────────────────────────────────────
-- Modal de bienvenida: el visitante deja nombre y correo y recibe
-- por correo el cupón que la tienda eligió.
--
--   suscriptores        → clientes potenciales captados (un correo,
--                         una fila). `cupon_id` es el cupón que se le
--                         envió; `acepta_marketing` permite exportar
--                         sólo a quien aceptó recibir promociones.
--
-- Ajustes (Ajustes → Bienvenida):
--   bienvenida_activa    → '1' / '0'. Apagado, la tienda no muestra
--                          el modal y la API no acepta registros.
--   bienvenida_cupon_id  → id del cupón que se envía. Ese cupón sólo
--                          lo puede usar un correo suscrito.
--
-- Re-ejecutable: IF NOT EXISTS / INSERT IGNORE.
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `suscriptores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(180) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `origen` varchar(40) NOT NULL DEFAULT 'bienvenida',
  `cupon_id` int(11) DEFAULT NULL,
  `acepta_marketing` tinyint(1) NOT NULL DEFAULT 1,
  `ultimo_envio_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_email` (`email`),
  KEY `idx_created` (`created_at`),
  CONSTRAINT `fk_susc_cupon` FOREIGN KEY (`cupon_id`) REFERENCES `cupones` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Clientes potenciales del modal de bienvenida';

INSERT IGNORE INTO `configuracion` (`clave`, `valor`) VALUES
  ('bienvenida_activa',   '0'),
  ('bienvenida_cupon_id', '');
