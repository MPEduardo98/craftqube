-- ─────────────────────────────────────────────────────────────
-- Reseñas de productos con compra verificada.
--
-- La tabla `reseñas` ya venía en el esquema; esto le agrega lo que
-- necesita el sistema:
--
--   imagenes            → hasta 3 fotos del cliente (JSON con URLs).
--   uq_producto_usuario → una reseña por cliente por producto.
--
-- Ajustes (Ajustes → Reseñas):
--   resenas_activas     → '1' / '0'. Apagado, ni se muestran ni se
--                         aceptan reseñas nuevas.
--   resenas_moderacion  → 'auto': se publican al enviarse.
--                         'manual': quedan pendientes hasta aprobarlas.
--
-- Re-ejecutable: IF NOT EXISTS / INSERT IGNORE.
-- ─────────────────────────────────────────────────────────────
ALTER TABLE `reseñas`
  ADD COLUMN IF NOT EXISTS `imagenes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
    COMMENT '["https://cdn…/resenas/…webp"] (máx. 3)' CHECK (json_valid(`imagenes`)) AFTER `cuerpo`,
  ADD UNIQUE KEY IF NOT EXISTS `uq_producto_usuario` (`producto_id`, `usuario_id`);

INSERT IGNORE INTO `configuracion` (`clave`, `valor`) VALUES
  ('resenas_activas',    '0'),
  ('resenas_moderacion', 'auto');
