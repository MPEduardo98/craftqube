CREATE TABLE IF NOT EXISTS contacto_mensajes (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  datos JSON NOT NULL,
  estado ENUM('nuevo','leido','resuelto') NOT NULL DEFAULT 'nuevo',
  notificacion ENUM('pendiente','enviada','error') NOT NULL DEFAULT 'pendiente',
  confirmacion ENUM('pendiente','enviada','error') NOT NULL DEFAULT 'pendiente',
  creado_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
