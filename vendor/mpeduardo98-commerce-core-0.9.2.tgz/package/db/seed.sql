-- ============================================================
-- Datos semilla para una tienda nueva
--
-- Se ejecuta DESPUÉS de db/schema.sql. Deja la tienda en un
-- estado mínimo operable: identidad genérica, moneda y límites
-- de envío por defecto. Todo esto se edita luego desde
-- /admin/ajustes — aquí sólo se garantiza que ninguna consulta
-- se encuentre con la tabla vacía.
--
-- Incluye un administrador por defecto (ver abajo). NO contiene
-- productos, categorías ni clientes: eso lo carga
-- cada tienda por su cuenta.
--
--   mysql -u USUARIO -p NOMBRE_BD < db/seed.sql
-- ============================================================

SET NAMES utf8mb4;

-- ------------------------------------------------------------
-- Configuración base (clave/valor)
--
-- INSERT IGNORE: si la clave ya existe no se pisa. Esto hace el
-- archivo re-ejecutable sobre una tienda ya configurada sin
-- borrarle sus ajustes.
-- ------------------------------------------------------------
INSERT IGNORE INTO `configuracion` (`clave`, `valor`) VALUES
  -- ── Identidad ────────────────────────────────────────────
  ('tienda_nombre',        'Mi Tienda'),
  ('tienda_descripcion',   ''),
  ('tienda_logo_url',      ''),
  ('tienda_favicon_url',   ''),
  ('tienda_email',         ''),
  ('tienda_telefono',      ''),

  -- ── Tema del panel (se inyectan como variables CSS) ──────
  ('tema_color_primario',  '#1238a0'),
  ('tema_color_acento',    '#2563EB'),

  -- ── Moneda ───────────────────────────────────────────────
  -- moneda_captura: en la que el admin escribe los precios.
  -- moneda_tienda:  en la que se cobra y se muestra.
  -- Iguales por defecto = sin conversión, el caso simple.
  ('moneda_captura',       'MXN'),
  ('moneda_tienda',        'MXN'),

  -- ── Modo de venta ────────────────────────────────────────
  -- tienda:   carrito y cobro en línea.
  -- catalogo: sólo mostrar productos; se pide informes por WhatsApp.
  ('venta_modo',             'tienda'),
  -- Sólo en catálogo: '0' oculta los precios.
  ('venta_mostrar_precios',  '1'),
  -- Con lada de país, sólo dígitos. Vacío = sin botón de WhatsApp.
  ('venta_whatsapp',         ''),
  ('venta_mensaje_whatsapp', 'Hola, me interesa {producto} {url}'),

  -- ── Límites de paquetería ────────────────────────────────
  -- Topes por paquete usados al cotizar envío.
  ('envio_peso_max_kg',    '20'),
  ('envio_volumen_max_m3', '0.125'),
  ('envio_dim_max_cm',     '100'),

  -- ── Modo de envío ────────────────────────────────────────
  -- dinamico: guías por peso/volumen + flete, por zona.
  -- fijo:     el cliente elige paquetería; precio fijo por zona.
  ('envio_modo',           'dinamico'),
  -- Subtotal desde el que el envío sale gratis. Vacío = nunca.
  ('envio_gratis_desde',   ''),

  -- ── Reseñas ──────────────────────────────────────────────
  -- Apagadas hasta que la tienda las active en Ajustes → Reseñas.
  ('resenas_activas',      '0'),
  -- auto: se publican al enviarse. manual: esperan aprobación.
  ('resenas_moderacion',   'auto'),

  -- ── Modal de bienvenida ──────────────────────────────────
  -- Apagado hasta que la tienda elija un cupón en Ajustes → Bienvenida.
  ('bienvenida_activa',    '0'),
  ('bienvenida_cupon_id',  '');

-- ------------------------------------------------------------
-- Administrador por defecto
--
--   Correo:      admin@tienda.com
--   Contraseña:  admin123
--
-- Para poder entrar al panel en cuanto la tienda tenga su /login.
-- CAMBIAR la contraseña antes de publicar la tienda.
--
-- La contraseña va cifrada como la guarda Better Auth (scrypt), en
-- la cuenta "credential" de la tabla account. Re-ejecutable: si el
-- correo ya existe no se toca.
-- ------------------------------------------------------------
INSERT IGNORE INTO `usuarios`
  (`email`, `nombre`, `apellido`, `name`, `rol`, `estado`, `email_verificado`)
VALUES
  ('admin@tienda.com', 'Admin', 'Tienda', 'Admin Tienda', 'admin', 'activo', 1);

INSERT INTO `account` (`accountId`, `providerId`, `userId`, `password`, `createdAt`, `updatedAt`)
SELECT CAST(u.`id` AS CHAR), 'credential', u.`id`,
       'd7a02cf3e9d89510bf64a68f2500b6bf:94b3f2823af0e5982c13a8e6e2cf4024700b64cb5607112ca664a5c0eaa81b0ac64bd75e48354c752f9a8eb47d3ea03c6226f7d9d4ab7a794b16921570ad4f1b',
       NOW(3), NOW(3)
FROM `usuarios` u
WHERE u.`email` = 'admin@tienda.com'
  AND NOT EXISTS (
    SELECT 1 FROM `account` a WHERE a.`userId` = u.`id` AND a.`providerId` = 'credential'
  );
