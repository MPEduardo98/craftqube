export const CAMPOS_CONTACTO = [
  { id: "nombre", etiqueta: "Nombre", tipo: "text", max: 120 },
  { id: "email", etiqueta: "Correo electrónico", tipo: "email", max: 254 },
  { id: "telefono", etiqueta: "Teléfono", tipo: "tel", max: 40 },
  { id: "empresa", etiqueta: "Empresa", tipo: "text", max: 160 },
  { id: "pedido", etiqueta: "Número de pedido", tipo: "text", max: 80 },
  { id: "asunto", etiqueta: "Asunto", tipo: "text", max: 200 },
  { id: "mensaje", etiqueta: "Mensaje", tipo: "textarea", max: 5000 },
] as const;
export type CampoContacto = typeof CAMPOS_CONTACTO[number]["id"];
export type ReglaCampo = "oculto" | "opcional" | "obligatorio";
export const TIPOS_CAMPO_CONTACTO = [
  { id: "text", etiqueta: "Texto corto" },
  { id: "textarea", etiqueta: "Texto largo" },
  { id: "email", etiqueta: "Correo electrónico" },
  { id: "tel", etiqueta: "Teléfono" },
  { id: "number", etiqueta: "Número" },
  { id: "date", etiqueta: "Fecha" },
  { id: "select", etiqueta: "Lista desplegable" },
  { id: "radio", etiqueta: "Una opción" },
  { id: "checkbox", etiqueta: "Varias opciones" },
] as const;
export type TipoCampoContacto = typeof TIPOS_CAMPO_CONTACTO[number]["id"];
export interface CampoFormularioContacto {
  id: string;
  etiqueta: string;
  tipo: TipoCampoContacto;
  obligatorio: boolean;
  placeholder: string;
  ayuda: string;
  opciones: string[];
  max: number;
}
export const esCampoOpciones = (tipo: TipoCampoContacto) => tipo === "select" || tipo === "radio" || tipo === "checkbox";
export interface ContactoPublico {
  activo: boolean;
  titulo: string;
  descripcion: string;
  campos: Record<CampoContacto, ReglaCampo>;
  /** Ausente en configuraciones antiguas; se convierte sin perder las reglas existentes. */
  formulario?: CampoFormularioContacto[];
}
export function obtenerCamposContacto(config: Pick<ContactoPublico, "campos" | "formulario">): CampoFormularioContacto[] {
  return config.formulario ?? CAMPOS_CONTACTO.filter(c => config.campos[c.id] !== "oculto").map(c => ({
    ...c, obligatorio: config.campos[c.id] === "obligatorio", placeholder: "", ayuda: "", opciones: [],
  }));
}
export interface ContactoConfig extends ContactoPublico { destinatario: string }
export const CONTACTO_DEFAULT: ContactoConfig = {
  activo: false, titulo: "Contáctanos", descripcion: "Envíanos tu consulta y nos pondremos en contacto contigo.", destinatario: "",
  campos: { nombre: "obligatorio", email: "obligatorio", telefono: "opcional", empresa: "oculto", pedido: "oculto", asunto: "opcional", mensaje: "obligatorio" },
};
export interface MensajeContacto {
  id: number;
  datos: Record<string, string>;
  campos?: { id: string; etiqueta: string }[];
  estado: "nuevo" | "leido" | "resuelto";
  notificacion: "pendiente" | "enviada" | "error";
  confirmacion: "pendiente" | "enviada" | "error";
  creado_at: string;
}
