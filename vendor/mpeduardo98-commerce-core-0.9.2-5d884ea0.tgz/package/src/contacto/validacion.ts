import { CAMPOS_CONTACTO, TIPOS_CAMPO_CONTACTO, esCampoOpciones, obtenerCamposContacto, type ContactoConfig, type CampoFormularioContacto } from "./types";

export class ErrorContacto extends Error {}
export function objeto(v: unknown): Record<string, unknown> {
  if (!v || typeof v !== "object" || Array.isArray(v)) throw new ErrorContacto("Datos inválidos.");
  return v as Record<string, unknown>;
}
export function emailValido(v: string): boolean {
  return v.length <= 254 && /^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(v);
}
export function validarConfig(v: unknown): ContactoConfig {
  const b = objeto(v);
  if (typeof b.activo !== "boolean") throw new ErrorContacto("Estado inválido.");
  for (const [key, max] of [["titulo", 120], ["descripcion", 600], ["destinatario", 254]] as const) {
    if (typeof b[key] !== "string" || b[key].length > max) throw new ErrorContacto(`Revisa ${key}.`);
  }
  const titulo = (b.titulo as string).trim();
  const destinatario = (b.destinatario as string).trim();
  if (!titulo) throw new ErrorContacto("Escribe un título.");
  if ((b.activo || destinatario) && !emailValido(destinatario)) throw new ErrorContacto("Escribe un correo de recepción válido.");
  const reglas = objeto(b.campos);
  const campos = {} as ContactoConfig["campos"];
  for (const { id } of CAMPOS_CONTACTO) {
    const regla = reglas[id];
    if (regla !== "oculto" && regla !== "opcional" && regla !== "obligatorio") throw new ErrorContacto(`Revisa el campo ${id}.`);
    campos[id] = regla;
  }
  let formulario: CampoFormularioContacto[] | undefined;
  if (b.formulario !== undefined) {
    if (!Array.isArray(b.formulario) || b.formulario.length < 1 || b.formulario.length > 30) throw new ErrorContacto("Agrega entre 1 y 30 campos al formulario.");
    const ids = new Set<string>();
    formulario = b.formulario.map(v => {
      const c = objeto(v);
      if (typeof c.id !== "string" || !/^[a-z][a-z0-9_]{0,63}$/.test(c.id) || ["website", "__proto__", "constructor", "prototype"].includes(c.id) || ids.has(c.id)) throw new ErrorContacto("Identificador de campo inválido o repetido.");
      ids.add(c.id);
      for (const [key, max] of [["etiqueta", 120], ["placeholder", 200], ["ayuda", 400]] as const) {
        if (typeof c[key] !== "string" || c[key].length > max || /[\u0000-\u001f]/.test(c[key])) throw new ErrorContacto(`Revisa ${key} del campo.`);
      }
      if (!(c.etiqueta as string).trim() || typeof c.obligatorio !== "boolean" || !TIPOS_CAMPO_CONTACTO.some(t => t.id === c.tipo) || !Number.isInteger(c.max) || (c.max as number) < 1 || (c.max as number) > 5000) throw new ErrorContacto("Revisa el tipo, título y límite del campo.");
      const tipo = c.tipo as CampoFormularioContacto["tipo"];
      let opciones: string[] = [];
      if (esCampoOpciones(tipo)) {
        if (!Array.isArray(c.opciones) || c.opciones.length < 1 || c.opciones.length > 30 || c.opciones.some(o => typeof o !== "string" || !o.trim() || o.length > 160 || /[\u0000-\u001f]/.test(o))) throw new ErrorContacto("Agrega entre 1 y 30 opciones, de hasta 160 caracteres cada una.");
        opciones = c.opciones.map((o: string) => o.trim());
        if (new Set(opciones).size !== opciones.length) throw new ErrorContacto("Las opciones no pueden repetirse.");
      }
      return { id: c.id, etiqueta: (c.etiqueta as string).trim(), tipo, obligatorio: c.obligatorio, placeholder: (c.placeholder as string).trim(), ayuda: (c.ayuda as string).trim(), opciones, max: c.max as number };
    });
    if (!formulario.some(c => c.id === "email" && c.tipo === "email" && c.obligatorio)) throw new ErrorContacto("Conserva el correo de contacto como obligatorio para poder responder.");
    for (const { id } of CAMPOS_CONTACTO) {
      const c = formulario.find(c => c.id === id);
      campos[id] = c ? c.obligatorio ? "obligatorio" : "opcional" : "oculto";
    }
  } else if (campos.email !== "obligatorio" || campos.mensaje !== "obligatorio") {
    throw new ErrorContacto("El correo y el mensaje son obligatorios para poder responder.");
  }
  return { activo: b.activo, titulo, descripcion: (b.descripcion as string).trim(), destinatario, campos, ...(formulario ? { formulario } : {}) };
}
export function validarMensaje(v: unknown, config: ContactoConfig) {
  const b = objeto(v);
  const datos: Record<string, string> = {};
  for (const { id, etiqueta, max, tipo, obligatorio, opciones } of obtenerCamposContacto(config)) {
    if (tipo === "checkbox") {
      const valores = b[id] ?? [];
      if (!Array.isArray(valores) || valores.length > opciones.length || valores.some(v => typeof v !== "string" || !opciones.includes(v)) || new Set(valores).size !== valores.length) throw new ErrorContacto(`Revisa ${etiqueta}.`);
      if (obligatorio && !valores.length) throw new ErrorContacto(`${etiqueta} es obligatorio.`);
      if (valores.length) datos[id] = opciones.filter(o => valores.includes(o)).join("\n");
      continue;
    }
    if (b[id] !== undefined && typeof b[id] !== "string") throw new ErrorContacto(`Revisa ${etiqueta}.`);
    const valor = ((b[id] as string | undefined) ?? "").trim();
    if (valor.length > max || /[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(valor)) throw new ErrorContacto(`Revisa ${etiqueta} (máximo ${max} caracteres).`);
    if (obligatorio && !valor) throw new ErrorContacto(`${etiqueta} es obligatorio.`);
    if (tipo === "email" && valor && !emailValido(valor)) throw new ErrorContacto(`Escribe un correo válido en ${etiqueta}.`);
    if (valor && esCampoOpciones(tipo) && !opciones.includes(valor)) throw new ErrorContacto(`Elige una opción válida en ${etiqueta}.`);
    if (valor && tipo === "number" && (!/^-?(?:\d+\.?\d*|\.\d+)$/.test(valor) || !Number.isFinite(Number(valor)))) throw new ErrorContacto(`Escribe un número válido en ${etiqueta}.`);
    if (valor && tipo === "date" && (!/^\d{4}-\d{2}-\d{2}$/.test(valor) || !Number.isFinite(Date.parse(valor)) || new Date(valor).toISOString().slice(0, 10) !== valor)) throw new ErrorContacto(`Escribe una fecha válida en ${etiqueta}.`);
    if (valor) datos[id] = valor;
  }
  return datos;
}
