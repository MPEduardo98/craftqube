export { getContactoConfig, getContactoPublico } from "./config";
export { CAMPOS_CONTACTO, CONTACTO_DEFAULT, TIPOS_CAMPO_CONTACTO, obtenerCamposContacto, esCampoOpciones } from "./types";
export type { CampoContacto, CampoFormularioContacto, TipoCampoContacto, ReglaCampo, ContactoConfig, ContactoPublico, MensajeContacto } from "./types";
