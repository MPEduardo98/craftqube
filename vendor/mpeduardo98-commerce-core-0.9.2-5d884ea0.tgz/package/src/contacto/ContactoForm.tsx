"use client";
import { useId, useRef, useState, type FormEvent } from "react";
import { obtenerCamposContacto, type CampoFormularioContacto, type ContactoPublico } from "./types";

function CampoFormulario({ campo: c, prefijo, controlClassName }: { campo: CampoFormularioContacto; prefijo: string; controlClassName?: string }) {
  const [seleccionados, setSeleccionados] = useState<string[]>([]);
  const id = `${prefijo}-${c.id}`;
  const ayudaId = c.ayuda ? `${id}-ayuda` : undefined;
  const titulo = <>{c.etiqueta}{c.obligatorio ? " *" : " (opcional)"}</>;
  if (c.tipo === "radio" || c.tipo === "checkbox") return <fieldset aria-describedby={ayudaId} style={{ border: 0, padding: 0, margin: 0, minWidth: 0 }}>
    <legend style={{ marginBottom: 8 }}>{titulo}</legend>
    <div style={{ display: "grid", gap: 8 }}>{c.opciones.map((opcion, i) => <label key={i} style={{ display: "flex", alignItems: "center", gap: 8, overflowWrap: "anywhere" }}>
      <input type={c.tipo} name={c.id} value={opcion} required={c.obligatorio && (c.tipo === "radio" || seleccionados.length === 0)} onChange={e => {
        if (c.tipo === "checkbox") setSeleccionados(actual => e.target.checked ? [...actual, opcion] : actual.filter(v => v !== opcion));
      }} />{opcion}
    </label>)}</div>
    {c.ayuda && <small id={ayudaId}>{c.ayuda}</small>}
  </fieldset>;
  const props = { id, name: c.id, required: c.obligatorio, "aria-describedby": ayudaId, className: controlClassName };
  return <div style={{ display: "grid", gap: 6, minWidth: 0 }}>
    <label htmlFor={id}>{titulo}</label>
    {c.tipo === "textarea" ? <textarea {...props} rows={5} maxLength={c.max} placeholder={c.placeholder} /> :
      c.tipo === "select" ? <select {...props} defaultValue=""><option value="" disabled={c.obligatorio}>{c.placeholder || "Selecciona una opción"}</option>{c.opciones.map(o => <option key={o} value={o}>{o}</option>)}</select> :
        <input {...props} type={c.tipo} step={c.tipo === "number" ? "any" : undefined} maxLength={c.max} placeholder={c.placeholder} autoComplete={c.id === "email" ? "email" : c.id === "nombre" ? "name" : c.id === "telefono" ? "tel" : "off"} />}
    {c.ayuda && <small id={ayudaId}>{c.ayuda}</small>}
  </div>;
}

/** Comparte los controles con la vista previa del administrador. */
export function CamposFormularioContacto({ campos, prefijo, controlClassName }: { campos: CampoFormularioContacto[]; prefijo: string; controlClassName?: string }) {
  return <>{campos.map(c => <CampoFormulario key={`${c.id}-${c.tipo}`} campo={c} prefijo={prefijo} controlClassName={controlClassName} />)}</>;
}

/** La tienda puede dar estilo con className o consumir /api/contacto con su propio diseño. */
export function ContactoForm({ config, className, privacidadUrl }: { config: ContactoPublico; className?: string; privacidadUrl?: string }) {
  const id = useId();
  const enviando = useRef(false);
  const [estado, setEstado] = useState<"idle" | "enviando" | "enviado" | "error">("idle");
  const [error, setError] = useState("");
  async function enviar(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (enviando.current) return;
    enviando.current = true;
    setEstado("enviando"); setError("");
    const formData = new FormData(e.currentTarget);
    const datos: Record<string, string | FormDataEntryValue[]> = { website: String(formData.get("website") ?? "") };
    for (const campo of obtenerCamposContacto(config)) {
      datos[campo.id] = campo.tipo === "checkbox" ? formData.getAll(campo.id) : String(formData.get(campo.id) ?? "");
    }
    try {
      const res = await fetch("/api/contacto", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(datos) });
      const json = await res.json();
      if (!res.ok || !json.success) throw new Error(json.error || "No se pudo enviar el mensaje.");
      setEstado("enviado");
    } catch (e) { setError(e instanceof Error ? e.message : "Error de conexión."); setEstado("error"); }
    finally { enviando.current = false; }
  }
  if (!config.activo) return null;
  return <section className={className}>
    <h1>{config.titulo}</h1><p>{config.descripcion}</p>
    {estado === "enviado" ? <p role="status">Recibimos tu mensaje. Te enviaremos una confirmación por correo y responderemos pronto.</p> :
      <form onSubmit={enviar}>
        <fieldset disabled={estado === "enviando"} style={{ border: 0, padding: 0, display: "grid", gap: 16 }}>
          <CamposFormularioContacto campos={obtenerCamposContacto(config)} prefijo={id} />
          <div aria-hidden="true" style={{ position: "absolute", width: 1, height: 1, overflow: "hidden", clipPath: "inset(50%)" }}>
            <label htmlFor={`${id}-website`}>Deja este campo vacío</label><input id={`${id}-website`} name="website" tabIndex={-1} autoComplete="off" />
          </div>
          {privacidadUrl && <a href={privacidadUrl}>Aviso de privacidad</a>}
          {error && <p role="alert">{error}</p>}
          <button type="submit">{estado === "enviando" ? "Enviando…" : "Enviar mensaje"}</button>
        </fieldset>
      </form>}
  </section>;
}
