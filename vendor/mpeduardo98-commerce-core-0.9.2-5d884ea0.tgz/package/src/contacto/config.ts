import { pool } from "../db/pool";
import type { RowDataPacket } from "mysql2";
import { CONTACTO_DEFAULT, type ContactoConfig, type ContactoPublico } from "./types";
import { validarConfig } from "./validacion";

export async function getContactoConfig(): Promise<ContactoConfig> {
  const [rows] = await pool.execute<RowDataPacket[]>("SELECT valor FROM configuracion WHERE clave = 'contacto_config'");
  return rows.length ? validarConfig(JSON.parse(rows[0].valor)) : structuredClone(CONTACTO_DEFAULT);
}
export async function setContactoConfig(config: ContactoConfig) {
  await pool.execute("INSERT INTO configuracion (clave, valor) VALUES ('contacto_config', ?) ON DUPLICATE KEY UPDATE valor = VALUES(valor)", [JSON.stringify(validarConfig(config))]);
}
export function contactoPublico(config: ContactoConfig): ContactoPublico {
  return { activo: config.activo, titulo: config.titulo, descripcion: config.descripcion, campos: config.campos, formulario: config.formulario };
}
export async function getContactoPublico() { return contactoPublico(await getContactoConfig()); }
