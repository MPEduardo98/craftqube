import Link from "next/link";
import { AdminPageHeader } from "../../../admin/components/AdminPageHeader";
import { MensajesContacto } from "../../../admin/contacto/MensajesContacto";
export const metadata = { title: "Mensajes de contacto" };
export default function ContactoPage() {
  return <div className="min-h-full" style={{ background: "var(--color-cq-bg, #fafafa)" }}>
    <AdminPageHeader titulo="Contacto" descripcion="Consultas recibidas desde el formulario de tu tienda"
      acciones={<Link href="/admin/ajustes/contacto" className="btn-secondary">Configurar formulario</Link>} />
    <div className="px-8 pb-10"><MensajesContacto /></div>
  </div>;
}
