import React from "react";
import { render } from "@react-email/components";
import { getLogoAttachment } from "../email/logo";
import { ContactoConfirmacionEmail, ContactoNotificacionEmail } from "../email/templates/ContactoEmail";
import { pool } from "../db/pool";
import type { RowDataPacket, ResultSetHeader } from "mysql2";
import { getResend, getFromEmail } from "../email/resend";
import { getStoreConfig } from "../config/store-config";
import { CAMPOS_CONTACTO, type MensajeContacto, type ContactoConfig } from "./types";

export async function recibirMensaje(datos: MensajeContacto["datos"], config: ContactoConfig) {
  // Primero conservar la consulta: un fallo del proveedor no debe perderla.
  const [r] = await pool.execute<ResultSetHeader>("INSERT INTO contacto_mensajes (datos) VALUES (?)", [JSON.stringify(datos)]);
  let estado = "error";
  let confirmacion = "error";
  try {
    const { nombre: tienda } = await getStoreConfig();
    const logo = await getLogoAttachment();
    const html = await render(React.createElement(ContactoNotificacionEmail, { tienda, consulta: r.insertId, datos }));
    const { error } = await getResend().emails.send({
      from: getFromEmail(), to: config.destinatario, replyTo: datos.email,
      subject: `Nueva consulta de contacto #${r.insertId}`,
      html, attachments: logo ? [logo] : [],
      text: CAMPOS_CONTACTO.filter(c => datos[c.id]).map(c => `${c.etiqueta}:\n${datos[c.id]}`).join("\n\n"),
    });
    if (!error) estado = "enviada";
    else console.error("[contacto] Proveedor rechazó la notificación", error.name);
  } catch { console.error("[contacto] No se pudo enviar la notificación"); }
  try {
    const { nombre } = await getStoreConfig();
    const logo = await getLogoAttachment();
    const html = await render(React.createElement(ContactoConfirmacionEmail, { tienda: nombre, consulta: r.insertId }));
    const { error } = await getResend().emails.send({
      from: getFromEmail(), to: datos.email!, replyTo: config.destinatario,
      subject: `Recibimos tu mensaje — ${nombre.replace(/[\r\n]/g, " ")}`,
      html, attachments: logo ? [logo] : [],
      // No reproducir texto del visitante en correos enviados a terceros.
      text: `Gracias por contactar a ${nombre}.\n\nRecibimos tu mensaje (consulta #${r.insertId}). Nuestro equipo lo revisará y se pondrá en contacto contigo.\n\nPuedes responder a este correo si necesitas agregar información.`,
    });
    if (!error) confirmacion = "enviada";
    else console.error("[contacto] Proveedor rechazó el acuse", error.name);
  } catch { console.error("[contacto] No se pudo enviar el acuse"); }
  // Si falla el registro del resultado, el mensaje sigue visible como pendiente.
  try { await pool.execute("UPDATE contacto_mensajes SET notificacion = ?, confirmacion = ? WHERE id = ?", [estado, confirmacion, r.insertId]); }
  catch { console.error("[contacto] No se pudo registrar el estado de notificación"); }
  return r.insertId;
}
export async function listarMensajes(pagina: number) {
  const [rows] = await pool.query<RowDataPacket[]>("SELECT id, datos, estado, notificacion, confirmacion, creado_at FROM contacto_mensajes ORDER BY id DESC LIMIT 21 OFFSET ?", [(pagina - 1) * 20]);
  return {
    hayMas: rows.length > 20,
    mensajes: rows.slice(0, 20).map(r => ({ ...r, datos: typeof r.datos === "string" ? JSON.parse(r.datos) : r.datos, creado_at: new Date(r.creado_at).toISOString() })) as MensajeContacto[],
  };
}
