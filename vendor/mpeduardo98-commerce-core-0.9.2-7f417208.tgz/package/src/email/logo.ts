import fs from "fs";
import path from "path";

/* ─────────────────────────────────────────────────────────────
   Logo optimizado para email
   
   Reglas:
   - Display en HTML:  width="140"  (lo que el usuario ve)
   - Archivo fuente:   280px ancho  (2× para pantallas retina)
   - Formato:          WebP         (60-80% más ligero que PNG)
   - Objetivo:         < 10 KB
   - Cache:            en memoria tras la primera llamada
─────────────────────────────────────────────────────────────── */
type LogoAttachment = { content: string; filename: string; contentId: string };

let _logoCache: LogoAttachment | null | undefined = undefined;

export async function getLogoAttachment(): Promise<LogoAttachment | null> {
  if (_logoCache !== undefined) return _logoCache;

  try {
    const logoPath = path.join(process.cwd(), "public", "logo_email.png");
    const raw      = fs.readFileSync(logoPath);
    const rawKB    = Math.round(raw.length / 1024);

    try {
      const sharp = (await import("sharp")).default;

      const buffer = await sharp(raw)
        .resize({
          width:              280,         // 2× el display de 140px → retina
          withoutEnlargement: true,        // no agrandar si el original es menor
        })
        .webp({
          quality:    82,                  // buen balance calidad/peso para logos
          lossless:   false,
          smartSubsample: true,
        })
        .toBuffer();

      const finalKB = Math.round(buffer.length / 1024);
      console.log(`[email] Logo: ${rawKB}KB PNG → ${finalKB}KB WebP (280px)`);

      _logoCache = {
        content:   buffer.toString("base64"),
        filename:  "Logo.webp",
        contentId: "logo-tienda",
      };

    } catch {
      // sharp no disponible — fallback a PNG sin transformar
      console.warn(`[email] sharp no disponible, usando logo original (${rawKB}KB)`);
      _logoCache = {
        content:   raw.toString("base64"),
        filename:  "Logo.png",
        contentId: "logo-tienda",
      };
    }

    return _logoCache;

  } catch {
    console.warn("[email] No se pudo leer public/Logo.png — el logo no aparecerá");
    _logoCache = null;
    return null;
  }
}

