import React from "react";
import { EmailBase } from "./EmailBase";
import { CAMPOS_CONTACTO, type MensajeContacto } from "../../contacto/types";

interface Props {
  tienda: string;
  consulta: number;
}

const parrafo: React.CSSProperties = { margin: "0 0 24px", fontSize: "15px", color: "#475569", lineHeight: 1.7 };
const referencia: React.CSSProperties = { padding: "16px", margin: "0 0 24px", backgroundColor: "#f8fafc", borderLeft: "3px solid #2563eb", borderRadius: "8px", color: "#1e293b", fontSize: "15px" };

export function ContactoConfirmacionEmail({ tienda, consulta }: Props) {
  return (
    <EmailBase tienda={tienda} subtitulo="Contacto" titulo="Recibimos tu mensaje" footerText={`Recibiste este correo porque se envió una consulta con esta dirección a ${tienda}.`}>
      <p style={parrafo}>Gracias por contactar a <strong>{tienda}</strong>.</p>
      <p style={referencia}>Tu número de consulta es <strong>#{consulta}</strong>.</p>
      <p style={parrafo}>Nuestro equipo revisará tu mensaje y se pondrá en contacto contigo.</p>
      <p style={{ ...parrafo, marginBottom: 0 }}>Puedes responder a este correo si necesitas agregar información.</p>
    </EmailBase>
  );
}

export function ContactoNotificacionEmail({ tienda, consulta, datos }: Props & { datos: MensajeContacto["datos"] }) {
  return (
    <EmailBase tienda={tienda} subtitulo="Formulario de contacto" titulo="Nueva consulta" footerText="Responde a este correo para contactar directamente al visitante.">
      <p style={referencia}>Consulta <strong>#{consulta}</strong></p>
      {CAMPOS_CONTACTO.filter(campo => datos[campo.id]).map(campo => (
        <div key={campo.id} style={{ marginBottom: "24px" }}>
          <p style={{ margin: "0 0 6px", fontSize: "12px", fontWeight: 700, color: "#64748b" }}>{campo.etiqueta}</p>
          <p style={{ ...parrafo, marginBottom: 0, whiteSpace: "pre-wrap", overflowWrap: "anywhere", wordBreak: "break-word" }}>{datos[campo.id]}</p>
        </div>
      ))}
    </EmailBase>
  );
}
