"use client";
// admin/components/AdminSidebar.tsx
// ─────────────────────────────────────────────────────────────
// Navegación del panel. Minimalista en blanco y negro: el elemento
// activo lleva una "píldora" que se desliza entre opciones
// (layoutId de framer-motion) y los submenús se despliegan con
// altura animada.
//
// Sólo enlaza a pantallas que existen: una opción que lleva a 404
// es peor que no tenerla.
// ─────────────────────────────────────────────────────────────
import Link            from "next/link";
import Image           from "next/image";
import { usePathname } from "next/navigation";
import { useState }    from "react";
import { motion, AnimatePresence } from "framer-motion";

interface NavItem {
  label:     string;
  href:      string;
  icon:      React.ReactNode;
  children?: { label: string; href: string }[];
}

interface AdminSidebarProps {
  /** Nombre de la tienda: alt del logo y respaldo cuando no hay imagen */
  nombre:  string;
  /** Logo del panel. Vacío = se rotula con el nombre en texto */
  logoUrl: string;
  colorFondo?: string;
  colorTexto?: string;
}

function Icon({ d, d2 }: { d: string; d2?: string }) {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <path d={d}/>{d2 && <path d={d2}/>}
    </svg>
  );
}

const NAV: NavItem[] = [
  { label: "Inicio", href: "/admin",
    icon: <Icon d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6h-6v6H4a1 1 0 0 1-1-1z" /> },
  { label: "Productos", href: "/admin/productos",
    icon: <Icon d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" d2="M3.3 7 12 12l8.7-5M12 22V12" />,
    children: [
      { label: "Todos",          href: "/admin/productos" },
      { label: "Nuevo producto", href: "/admin/productos/crear" },
      { label: "Categorías",     href: "/admin/categorias" },
    ],
  },
  { label: "Pedidos", href: "/admin/pedidos",
    icon: <Icon d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z" d2="M3 6h18M16 10a4 4 0 0 1-8 0" /> },
  { label: "Cupones", href: "/admin/cupones",
    icon: <Icon d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z" d2="M7 7h.01" /> },
  { label: "Reseñas", href: "/admin/resenas",
    icon: <Icon d="M12 2.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.3l-5.9 3.2 1.2-6.5L2.5 9.4l6.6-.9z" /> },
  { label: "Ajustes", href: "/admin/ajustes",
    icon: <Icon d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" d2="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0z" /> },
  { label: "Analítica", href: "/admin/analitica",
    icon: <Icon d="M3 3v18h18M7 16v-4M12 16V8M17 16V5" /> },
  { label: "Contacto", href: "/admin/contacto", icon: <Icon d="M4 4h16v16H4z" d2="m4 6 8 6 8-6" /> },
];

const RESORTE = { type: "spring", stiffness: 500, damping: 38, mass: 0.8 } as const;

export function AdminSidebar({ nombre, logoUrl, colorFondo = "#ffffff", colorTexto = "#525252" }: AdminSidebarProps) {
  const pathname = usePathname();

  const hijoActivo = (href: string) => pathname === href || pathname.startsWith(href + "/");
  const isActive = (item: NavItem) =>
    item.href === "/admin"
      ? pathname === "/admin"
      : pathname.startsWith(item.href) || !!item.children?.some((c) => hijoActivo(c.href));

  const abiertoInicial = NAV.find((n) => n.children && isActive(n))?.href ?? null;
  const [abierto, setAbierto] = useState<string | null>(abiertoInicial);

  return (
    <aside
      className="cc-sidebar w-[232px] h-full flex flex-col shrink-0 overflow-y-auto"
      style={{ background: colorFondo, color: colorTexto }}
    >
      {/* Marca */}
      <div className="h-14 flex items-center gap-2.5 px-5 shrink-0">
        {logoUrl ? (
          <Image src={logoUrl} alt={nombre} width={112} height={26} priority
            unoptimized={/^https?:\/\//.test(logoUrl)}
            style={{ height: "auto", maxHeight: 26, width: "auto", filter: "grayscale(1)" }} />
        ) : (
          <>
            <span className="w-6 h-6 rounded-md flex items-center justify-center text-[11px] font-semibold shrink-0"
              style={{ background: colorTexto, color: colorFondo }}>
              {nombre.trim().charAt(0).toUpperCase() || "T"}
            </span>
            <span className="text-[14px] font-semibold tracking-tight truncate" style={{ color: "inherit" }}>
              {nombre}
            </span>
          </>
        )}
      </div>

      <nav className="flex-1 px-3 pt-2 pb-4">
        <p className="px-2.5 pb-2 text-[11px] font-medium" style={{ color: "inherit" }}>
          Menú
        </p>
        <ul className="space-y-0.5">
          {NAV.map((item) => {
            const activo    = isActive(item);
            const conHijos  = !!item.children?.length;
            const expandido = abierto === item.href;

            const contenido = (
              <>
                {activo && (
                  <motion.span
                    layoutId="cc-nav-activo"
                    transition={RESORTE}
                    className="absolute inset-0 rounded-lg"
                    style={{ background: "color-mix(in srgb, currentColor 12%, transparent)", boxShadow: "inset 0 0 0 1px color-mix(in srgb, currentColor 15%, transparent)" }}
                  />
                )}
                <span className="relative flex items-center gap-2.5 flex-1 min-w-0">
                  <span style={{ color: "inherit" }}>{item.icon}</span>
                  <span className="truncate">{item.label}</span>
                </span>
                {conHijos && (
                  <motion.svg
                    width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                    strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
                    className="relative shrink-0" style={{ color: "inherit" }}
                    animate={{ rotate: expandido ? 90 : 0 }} transition={RESORTE}
                  >
                    <polyline points="9 6 15 12 9 18" />
                  </motion.svg>
                )}
              </>
            );

            const clases =
              "relative w-full flex items-center gap-2 h-9 px-2.5 rounded-lg text-[13.5px] text-left " +
              (activo ? "font-medium" : "");
            const color = { color: "inherit" };

            return (
              <li key={item.href}>
                {conHijos ? (
                  <button type="button" onClick={() => setAbierto(expandido ? null : item.href)}
                    className={clases} style={color} aria-expanded={expandido}>
                    {contenido}
                  </button>
                ) : (
                  <Link href={item.href} className={clases} style={color}>
                    {contenido}
                  </Link>
                )}

                <AnimatePresence initial={false}>
                  {conHijos && expandido && (
                    <motion.ul
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
                      className="overflow-hidden ml-[21px] pl-3"
                      style={{ borderLeft: "1px solid color-mix(in srgb, currentColor 15%, transparent)" }}
                    >
                      {item.children!.map((hijo) => {
                        // "Todos" (/admin/productos) no se marca estando en "Nuevo producto"
                        const ha = hijoActivo(hijo.href) && !item.children!.some(
                          (o) => o.href !== hijo.href && o.href.startsWith(hijo.href) && hijoActivo(o.href)
                        );
                        return (
                          <li key={hijo.href} className="py-px first:pt-1 last:pb-1">
                            <Link href={hijo.href}
                              className="flex items-center h-8 px-2.5 rounded-md text-[13px]"
                              style={{ color: "inherit", background: ha ? "color-mix(in srgb, currentColor 12%, transparent)" : undefined, fontWeight: ha ? 600 : 400 }}>
                              {hijo.label}
                            </Link>
                          </li>
                        );
                      })}
                    </motion.ul>
                  )}
                </AnimatePresence>
              </li>
            );
          })}
        </ul>
      </nav>

      <div className="px-5 py-4 shrink-0" style={{ borderTop: "1px solid color-mix(in srgb, currentColor 15%, transparent)" }}>
        <p className="text-[11px]" style={{ color: "inherit" }}>Panel de administración</p>
      </div>
    </aside>
  );
}
