"use client";

import { useEffect, useState } from "react";
import { CAMPOS_CONTACTO, type MensajeContacto } from "../../contacto/types";

const ESTADOS: Record<MensajeContacto["estado"], { label: string; color: string; fondo: string }> = {
  nuevo: { label: "Nuevo", color: "#a16207", fondo: "#fef9e7" },
  leido: { label: "Leído", color: "#525252", fondo: "#f5f5f5" },
  resuelto: { label: "Resuelto", color: "#15803d", fondo: "#f0fdf4" },
};

const ENVIOS: Record<MensajeContacto["notificacion"], string> = {
  enviada: "Enviado",
  pendiente: "Pendiente",
  error: "No enviado",
};

const CAMPOS_LATERALES = CAMPOS_CONTACTO.filter(c => c.id !== "mensaje" && c.id !== "asunto");

function fecha(v: string) {
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? "Fecha no disponible" : d.toLocaleString("es-MX", {
    day: "numeric", month: "short", year: "numeric", hour: "numeric", minute: "2-digit",
  });
}

function Dato({ etiqueta, valor }: { etiqueta: string; valor: string }) {
  return <div className="min-w-0">
    <dt className="text-[11px] font-medium text-slate-500">{etiqueta}</dt>
    <dd className="mt-0.5 break-words text-[13px] text-slate-800">{valor}</dd>
  </div>;
}

export function MensajesContacto() {
  const [pagina, setPagina] = useState(1);
  const [mensajes, setMensajes] = useState<MensajeContacto[]>([]);
  const [hayMas, setHayMas] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [revision, setRevision] = useState(0);
  const [saving, setSaving] = useState<number | null>(null);

  useEffect(() => {
    const controller = new AbortController();
    setLoading(true);
    setError("");
    fetch(`/api/admin/contacto?pagina=${pagina}`, { signal: controller.signal }).then(async res => {
      const json = await res.json();
      if (!res.ok || !json.success) throw new Error("No se pudieron cargar las consultas.");
      if (!controller.signal.aborted) {
        setMensajes(json.data.mensajes);
        setHayMas(json.data.hayMas);
      }
    }).catch(e => {
      if (!controller.signal.aborted) setError(e instanceof Error ? e.message : "Error de conexión.");
    }).finally(() => {
      if (!controller.signal.aborted) setLoading(false);
    });
    return () => controller.abort();
  }, [pagina, revision]);

  async function cambiar(id: number, estado: MensajeContacto["estado"]) {
    setSaving(id);
    setError("");
    try {
      const res = await fetch("/api/admin/contacto", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, estado }),
      });
      const json = await res.json();
      if (!res.ok || !json.success) throw new Error("No se pudo cambiar el estado.");
      setMensajes(actual => actual.map(m => m.id === id ? { ...m, estado } : m));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error de conexión.");
    } finally {
      setSaving(null);
    }
  }

  return <section className="overflow-hidden rounded-xl border border-slate-200 bg-white" style={{ boxShadow: "var(--shadow-card)" }} aria-label="Consultas recibidas">
    <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 px-5 py-4">
      <div>
        <h2 className="text-[14px] font-semibold text-slate-900">Mensajes recibidos</h2>
        <p className="mt-0.5 text-[12px] text-slate-500">Revisa las consultas y actualiza su estado.</p>
      </div>
      <button type="button" className="btn-secondary disabled:opacity-40" disabled={loading || saving !== null} onClick={() => setRevision(r => r + 1)}>
        <svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <path d="M20 11a8 8 0 1 0-2.3 6.7M20 4v7h-7" />
        </svg>
        Actualizar
      </button>
    </div>

    {error && <p role="alert" className="border-b border-red-200 bg-red-50 px-5 py-3 text-[13px] text-red-600">{error}</p>}

    {loading ? <div role="status" className="px-5 py-14 text-center text-[13px] text-slate-500">Cargando consultas…</div>
      : mensajes.length === 0 ? <div className="px-5 py-14 text-center">
        <p className="text-[14px] font-medium text-slate-800">{error ? "No se pudieron mostrar las consultas" : "No hay mensajes recibidos"}</p>
        <p className="mt-1 text-[13px] text-slate-500">{error ? "Vuelve a intentarlo con Actualizar." : "Las consultas del formulario aparecerán aquí."}</p>
      </div>
      : <div className="divide-y divide-slate-200">
        {mensajes.map(m => {
          const nombre = m.datos.nombre || m.datos.email || `Consulta #${m.id}`;
          const asunto = m.datos.asunto?.trim();
          const laterales = CAMPOS_LATERALES.filter(c => m.datos[c.id]);
          return <article key={m.id} className="min-w-0">
            <div className="flex flex-wrap items-start justify-between gap-3 px-5 py-4">
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <h3 className="break-words text-[14px] font-semibold text-slate-900">{asunto || `Consulta #${m.id}`}</h3>
                  <span className="rounded-md px-2 py-0.5 text-[11px] font-medium" style={{ color: ESTADOS[m.estado].color, background: ESTADOS[m.estado].fondo }}>{ESTADOS[m.estado].label}</span>
                </div>
                <p className="mt-1 break-words text-[12px] text-slate-500">#{m.id} · {nombre} · {fecha(m.creado_at)}</p>
              </div>
              <label className="flex shrink-0 items-center gap-2 text-[12px] text-slate-500">
                Estado
                <select aria-label={`Estado de consulta ${m.id}`} value={m.estado} disabled={saving !== null} onChange={e => cambiar(m.id, e.target.value as MensajeContacto["estado"])} className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-[12px] font-medium text-slate-800">
                  <option value="nuevo">Nuevo</option>
                  <option value="leido">Leído</option>
                  <option value="resuelto">Resuelto</option>
                </select>
              </label>
            </div>

            <div className="grid gap-5 border-t border-slate-100 px-5 py-4 sm:grid-cols-[minmax(0,1.5fr)_minmax(180px,1fr)]">
              <div className="min-w-0">
                <p className="text-[11px] font-medium text-slate-500">Mensaje</p>
                <p className="mt-1 whitespace-pre-wrap break-words text-[13px] leading-relaxed text-slate-800">{m.datos.mensaje || "Sin mensaje"}</p>
              </div>
              {laterales.length > 0 && <dl className="grid min-w-0 content-start gap-3 border-t border-slate-100 pt-4 sm:border-t-0 sm:border-l sm:pl-5 sm:pt-0">
                {laterales.map(c => <Dato key={c.id} etiqueta={c.etiqueta} valor={m.datos[c.id] || ""} />)}
              </dl>}
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 bg-slate-50 px-5 py-3 text-[11px] text-slate-500">
              <div className="flex flex-wrap gap-x-4 gap-y-1">
                <span>Aviso a tienda: <strong className="font-medium text-slate-700">{ENVIOS[m.notificacion]}</strong></span>
                <span>Acuse al cliente: <strong className="font-medium text-slate-700">{ENVIOS[m.confirmacion]}</strong></span>
              </div>
              {m.datos.email && <a className="font-medium text-slate-900 hover:underline" href={`mailto:${encodeURIComponent(m.datos.email)}?subject=${encodeURIComponent(`Re: Consulta #${m.id}`)}`}>Responder por correo ↗</a>}
            </div>
          </article>;
        })}
      </div>}

    <div className="flex items-center justify-between gap-3 border-t border-slate-200 px-5 py-3 text-[12px] text-slate-500">
      <span>Página {pagina}</span>
      <div className="flex items-center gap-2">
        <button type="button" className="btn-secondary disabled:opacity-40" disabled={loading || saving !== null || pagina === 1} onClick={() => setPagina(p => p - 1)}>Anterior</button>
        <button type="button" className="btn-secondary disabled:opacity-40" disabled={loading || saving !== null || !hayMas} onClick={() => setPagina(p => p + 1)}>Siguiente</button>
      </div>
    </div>
  </section>;
}
